// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 7-5 mod version average life

// Modified version of listing 7-5 of Generative Art by Pearson
// modifications based on Shiffman's version of Game of Life from
// coding challenges (Coding Train).

// Daniel Shiffman
// http://codingtra.in
// http://patreon.com/codingtrain

// Game of Life (GOL)
// Video: https://youtu.be/FWSR_7kZuYg

let nextState;
let state;
let lastState;

let numX;
let numY;
let cellSize = 10;
let pCount = 0;
let stage = 0;
let avg = 0;

function setup() {
	createCanvas(500, 300);
	numX = width / cellSize;
	numY = height / cellSize;
	restart();
} //end setup

function draw() {
	background(200);
  
	//calculate nextState
	for (let i = 0; i < numX; i++) {
		for (let j = 0; j < numY; j++) {
			avg = countNeighbors(i, j);
      nextState[i][j] = calcNextState(avg,state[i][j],nextState[i][j],lastState[i][j]);
      lastState[i][j] = state[i][j];
    }
	}
	//arrayCopy(state,lastState);
  if (pCount < 100){
  console.log('pCnt ' + pCount);
  console.log("s3 " + state[0][0] + " " + state[1][0] + " " + state[48][29] + " " + state[49][29] + "\n");
  console.log("n3 " + nextState[0][0] + " " + nextState[1][0] + " " + nextState[48][29] + " " + nextState[49][29] + "\n");
  console.log("ls3 " + lastState[0][0] + " " + lastState[1][0] + " " + lastState[48][29] + " " + lastState[49][29] + "\n");
  pCount++;
  }
  drawGrid();

} //end draw

function make2DArray(cols, rows) {
	let arr = new Array(cols);
	for (let i = 0; i < arr.length; i++) {
		arr[i] = new Array(rows);
	}
	return arr;
} // end make

function restart(){ //initialize or re-initialize arrays
	nextState = make2DArray(numX, numY);
	state = make2DArray(numX, numY);
	lastState = make2DArray(numX, numY);
	
	for (let i = 0; i < numX; i++) {
		for (let j = 0; j < numY; j++) {
			x = i * cellSize;
			y = j * cellSize
			nextState[i][j] = ((x/width) + (y/height)) * 14;
			lastState[i][j] = 0.0;
		}
	}
	arrayCopy(nextState, state);
}// end restart

function countNeighbors(x, y) {
	let total = 0;
	for (let i = -1; i < 2; i++) {
		for (let j = -1; j < 2; j++) {
			let col = (x + i + numX) % numX;
			let row = (y + j + numY) % numY;
			total += state[col][row];
		}
	}
	total -= state[x][y]; // this subtracts the value of the current state from neighbor count
	let neighAvg = int(total/8.0);
  return neighAvg;
} //end countNeighbors

function calcNextState(nAvg,sState,nState,lState){
	if (nAvg == 255) {nState = 0;
	} else if (nAvg == 0) {nState = 255;
	} else {
		nState = sState + nAvg;
		if (lState > 0){nState -= lState;}
		if (nState > 255){nState = 255;} 
	}
	return nState
}

function drawGrid(){
	arrayCopy(nextState,state);
	translate(cellSize/2,cellSize/2);
	for (let i = 0; i < numX; i++) {
		for (let j = 0; j < numY; j++) {
			let x = i * cellSize;
			let y = j * cellSize;
			stroke(0);
			fill(10 * state[i][j]);
			ellipse(x,y,cellSize,cellSize);
		}
	}
} // end drawMe

function mousePressed(){
	restart();
}// end mousePressed


function debugPrint(sLim, eLim, pVal,tNum){
  if ((pCount >= sLim) && (pCount < eLim)){
    console.log(pCount);
    if (tNum > 0){console.log('pVal ' + pVal);}
    console.log("s " + state[0][0] + " " + state[1][0] + " " + state[48][29] + " " + state[49][29] + "\n");
    console.log("n " + nextState[0][0] + " " + nextState[1][0] + " " + nextState[48][29] + " " + nextState[49][29] + "\n");
    console.log("ls " + lastState[0][0] + " " + lastState[1][0] + " " + lastState[48][29] + " " + lastState[49][29] + "\n");
  }
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-7-5_mod_version_average_life.jpg')
}

// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 5-3 2D perlin noise

var xstart, xnoise, ystart, ynoise;

function setup() {
  createCanvas(300,300);
  smooth();
  background(0);
  frameRate(24);
  
  xstart = random(10);
  ystart = random(10);
}

function draw () {
  background(0);

  xstart += 0.01;   
  ystart += 0.01;	
  
  xnoise = xstart;
  ynoise = ystart;
  
  for (var y = 0; y <= height; y+=5) {
    ynoise += 0.1;
    xnoise = xstart;
    for (var x = 0; x <= width; x+=5) {
      xnoise += 0.1;
      drawPoint(x, y, noise(xnoise, ynoise));
    }
  } 
}

function drawPoint(x, y, noiseFactor) {
  push();
  translate(x,y);
  rotate(noiseFactor * radians(540));
  noStroke();
  var edgeSize = noiseFactor * 35;
  var grey = 150 + (noiseFactor * 120);
  var alph = 150 + (noiseFactor * 120);
  fill(grey, alph);
  ellipse(0,0, edgeSize, edgeSize/2);
  pop();
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-5-3_2D_perlin_noise.jpg')
}

// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 5-2 noise grid

var xstart, xnoise, ynoise;	

function setup() {	
  createCanvas(300,300);
  smooth();
  background(255);
  xstart = random(10);
  xnoise = xstart;
  ynoise = random(10);
  for (var y = 0; y <= height; y+=5) {
    ynoise += 0.1;		
    xnoise = xstart;
    for (var x = 0; x <= width; x+=5) {
      xnoise += 0.1; 
      drawPoint(x, y, noise(xnoise, ynoise));  
    }
  } 
}

function drawPoint(x, y, noiseFactor) {	
  var len = 10 * noiseFactor;
  rect(x, y, len, len);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-5-2_noise_grid.jpg')
}

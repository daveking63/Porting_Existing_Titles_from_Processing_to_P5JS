// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 7-4 brian brain rules for gol

// Modified version of listing 7-4 of Generative Art by Pearson
// modifications based on Shiffman's version of Game of Life from
// coding challenges (Coding Train).

// Daniel Shiffman
// http://codingtra.in
// http://patreon.com/codingtrain

// Game of Life (GOL)
// Video: https://youtu.be/FWSR_7kZuYg

function make2DArray(cols, rows) {
	let arr = new Array(cols);
	for (let i = 0; i < arr.length; i++) {
		arr[i] = new Array(rows);
	}
	return arr;
}

let cellArray;
let numX;
let numY;
let cellSize = 10;

function setup() {
    createCanvas(500, 300);
    numX = width / cellSize;
	numY = height / cellSize;

	cellArray = make2DArray(numX, numY);
	for (let i = 0; i < numX; i++) {
		for (let j = 0; j < numY; j++) {
			cellArray[i][j] = int(random(3));
		}
	}
} //end setup

function draw() {
	background(200);

	// if cell[i][j] == 1, then state is firing and fill black (color 0)
	// else if cell[i][j] == 2, then state is resting and fill grey (color 150)
	// else cell[i][j] == 0, then state is off and fill white (color 255)

	for (let i = 0; i < numX; i++) {
		for (let j = 0; j < numY; j++) {
			let x = i * cellSize;
			let y = j * cellSize;
			stroke(0);
			if (cellArray[i][j] == 1) {
 		       fill(0);
			} else if (cellArray[i][j] == 2) {
				fill(150);
			} else { //cellArray[i][j] == 0
				fill(255);
			}
			ellipse(x,y,cellSize,cellSize);
		}
	}

	let nextState = make2DArray(numX, numY);

	// Compute next based on cellArray
	for (let i = 0; i < numX; i++) {
		for (let j = 0; j < numY; j++) {
			let state = cellArray[i][j];
			
			//Rules for GOL using Brian's Brain Algorithm
			// if state is off (=0) && exactly 2 neighbors are firing (not including self)
			// 		then state becomes firing (=1)
			// else if state is firing (=1), next state is resting (=2)
			// else if state is resting (=2), next state is off (0)

			if (state == 0){
				let firingCount = 0;
				firingCount = countNeighbors(cellArray, i, j);
				if (firingCount == 2){
					nextState[i][j] = 1;
				} else {
					nextState[i][j] = state;
				}
			} else if (state == 1){
				nextState[i][j] = 2;
			} else if (state == 2){
				nextState[i][j] = 0;
			}
		}
	}
	cellArray = nextState;
} //end draw

function countNeighbors(cellArray, x, y) {
	let sum = 0;
	for (let i = -1; i < 2; i++) {
		for (let j = -1; j < 2; j++) {
			let col = (x + i + numX) % numX;
			let row = (y + j + numY) % numY;
      if (cellArray[col][row] == 1){
				sum += cellArray[col][row];
      }
		}
	}
  if (cellArray[x][y] == 1){
		sum -= cellArray[x][y]; // this subtracts the value of the current state from neighbor count
  }
  return sum;
} // end count countNeighbors

// this restarts the game
function mousePressed(){
	cellArray = make2DArray(numX, numY);
	for (let i = 0; i < numX; i++) {
		for (let j = 0; j < numY; j++) {
		cellArray[i][j] = floor(random(2));
		}
	}
}// end mousePressed


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-7-4_brian_brain_rules_for_gol.jpg')
}

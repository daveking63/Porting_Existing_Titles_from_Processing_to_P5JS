// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 5-1 2D noise

function setup(){
	createCanvas(300,300);
	smooth();
	background(255);
	var xstart = random(10);
	var xnoise = xstart;
	var ynoise = random(10);
	  
	for (var y = 0; y <= height; y+=1) {	
		ynoise += 0.01;
		xnoise = xstart;     			
	for (var x = 0; x <= width; x+=1) {	
	  		xnoise += 0.01;
			var alph = int(noise(xnoise, ynoise) * 255);	
	   		stroke(0, alph);
	    		line(x,y, x+1, y+1);
		}
	}
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-5-1_2D_noise.jpg')
}

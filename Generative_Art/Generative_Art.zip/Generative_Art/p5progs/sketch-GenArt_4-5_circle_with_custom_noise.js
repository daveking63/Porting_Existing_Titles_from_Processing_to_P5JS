// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 4-5 circle with custom noise

function setup () {
  createCanvas(500,300);
  background(255);
  strokeWeight(5);
  smooth();
  
  var radius = 100;
  var centX = 250;
  var centY = 150;

  stroke(0, 30);
  noFill();
  ellipse(centX,centY,radius*2,radius*2);
  
  stroke(20, 50, 70);
  strokeWeight(1);
  var x, y;
  var noiseval = random(10);
  
  beginShape();
  fill(20, 50, 70, 50);
  for (var ang = 0; ang <= 360; ang += 1) {
    
    noiseval += 0.1;
    var radVariance = 30 * customNoise(noiseval);
    
    var thisRadius = radius + radVariance;
    var rad = radians(ang);
    x = centX + (thisRadius * cos(rad));
    y = centY + (thisRadius * sin(rad));
    
    curveVertex(x,y);
  }
  endShape();
}

function customNoise(value) {   
   var retValue = pow(sin(value), 3);
   return retValue; 
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-4-5_circle_with_custom_noise.jpg')
}

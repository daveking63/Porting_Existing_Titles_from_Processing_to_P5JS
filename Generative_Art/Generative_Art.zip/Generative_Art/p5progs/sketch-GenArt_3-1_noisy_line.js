// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 3-1 noisy line

function setup(){
    createCanvas(500,100);
    background(255);
    strokeWeight(5);
    smooth();

    stroke(0, 30);
    line(20,50,480,50);

    stroke(20, 50, 70);
    var step = 10;
    var lastx = -999;
    var lasty = -999;
    var ynoise = random(10);
    var y;
    for (var x=20; x<=480; x+=step) {
        y = 10 + noise(ynoise) * 80;  // between 10 and 90
        if (lastx > -999) {
           line(x, y, lastx, lasty); 
        }
        lastx = x;
        lasty = y;
        ynoise += 0.1;
    }
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-3-1_noisy_line.jpg')
}

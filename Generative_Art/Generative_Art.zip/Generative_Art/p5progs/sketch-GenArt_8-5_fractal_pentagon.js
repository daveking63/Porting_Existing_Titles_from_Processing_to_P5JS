// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 8-5 fractal pentagon

var pentagon;
var maxlevels = 5;

function setup(){
    createCanvas(750, 500); //originally 1000 x 1000
    smooth();
    pentagon = new FractalRoot();
    pentagon.drawShape();
}

function PointObj(ex, why) {
     this.x = ex;
     this.y = why;
}

function FractalRoot() {
      this.centX = width/2;
      this.centY = height/2;
      this.count = 0;
	  this.pointArr = [];
	
      for (var i = 0; i<360; i+=72) {
          this.x = this.centX + (150 * cos(radians(i))); //originally 400
          this.y = this.centY + (150 * sin(radians(i))); //originally 400
          this.pointArr[this.count] = new PointObj(this.x, this.y);
          this.count++;
      }
      
      this.rootBranch = new Branch(0, 0, this.pointArr);

	  this.drawShape = function() {
		  this.rootBranch.drawMe();
	  }
}

function Branch(lev, n, points) {
    this.level = lev;
    this.num = n;
    this.outerPoints = points;

  	this.drawMe = function() {
    	strokeWeight(5 - this.level);
    	// draw outer shape
    	for (var i = 0; i < this.outerPoints.length; i++) {
     		this.nexti = i+1;
			if (this.nexti == this.outerPoints.length) { this.nexti = 0; }
     		line(this.outerPoints[i].x, this.outerPoints[i].y, this.outerPoints[this.nexti].x, this.outerPoints[this.nexti].y);
   		}
  	}
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-8-5_fractal_pentagon.jpg')
}

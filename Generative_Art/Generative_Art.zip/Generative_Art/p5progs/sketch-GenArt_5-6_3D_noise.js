// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 5-6 3D noise

var xstart, ystart, zstart;
var xnoise, ynoise, znoise;

var sideLength = 200;
var spacing = 7;

function setup() {
  createCanvas(500, 300, WEBGL);
  background(0);
  noStroke();
  
  xstart = random(10);
  ystart = random(10);
  zstart = random(10);
}

function draw () {
  background(0);
  translate(-width/2, -height/2, 0);	

  xstart += 0.01;  	 
  ystart += 0.01;	
  zstart += 0.01;	
  
  xnoise = xstart;
  ynoise = ystart;
  znoise = zstart;
  
  translate(150, 20, -150);	
  rotateZ(frameCount * 0.1); 	
  rotateY(frameCount * 0.1); 	
  
  for (var z = 0; z <= sideLength; z+=spacing) {	
    znoise += 0.1;					
    ynoise = ystart;			
    for (var y = 0; y <= sideLength; y+=spacing) {
      ynoise += 0.1;
      xnoise = xstart;
      for (var x = 0; x <= sideLength; x+=spacing) {
        xnoise += 0.1;
        drawPoint(x, y, z, noise(xnoise, ynoise, znoise));
      }
    } 
  }
}

function drawPoint(x, y, z, noiseFactor) {
  push();
	  translate(x, y, z);
	  var grey = noiseFactor * 255;
	  fill(grey, 10);
	  box(spacing, spacing, spacing);
  pop();
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-5-6_3D_noise.jpg')
}

// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 2-2 filled circle and lines

function setup(){
	createCanvas(500, 300);	
	smooth();		
	background(230, 230, 230); 

	var centX = width/2;
	var centY = height/2;
	stroke(130, 0, 0); 
	strokeWeight(1);  
	fill(0, 40, 0);	

	ellipse(centX, centY, 30, 30);		
	line(centX - 70, centY - 70, centX + 70, centY + 70);
	line(centX + 70, centY - 70, centX - 70, centY + 70);	
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-2-2_filled_circle_and_lines.jpg')
}

// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 7-3 modified version vichniac vote rules for gol

// Modified version of listing 7-3 of Generative Art by Pearson
// modifications based on Shiffman's version of Game of Life from
// coding challenges (Coding Train).

// Daniel Shiffman
// http://codingtra.in
// http://patreon.com/codingtrain

// Game of Life (GOL)
// Video: https://youtu.be/FWSR_7kZuYg

function make2DArray(cols, rows) {
	let arr = new Array(cols);
	for (let i = 0; i < arr.length; i++) {
		arr[i] = new Array(rows);
	}
	return arr;
}

let cellArray;
let numX;
let numY;
let cellSize = 10;

function setup() {
	createCanvas(500, 300);
	numX = width / cellSize;
	numY = height / cellSize;

	cellArray = make2DArray(numX, numY);
	for (let i = 0; i < numX; i++) {
		for (let j = 0; j < numY; j++) {
			cellArray[i][j] = floor(random(2));
		}
	}
} //end setup

function draw() {
	background(200);
	
	// This section draws the cellArray and cells
	// alive cells (=1) are black and 
	// dead cells (=0) are white

	for (let i = 0; i < numX; i++) {
		for (let j = 0; j < numY; j++) {
			let x = i * cellSize;
			let y = j * cellSize;
			stroke(0);
			if (cellArray[i][j] == 1) {
 		       fill(0);
			} else {
 		       fill(255);
			}
			ellipse(x,y,cellSize,cellSize);
		}
	}

	let nextState = make2DArray(numX, numY);

	// Compute next based on cellArray
	for (let i = 0; i < numX; i++) {
		for (let j = 0; j < numY; j++) {
			let state = cellArray[i][j];
			// Count live neighbors!
			//let sum = 0;

			let liveCount = countNeighbors(cellArray, i, j);

			// In the Vichniac Vote algorithm think of the
			// surrounding neighbors or cells as voters and
			// the current cell as the candidate (who can
			// also vote for him or herself). If a candidate
			// has a majority (5 out of 9) of the 9 neighbors 
			// (including self), then they are elected (live).
			// Else, he or she isn't elected (die).
			// However, Vichniac proposed a twist in the voting process.
			// He proposed reversing the outcome if the candidate
			// had a slight minority (4 votes) or a slight majority
			// (5 votes). So, live were switched to dead and vice-versa.

			if (liveCount <= 4) { // remember numX/numY are numbered starting at 0
					nextState[i][j] = 0;
			} else if (liveCount > 4){
					nextState[i][j] = 1;
			}
			if ((liveCount == 4) || (liveCount == 5)) {
				nextState[i][j] = !nextState[i][j];
			}
		}
	}
	cellArray = nextState;
} //end draw

function countNeighbors(cellArray, x, y) {
	let sum = 0;
	for (let i = -1; i < 2; i++) {
		for (let j = -1; j < 2; j++) {
			let col = (x + i + numX) % numX;
			let row = (y + j + numY) % numY;
			sum += cellArray[col][row];
		}
	}
	//sum -= cellArray[x][y]; // in this version we eliminate this statement and count the current cell
	return sum;
}

// this restarts the game
function mousePressed(){
	cellArray = make2DArray(numX, numY);
	for (let i = 0; i < numX; i++) {
		for (let j = 0; j < numY; j++) {
		cellArray[i][j] = floor(random(2));
		}
	}
}// end mousePressed


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-7-3_modified_version_vichniac_vote_rules_for_gol.jpg')
}

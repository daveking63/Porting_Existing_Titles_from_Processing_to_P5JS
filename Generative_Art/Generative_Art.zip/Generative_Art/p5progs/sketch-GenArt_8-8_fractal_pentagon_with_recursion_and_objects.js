// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 8-8 fractal pentagon with recursion and objects

//Version of recursive pentagon built on objects

var startAngle;
var sides = 5;
var pentagon;
var maxlevels = 4;
var strutFactor = 0.2;
var strutNoise;

function setup() {

    createCanvas(1000, 1000);
    smooth();
    strutNoise = random(10);
}

function draw(){
	strutNoise += 0.01;
	strutFactor = noise(strutNoise) * 2;
	pentagon = new FractalRoot(frameCount);
	pentagon.drawShape();
}

function FractalRoot(startAngle) {
	this.centX = width/2;
	this.centY = height/2;
	this.count = 0;
	this.angle = 360/sides;
	this.pointArr = [];
	
	for (var i = 0; i<360; i+=this.angle) {
		this.x = this.centX + (400 * cos(radians(startAngle + i)));
		this.y = this.centY + (400 * sin(radians(startAngle + i)));
		this.pointArr[this.count] = new createVector(this.x, this.y);
		this.count++;
	}
	
	this.rootBranch = new Branch(0, this.pointArr);
	
	this.drawShape = function() {
		this.rootBranch.drawMe();
	}
}

function Branch(lev, points) {
	this.level = lev;
    this.outerPoints = points;
	this.midPoints = [];
	this.projPoints = [];
	this.myBranches = []
	var mx, my;
    
	//  calculate midPoints
    for (var i = 0; i < this.outerPoints.length; i++) {
        this.nexti = i+1;
        if (this.nexti == this.outerPoints.length) { this.nexti = 0; }
        var end1 = this.outerPoints[i]
        var end2 = this.outerPoints[this.nexti];
        if (end1.x > end2.x) {mx = end2.x + ((end1.x - end2.x)/2);}
        else {mx = end1.x + ((end2.x - end1.x)/2);}
        if (end1.y > end2.y) {my = end2.y + ((end1.y - end2.y)/2);}
        else {my = end1.y + ((end2.y - end1.y)/2);}      
        this.midPoints[i] = new createVector(mx, my);
	}

    // calculate strutPoint
    for (i = 0; i < this.midPoints.length; i++) {
     	this.nexti = i+3;
        if (this.nexti >= this.midPoints.length) {this.nexti -= this.midPoints.length; }
		mp = this.midPoints[i]; 
		op = this.outerPoints[this.nexti];

		if (op.x > mp.x) {opp = op.x - mp.x;}
		else {opp = mp.x - op.x;}
		if (op.y > mp.y) {adj = op.y - mp.y;} 
		else {adj = mp.y - op.y;}
		if (op.x > mp.x) {px = mp.x + (opp * strutFactor);} 
		else {px = mp.x - (opp * strutFactor);}				
		if (op.y > mp.y) {py = mp.y + (adj * strutFactor);}
 		else {py = mp.y - (adj * strutFactor);} 
     	 
 		var strutP	= new createVector(px, py);
		this.projPoints[i] = strutP;
	}
	 
	if ((this.level+1) < maxlevels) {
		this.childBranch = new Branch(this.level+1, this.projPoints);
	}

  	this.drawMe = function() 	{
    	// draw outer shape
		strokeWeight((5 - this.level)/1);
    	for (var i = 0; i < this.outerPoints.length; i++) {
			this.nexti = i+1;
		    if (this.nexti == this.outerPoints.length) { this.nexti = 0; }
				line(this.outerPoints[i].x, this.outerPoints[i].y, this.outerPoints[this.nexti].x, this.outerPoints[this.nexti].y);
		}
		// draw midpoints and projects-struts
		for (var j = 0; j < this.midPoints.length; j++) {
			strokeWeight(0.5);
			fill(255, 150);   
			ellipse(this.midPoints[j].x, this.midPoints[j].y, 7, 7); //originally 7 was 15
			line(this.midPoints[j].x, this.midPoints[j].y, this.projPoints[j].x, this.projPoints[j].y);
			ellipse(this.projPoints[j].x, this.projPoints[j].y, 7, 7);
		}
		for (var k = 0; k < this.myBranches.length; k++) {
			this.myBranches[k].drawMe();
		} 
	} // drawMe
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-8-8_fractal_pentagon_with_recursion_and_objects.jpg')
}

// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 2-5 concentric circles


// variables
var diam = 10;  
var centX, centY;

// init
function setup() {
  createCanvas(500, 300);
  frameRate(24);
  smooth();
  background(180);
  centX = width/2;
  centY = height/2;
  stroke(0);
  strokeWeight(1); 
  noFill(); 
}

// frame loop
function draw() {
  if (diam <= 400) {
    // background(180);	
    // draw the circle 
    ellipse(centX, centY, diam, diam);
    diam += 10;
  }
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-2-5_concentric_circles.jpg')
}

// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 4-4 100 spirals with noise

function setup() {
	createCanvas(500,300);
	background(255);
	strokeWeight(0.5);   
	smooth();

	var centX = 250;
	var centY = 150;

	var x, y;
	for (var i = 0; i<100; i++) {    
	  var lastx = -999;
	  var lasty = -999;
	  var radiusNoise = random(10);
	  var radius = 10;
	  stroke(random(20), random(50), random(70), 80); 
	  var startangle = int(random(360)); 
	  var endangle =  1440 + int(random(1440)); 
	  var anglestep =  5 + int(random(3)); 
	  for (var ang = startangle; ang <= 1440 + random(1440); ang += anglestep) {    
	    radiusNoise += 0.05;
	    radius += 0.5;
	    var thisRadius = radius + (noise(radiusNoise) * 200) - 100;
	    var rad = radians(ang);
	    x = centX + (thisRadius * cos(rad));
	    y = centY + (thisRadius * sin(rad));
	    if (lastx > -999) {
	      line(x,y,lastx,lasty);
	    }
	    lastx = x;
	    lasty = y;  
	  }
	}
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-4-4_100_spirals_with_noise.jpg')
}

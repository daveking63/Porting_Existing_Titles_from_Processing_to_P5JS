// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 6-2 mousereleased drawcircles as objects

var _num = 10;
var circ;	

function setup() {
  createCanvas(500,300);
  background(255);
  smooth();
  strokeWeight(1);
  fill(150, 50);
  circ = new dCircle();
  drawCircles();
}

function draw() {
  // do nothing
}

function mouseReleased() {
  drawCircles();    
}

function drawCircles() {
  for (var i=0; i<_num; i++) { 
  		circ = new dCircle();
  		circ.display();	
  }
}

//=== Circle Object

function dCircle() { 	

    this.x = random(width);
    this.y = random(height);
    this.radius = random(100) + 10; 
    
    this.linecol = color(random(255), random(255), random(255));
    this.fillcol = color(random(255), random(255), random(255), random(255));
    
    this.display = function(){
    	stroke(this.linecol);
    	fill(this.fillcol);
    	ellipse(this.x, this.y, this.radius, this.radius);					
  }
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-6-2_mousereleased_drawcircles_as_objects.jpg')
}

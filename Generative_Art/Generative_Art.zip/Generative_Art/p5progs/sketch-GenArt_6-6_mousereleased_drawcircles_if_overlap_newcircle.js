// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 6-6 mousereleased drawcircles if overlap newcircle

var _num = 5; //original was 10
var max_radius = 50; //original was 100
var circs = [];

function setup() {
	createCanvas(500, 300);
	background(255);
	smooth();
	strokeWeight(1);
	fill(150, 50);
	drawCircles();
}

function draw() {
	background(255);
	for (var i = 0; i < circs.length; i++) {
		circs[i].updateMe();
	}
}

function mouseReleased() {
	drawCircles();
	}

function drawCircles() {
	for (var i = 0; i < _num; i++) {
		circs[i] = new dCircle();
		circs[i].drawMe();
		append(circs,circs[i]);
	}
}

//=== Circle Object

function dCircle() {

	this.x = random(width);
	this.y = random(height);
	this.radius = random(max_radius) + 10;
	this.alph = floor(random(255));

	this.linecol = color(floor(random(255)), floor(random(255)), floor(random(255)));
	this.fillcol = color(floor(random(255)), floor(random(255)), floor(random(255)));
	
    this.xmove = random(10) - 5;
	this.ymove = random(10) - 5;

	this.drawMe = function() {
		noStroke();
		fill(this.fillcol);
		ellipse(this.x, this.y, this.radius * 2, this.radius * 2);
		stroke(this.linecol);
		noFill();
		ellipse(this.x, this.y, 10, 10);
	}

	this.updateMe = function() {
		this.x += this.xmove;
		this.y += this.ymove;
		if (this.x > (width + this.radius)) {this.x = 0 - this.radius;}
		if (this.x < (0 - this.radius)) {this.x = width + this.radius;}
		if (this.y > (height + this.radius)) {this.y = 0 - this.radius;}
		if (this.y < (0 - this.radius)) {this.y = height + this.radius;}

		for (var i = 0; i < circs.length; i++) {
			var otherCirc = circs[i];
			if (otherCirc != this) {
				var dis = dist(this.x, this.y, otherCirc.x, otherCirc.y);
				var overlap = dis - this.radius - otherCirc.radius;
				if (overlap < 0){
					var midx;
					var midy;
					
					if (this.x < otherCirc.x){
						midx = this.x + (otherCirc.x - this.x)/2;
					} else {
						midx = otherCirc.x + (this.x - otherCirc.x)/2;
					}
					if (this.y < otherCirc.y){
						midy = this.y + (otherCirc.y - this.y)/2;
					} else {
						midy = otherCirc.y + (this.y - otherCirc.y)/2;
					}
					stroke(0, 100);
					noFill();
					overlap *= -1;
					ellipse(midx, midy, overlap, overlap);
				}
			}
		}
		this.drawMe();
	} //update
} //dCircle
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-6-6_mousereleased_drawcircles_if_overlap_newcircle.jpg')
}

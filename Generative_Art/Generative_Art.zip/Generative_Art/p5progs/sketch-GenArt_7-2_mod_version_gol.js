// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 7-2 mod version gol

// Modified version of listing 7-2 of Generative Art by Pearson
// modifications based on Shiffman's version of Game of Life from
// coding challenges (Coding Train).

// Daniel Shiffman
// http://codingtra.in
// http://patreon.com/codingtrain

// Game of Life (GOL)
// Video: https://youtu.be/FWSR_7kZuYg

function make2DArray(cols, rows) {
	let arr = new Array(cols);
	for (let i = 0; i < arr.length; i++) {
		arr[i] = new Array(rows);
	}
	return arr;
}

let cellArray;
let numX;
let numY;
let cellSize = 10;

function setup() {
	createCanvas(500, 300);
	numX = width / cellSize;
	numY = height / cellSize;

	cellArray = make2DArray(numX, numY);
	for (let i = 0; i < numX; i++) {
		for (let j = 0; j < numY; j++) {
			cellArray[i][j] = int(random(2));
		}
	}
} //end setup

function draw() {
	background(200);
	
	// This section draws the cellArray and cells
	// alive cells (=1) are black and 
	// dead cells (=0) are white

	for (let i = 0; i < numX; i++) {
		for (let j = 0; j < numY; j++) {
			let x = i * cellSize;
			let y = j * cellSize;
			stroke(0);
			if (cellArray[i][j] == 1) {
 		       fill(0);
			} else {
 		       fill(255);
			}
			ellipse(x,y,cellSize,cellSize);
		}
	}

	let nextState = make2DArray(numX, numY);

	// Compute next based on cellArray
	for (let i = 0; i < numX; i++) {
		for (let j = 0; j < numY; j++) {
			let state = cellArray[i][j];
			// Count live neighbors!
			//let sum = 0;

			let liveCount = countNeighbors(cellArray, i, j);

			// In this version of GOL there are 2 rules:
			// Rule 1. if a live (black) cell (= 1 or true)
			// has 2 or 3 neighbors, it continues to live.
			// Otherwise it dies.
			//
			// Rule 2. if a dead (white) cell (=0 or false)
			// has 3 neighbors it is brought back to life.
			// Otherwise is remains dead.

			if (state == 1) {
				if ((liveCount == 2) || (liveCount == 3)){
					nextState[i][j] = 1;
				} else {
					nextState[i][j] = 0;
				}
			} else { // state == 0
				if (liveCount == 3){
					nextState[i][j] = 1;
				} else {
					nextState[i][j] = 0;
				}
			}
    	}
	}
	cellArray = nextState;
} //end draw

function countNeighbors(cellArray, x, y) {
	let sum = 0;
	for (let i = -1; i < 2; i++) {
		for (let j = -1; j < 2; j++) {
			let col = (x + i + numX) % numX;
			let row = (y + j + numY) % numY;
			sum += cellArray[col][row];
		}
	}
	sum -= cellArray[x][y]; // this subtracts the value of the current state from neighbor count
	return sum;
}

// this restarts the game
function mousePressed(){
	cellArray = make2DArray(numX, numY);
	for (let i = 0; i < numX; i++) {
		for (let j = 0; j < numY; j++) {
		cellArray[i][j] = floor(random(2));
		}
	}
}// end mousePressed

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-7-2_mod_version_gol.jpg')
}

// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 4-2 reg circle and spiral

function setup() {
	createCanvas(500,300);
	background(255);
	strokeWeight(5);
	smooth();

	var radius = 100;
	var centX = 250;
	var centY = 150;

	stroke(0, 30);
	noFill();
	ellipse(centX,centY,radius*2,radius*2);

	stroke(20, 50, 70);
	radius = 10;		
	var x, y;
	var lastx = -999;
	var lasty = -999;
	for (var ang = 0; ang <= 1440; ang += 5) {	
	  radius += 0.5;
	  var rad = radians(ang);
	  x = centX + (radius * cos(rad));
	  y = centY + (radius * sin(rad));
	  if (lastx > -999) {
	    line(x,y,lastx,lasty);
	  }
	  lastx = x;
	  lasty = y;  
	}
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-4-2_reg_circle_and_spiral.jpg')
}

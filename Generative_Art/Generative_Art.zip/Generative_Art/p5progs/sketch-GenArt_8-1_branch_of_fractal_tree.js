// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 8-1 branch of fractal tree

var numChildren = 3; 	// limit on number of branches
var maxLevels = 3;  	// the maximum depth
var trunk;    	// the trunk of our fractal "tree"

function setup() {
  createCanvas(750,500);
  background(255);
  noFill();
  smooth();
  newTree();
}

function newTree() {
  trunk = new Branch(1, 0, width/2, 50);
  trunk.drawMe();
}

// ======================= Branch object
function Branch(lev, ind, ex, why){
   this.level = lev; 
   this.index = ind;
   this.x = ex;
   this.y = why;
   this.endx = this.x + 150;
   this.endy = this.y + 15;
  
   this.drawMe = function() { 
    	line(this.x, this.y, this.endx, this.endy); 
    	ellipse(this.x, this.y, 5, 5);
  } 
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-8-1_branch_of_fractal_tree.jpg')
}

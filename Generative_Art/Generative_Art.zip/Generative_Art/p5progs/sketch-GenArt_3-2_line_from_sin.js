// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 3-2 line from sin

function setup(){
	createCanvas(500,100);
	background(255);
	strokeWeight(5);
	smooth();
}
function draw(){
	stroke(0, 30);
	line(20,50,480,50);

	stroke(20, 50, 70);
	var xstep = 1;
	var lastx = -999;
	var lasty = -999;
	var angle = 0;
	var y = 50;
	for (var x=20; x<=480; x+=xstep) {
	  var rad = radians(angle);
	  y = 50 + (sin(rad) * 40);  
	  if (lastx > -999) {
	    line(x, y, lastx, lasty);
	  }
	  lastx = x;
	  lasty = y;
	  angle++;
	}
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-3-2_line_from_sin.jpg')
}

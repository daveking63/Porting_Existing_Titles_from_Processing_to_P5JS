// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 6-3 mousereleased drawcircles as objects 2

var _num = 10;
var circ;	

function setup() {
  createCanvas(500,300);
  background(255);
  smooth();
  strokeWeight(1);
  fill(150, 50);
  circ = new dCircle();
  drawCircles();
}

function draw() {
  // do nothing
}

function mouseReleased() {
  drawCircles();    
}

function drawCircles() {
  for (var i=0; i<_num; i++) { 
  		circ = new dCircle();
  		circ.display();	
  }
}

//=== Circle Object

function dCircle() {

    this.x = random(width);
    this.y = random(height);
    this.radius = random(100) + 10; 
    
    this.linecol = color(random(255), random(255), random(255));
    this.fillcol = color(random(255), random(255), random(255), random(255));
    
    this.display = function(){
    	noStroke();
    	fill(this.fillcol);
    	ellipse(this.x, this.y, this.radius*2, this.radius*2);
    	stroke(this.linecol, 150);
    	noFill();
    	ellipse(this.x, this.y, 10, 10);
      }				
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-6-3_mousereleased_drawcircles_as_objects_2.jpg')
}

// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 5-5 2D noise from 3D perspective

var xstart, xnoise, ystart, ynoise;

function setup() {
  createCanvas(500, 300, WEBGL);
  background(0);
  noStroke();

  xstart = random(10);
  ystart = random(10);
}

function draw () {
  
  background(0);
  translate(-width/2, -height/2, 0);	

  xstart += 0.01;  	
  ystart += 0.01;
  
  xnoise = xstart;
  ynoise = ystart;
  
  for (var y = 0; y <= height; y+=5) {
    ynoise += 0.1;
    xnoise = xstart;
    for (var x = 0; x <= width; x+=5) {
      xnoise += 0.1;
      drawPoint(x, y, noise(xnoise, ynoise));
    }
  } 
}

function drawPoint(x, y, noiseFactor) {
  push();
	  translate(x, 250 - y, -y);
	  //translate(-x/2, 100-y, y/2)
	  var sphereSize = noiseFactor * 35;
	  var grey = 150 + (noiseFactor * 120);
	  var alph = 150 + (noiseFactor * 120);
	  var sDetail = 16
	  fill(grey, alph);
	  sphere(sphereSize, sDetail, sDetail);
  pop();
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-5-5_2D_noise_from_3D_perspective.jpg')
}

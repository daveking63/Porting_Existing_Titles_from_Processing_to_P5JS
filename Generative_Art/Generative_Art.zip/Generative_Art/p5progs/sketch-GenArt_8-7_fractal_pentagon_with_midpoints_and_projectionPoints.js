// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 8-7 fractal pentagon with midpoints and projectionPoints

var pentagon;
var maxlevels = 5;
var strutFactor = 0.2;

function setup() {
    createCanvas(750, 500); //originally 1000 x 1000
    smooth();
    pentagon = new FractalRoot();
    pentagon.drawShape();
}

function PointObj(ex, why) {
     this.x = ex;
     this.y = why;
}

function FractalRoot() {
      this.centX = width/2;
      this.centY = height/2;
      this.count = 0;
	  this.pointArr = [];
	
      for (var i = 0; i<360; i+=72) {
          this.x = this.centX + (150 * cos(radians(i))); //originally 400
          this.y = this.centY + (150 * sin(radians(i))); //originally 400
          this.pointArr[this.count] = new PointObj(this.x, this.y);
          this.count++;
      }
      
      this.rootBranch = new Branch(0, 0, this.pointArr);

	  this.drawShape = function() {
		  this.rootBranch.drawMe();
	  }
}

function Branch(lev, n, points) {
    this.level = lev;
    this.num = n;
    this.outerPoints = points;
    this.midPoints = [];
    this.projPoints = [];
    var mx, my;
    
    for (var i = 0; i < this.outerPoints.length; i++) {
        this.nexti = i+1;
        if (this.nexti == this.outerPoints.length) { this.nexti = 0; }
        var end1 = this.outerPoints[i]
        var end2 = this.outerPoints[this.nexti];
        if (end1.x > end2.x) {mx = end2.x + ((end1.x - end2.x)/2);}
        else {mx = end1.x + ((end2.x - end1.x)/2);}
        if (end1.y > end2.y) {my = end2.y + ((end1.y - end2.y)/2);}
        else {my = end1.y + ((end2.y - end1.y)/2);}      
        this.midPoints[i] = new PointObj(mx, my);
     }
     // calculate strutPoint
     for (var i = 0; i < this.midPoints.length; i++) {
     	 this.nexti = i+3;
         if (this.nexti >= this.midPoints.length) {this.nexti -= this.midPoints.length; }
		 
		 mp = this.midPoints[i]; 
		 op = this.outerPoints[this.nexti];

         if (op.x > mp.x) {opp = op.x - mp.x;}	
	     else {opp = mp.x - op.x;}
	     if (op.y > mp.y) {adj = op.y - mp.y;} 
         else {adj = mp.y - op.y;}	
	     if (op.x > mp.x) {px = mp.x + (opp * strutFactor);} 
		 else {px = mp.x - (opp * strutFactor);}				
    	 if (op.y > mp.y) {py = mp.y + (adj * strutFactor);}
    	 else {py = mp.y - (adj * strutFactor);} 
     	 
     	 var strutP	= new PointObj(px, py);
		 this.projPoints[i] = strutP;
	 }

  	this.drawMe = function() {
    	// draw outer shape
    	for (var i = 0; i < this.outerPoints.length; i++) {
    		strokeWeight(5 - this.level);
            this.nexti = i+1;
		    if (this.nexti == this.outerPoints.length) { this.nexti = 0; }
    	        line(this.outerPoints[i].x, this.outerPoints[i].y, this.outerPoints[this.nexti].x, this.outerPoints[this.nexti].y);
   		 
   		 // draw midpoints
         for (var j = 0; j < this.midPoints.length; j++) {
         	 strokeWeight(0.5);
             fill(255, 150);   
             ellipse(this.midPoints[j].x, this.midPoints[j].y, 7, 7); //originally 7 was 15
             line(this.midPoints[j].x, this.midPoints[j].y, this.projPoints[j].x, this.projPoints[j].y);
             ellipse(this.projPoints[j].x, this.projPoints[j].y, 7, 7);
         }
      }
   }
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-8-7_fractal_pentagon_with_midpoints_and_projectionPoints.jpg')
}

// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 5-7 3D rotating spiral

var radius = 100;

function setup() {
  createCanvas(500, 300, WEBGL);
  background(0);
  stroke(255);
} 
  
function draw() {
  background(0);
  
  //translate(width/2, height/2, 0);	
  rotateY(frameCount * 0.03);
  rotateX(frameCount * 0.04);
  
  var s = 0;
  var t = 0;
  var lastx = 0; 
  var lasty = 0;
  var lastz = 0;
  while (t < 180) {
     s += 18;  
     t += 1;   
     var radianS = radians(s);
     var radianT = radians(t);
     
     var thisx = 0 + (radius * cos(radianS) * sin(radianT));
     var thisy = 0 + (radius * sin(radianS) * sin(radianT));
     var thisz = 0 + (radius * cos(radianT));
     
     if (lastx != 0) {
        line(thisx, thisy, thisz, lastx, lasty, lastz);
     }
     lastx = thisx; 
     lasty = thisy; 
     lastz = thisz;
  }
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-5-7_3D_rotating_spiral.jpg')
}

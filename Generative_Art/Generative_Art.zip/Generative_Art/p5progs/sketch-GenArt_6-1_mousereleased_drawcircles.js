// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 6-1 mousereleased drawcircles

var _num = 10;

function setup() {
  createCanvas(500,300);
  background(255);
  smooth();
  strokeWeight(1);
  fill(150, 50);
  drawCircles();
 }

function draw() {

}

function mouseReleased(){
	drawCircles();
}

function drawCircles() {
 for (var i=0; i<_num; i++) {
  var x = random(width);
  var y = random(height);
  var radius = random(100) + 10;
  noStroke();
  ellipse(x, y, radius*2, radius*2);
  stroke(0, 150);
  ellipse(x, y, 10, 10);
 }
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-6-1_mousereleased_drawcircles.jpg')
}

// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 8-3 exponential fractal mass

var numChildren = 5; //originally 7
var maxLevels = 5; //originally 7
var maxLen = 300; //originally 500
var ellipRadDiv = 18; //originally 12
var strokeBase = 10; //originally 10
var trunk;

function setup() {
    createCanvas(750, 500);
	background(255);
	noFill();
	smooth();
	newTree();
}

function draw() {
	background(255);
    trunk.updateMe(width/2,height/2);
	trunk.drawMe();
}

function newTree(){
    trunk = new Branch(1, 0, width/2, height/2);
	trunk.drawMe();
}

function Branch(lev, ind, ex, why){
	 this.level = lev; 
	this.index = ind;
	this.strokeW = (1/this.level) * strokeBase;
	this.alph = 255 / this.level;
	this.len = (1/this.level) * random(maxLen);
	this.rot = random(360);
	this.lenChange = random(10) - 5;
	this.rotChange = random(10) - 5;
	
	this.children = [];
	if(this.level < maxLevels){
		for (var i=0; i < numChildren; i++){
			this.children[i] = new Branch(this.level + 1, this.x, this.endx, this.endy);
		}
	 }

	 this.updateMe = function(ex, why){
		this.x = ex;
		this.y = why;

		this.rot += this.rotChange;		
		if (this.rot > 360) {this.rot = 0; }		
		else if (this.rot < 0) {this.rot = 360; }	

		this.len -= this.lenChange;		
		if (this.len < 0) {this.lenChange *= -1; }		
		else if (this.len > maxLen) {this.lenChange *= -1; }	

		this.radian = radians(this.rot);	
		this.endx = this.x + (this.len * cos(this.radian));	
		this.endy = this.y + (this.len * sin(this.radian));

		 for (var i=0; i < this.children.length; i++){
			 this.children[i].updateMe(this.endx, this.endy);
		 }
	 }

	 this.drawMe = function(){
		 strokeWeight(this.strokeW);
		 stroke(0,this.alph);
		 line(this.x, this.y, this.endx, this.endy);
		 ellipse(this.endx, this.endy, this.len/ellipRadDiv, this.len/ellipRadDiv);

	   	 for(var i=0; i < this.children.length; i++){
			 this.children[i].drawMe(this.endx, this.endy);
		 }
	 }
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-8-3_exponential_fractal_mass.jpg')
}

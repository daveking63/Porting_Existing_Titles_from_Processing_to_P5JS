// Source: Generative Art: A Practical Guide Using Processing
// Artist: Matt Pearson
// SourceType: book - rewrite of .pde code at https://www.manning.com/downloads/1117
// Date: 2011
// Description: GenArt 8-8B fractal pentagon all levels recursion without objects

let strutFactor = 0.05; //originally 2
let strutNoise = 0;
let maxLevels = 8;
let currentLevel = 0;
let sides = 5;
let radius = 150;

function setup() {
	createCanvas(750, 500);
	background(255);
	stroke(0);
	strokeWeight(2);
	let outerPoints = [];
	let centX = width/2;
	let centY = height/2;
	let angle = 360/sides;
	let count = 0;
	
	for (let i = 0; i < 360; i += angle){
		let sx = centX + (radius * cos(radians(i))); 
		let sy = centY + (radius * sin(radians(i)));
		outerPoints[count] = createVector(sx, sy);
		count++;
	}
	
	outerPoints[count] = outerPoints[0];	
	polygon(outerPoints);
	
}

function draw() {

}

function polygon(oPoints) {

	var op, mp, px, py;
	var nexti;
	var adj, opp;
	var midPoints = [];
	var projPoints = [];

	let end1 = new p5.Vector(0, 0);
	let end2 = new p5.Vector(0, 0);

	let pLen = oPoints.length;

	// plot outerPoints of polygon
	push();
	strokeWeight(2); 
	stroke(0);
	beginShape();
		for (let i = 0; i < pLen; i++){
			let sx = oPoints[i].x; 
			let sy = oPoints[i].y;
			vertex(sx, sy);}
	endShape(CLOSE);
	pop();

	//create and plot midPoints between ends of an outerpoint
	for (let i = 0; i < pLen; i++){
		let j = i + 1;
		if(j == pLen){j = 0;}
		end1 = oPoints[i].copy();
		end2 = oPoints[j].copy();
		midPoints[i] = end1.add(end2).div(2);
		push();
		stroke(150);
		strokeWeight(1);
		ellipse(midPoints[i].x,midPoints[i].y, 7, 7);
		pop();
	}

	// calculate strut and projection points
	//let mpLen = midPoints.length - 1;
	mpLen = sides;
	console.log('mpLen ' + mpLen);
	for (var i = 0; i < mpLen; i++) {
		nexti = i+3;
		if (nexti >= mpLen) { nexti -= mpLen; }
		console.log(i + ' ' + nexti);
    mp = midPoints[i];
    op = oPoints[nexti];

	if (op.x > mp.x) {opp = op.x - mp.x;} 
	else {opp = mp.x - op.x;}
	if (op.y > mp.y) {adj = op.y - mp.y;}
	else {adj = mp.y - op.y;}
	if (op.x > mp.x) {px = mp.x + (opp * strutFactor);}
	else {px = mp.x - (opp * strutFactor);}
	if (op.y > mp.y) {py = mp.y + (adj * strutFactor);}
	else {py = mp.y - (adj * strutFactor);}

	let thisSP = new createVector(px, py); 
	projPoints[i] = thisSP;
	}

	for (var j = 0; j < mpLen; j++) {
		strokeWeight(0.25);//originally 0.5
		fill(255, 150);
		ellipse(midPoints[j].x, midPoints[j].y, 7, 7); //originally 7 was 15
		line(midPoints[j].x, midPoints[j].y, projPoints[j].x, projPoints[j].y);
		ellipse(projPoints[j].x, projPoints[j].y, 7, 7);
	}

	currentLevel++;

	if (currentLevel < maxLevels){
		polygon(projPoints);
	}
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-GenArt-sketch-8-8B_fractal_pentagon_all_levels_recursion_without_objects.jpg')
}

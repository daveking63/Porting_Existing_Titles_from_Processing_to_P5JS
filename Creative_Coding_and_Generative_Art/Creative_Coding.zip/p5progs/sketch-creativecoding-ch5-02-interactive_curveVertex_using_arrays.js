// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// Sketch 5-2.pde, chapter 4-15 No Figure
// Description: Ch 5-02 No Figure Interactive curveVertex() example using arrays

var ax = [] ;  // x-anchor points
var ay = [] ;  // y-anchor points
var N = 5;    // number of anchor points
var isOnAnchor = -1;  // anchor point was selected
var radius = 5;
var curvature = 0;

// gui to control curvature

function setup() {
	createCanvas(600, 600);
	background(255);

	for (var i=0; i < N; i++) {
		ax[i] = random(100, width-100);
		ay[i] = random(100, height-100);
	}
	
	// slider bar for intractive curvature
	slider = createSlider(0, width/2, 0, 0)
	slider.position(40, 40);
	slider.style('width', '80px');
} // setup()

function draw() {
	background(255);
	noFill();
	strokeWeight(4);
	stroke(0);

	curveTightness(curvature);
	// draw curve
	beginShape();
		curveVertex(ax[0], ay[0]); // double inital point
		for (var i=0; i<N; i++) {  // specify all anchor points
			curveVertex(ax[i], ay[i]);
		}
		curveVertex(ax[N-1], ay[N-1]); // double final point
	endShape();

	// draw control/anchor points
	strokeWeight(1);
	fill(255, 127, 0);
	for (var i=0; i<N; i++) {
		ellipse(ax[i], ay[i], radius*2, radius*2);
	}

	sVal = slider.value();
	curvature = map(sVal, 0, width/3, -3, 3);
	
} // draw()

function mouseDragged(){
		
	// detect if mouse is on control/anchor point
	for (var i=0; i<N; i++) {
		if (dist(mouseX, mouseY, ax[i], ay[i]) < radius)
		  isOnAnchor = i;
	}

	// move points
	if (isOnAnchor >=0 && isOnAnchor <N) {
		ax[isOnAnchor] = mouseX;
		ay[isOnAnchor] = mouseY;
	}
} // mouseDragged()
	
function mousePressed(){
	isOnAnchor = -1;
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch5-02-interactive_curveVertex_using_arrays.jpg')
}

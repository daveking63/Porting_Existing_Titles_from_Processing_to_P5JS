// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// quadraticVertex_interactive_example.pde, chapter 4-09 Figure 4.10
// Description: Ch 4-09 Figure 4.10 Interactive quadratic curve..

var ax, ay, cx, cy;
var isOnControl, isOnAnchor;
var radius = 5;

function setup(){
	createCanvas(600, 600);
	cx = random(100, width-100);
	cy = random(100, height-100);
	ax =random(100, width-100);
	ay =  random(100, height-100);
}

function draw(){
	background(255);
	noFill();
	strokeWeight(4);
	stroke(0);

	// draw curve
	beginShape();
		vertex(width/2, height/2);
		quadraticVertex(cx, cy, ax, ay);
	endShape();

	// draw center point
	fill(200);
	strokeWeight(1);
	ellipse(width/2, height/2, radius*2, radius*2);

	// draw connecting handle
	line(cx, cy, ax, ay);

	// draw control point
	fill(0, 0, 255);
	rect(cx-radius, cy-radius, radius*2, radius*2);

	// draw anchor point
	fill(255, 127, 0);
	ellipse(ax, ay, radius*2, radius*2);

	// detect if mouse is on control/anchor point
	if (dist(mouseX, mouseY, ax, ay) < radius) {
		isOnAnchor = true;
	} 
	else if (dist(mouseX, mouseY, cx, cy) < radius) {
		isOnControl = true;
	} 
	else {
		isOnAnchor = isOnControl = false;
	}
}

function mouseDragged(){
  // move points
	if (isOnControl) {
		cx = mouseX;
		cy = mouseY;
	} 
	else if (isOnAnchor) {
		ax = mouseX;
		ay = mouseY;
	}
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch4-09-quadraticVertex_interactive_example.jpg')
}

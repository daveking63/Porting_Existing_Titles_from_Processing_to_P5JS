// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// emergentVoronoi.pde, chapter 9-17 Figure 9.34
// Description: Ch 9-17 Figure 9.34 - A Voronoi diagram drawn with an emergent system.

// emergentVoronoi.pde, chapter 9
// A Voronoi diagram drawn with an emergent system.
// Particles move to get further away from the closest site,
// until they are equidistant to two or more.
// Left mouse click releases one new particle at mouse point
// Right mouse click or any key press resets the entire system

let sites = [];  //PVector[] sites; sites
let ps = [];     // arraylist of particles
let numSites = 10;
let numParticles = 5000;// originally 5000

function setup(){
	createCanvas(800, 800);
	smooth();
	colorMode(HSB, 360, 100, 100);
	for (let i = 0; i < numSites; i++){
		sites[i] = createVector(0,0);
	}
	reset();
} // end setup()

function draw() {
	background(255);
	// draws the sites
	for (let i=0; i < numSites; i++) {
		noStroke();
		fill(70);
		ellipse(sites[i].x, sites[i].y, 20, 20);
	}//for
	
	// draws the particles
	for (let i = ps.length - 1; i >= 0; i--) {
		let p = ps[i];
		p.display();

		if (!p.converge()) {  // if p has not converged
			p.update();
		}

	}//for

} // end draw()

// creates all new randomly placed sites and particles
function reset() {
	
	for (let i = 0; i < sites.length; i++) {
		sites[i] = createVector(random(width), random(height));
	}//for
	
	for (i = 0; i < numParticles; i++) {
		ps[i] = new Particle(random(width), random(height));
	}//for
	
} // end reset()

// left click adds a single particle, right click resets all
function mousePressed() {
	if (mouseButton == LEFT) {
		ps.push(new Particle(mouseX, mouseY));
	}
	else {
		reset();
	}
} // end mousePressed()

// pressing any key resets as well
function keyPressed() {
	reset();
} // end keyPressed()

class Particle {
  constructor(x, y) {
    this.center = createVector(x, y, 0);
	this.radius = 2;

    // green/blue 50% of the time and yellow/gold 50% of the time
    if (random(1) < 0.5) {
		this.c = color(random(170, 190), 70, random(100));
    }//if
    else { 
		this.c = color(random(40, 60), 70, random(100));
    }//else
    
    let i = this.nearestSite();
    let centDup = this.center.copy();
    this.v = createVector(0,0,0);
    this.v = centDup.sub(sites[i]);
    this.v.normalize();
    this.stable = false;

  } //constructor

	display() {
		fill(this.c);//
		ellipse(this.center.x, this.center.y, this.radius*2, this.radius*2);
	} // end display()

  // returns the index of the nearest site, also sets
  // stable to true if the two nearest nodes are equidistant
	nearestSite() {
		// start with first site as nearest and 2nd site as next nearest
		let minDist = this.center.dist(sites[0]);  // calculate distance to the current nearest site
		let minDist2 = this.center.dist(sites[1]); // calculate distance to the current 2nd nearest site
		let minIdx = 0;                                  // index of the current nearest site
		let minIdx2 = 1;                                 // index of the current 2nd nearest site
		for (let i=1; i<sites.length; i++) {
			let d = this.center.dist(sites[i]);
			if (d < minDist) {      // if site[i] is found closer
				minDist2 = minDist;   // swap nearest site as 2nd nearest site
				minIdx2 = minIdx;     // swap site[i] as nearest site
				minDist = d;
				minIdx = i;
			}//if
			else if (d < minDist2) { // if site[i] is between nearest site and 2nd nearest site
				minDist2 = d;          // swap site[i] as 2nd nearest site
				minIdx2 = i;
		  	}//else if
		}//for
	// if equidistant to two nearest sites
		if (minDist2 - minDist < 1) {
			this.stable = true;
		}//if
		return minIdx;
	} // end nearestNode()

	update() {
		this.center.add(this.v);
		let i = this.nearestSite();
		let d = this.center.dist(sites[i]);
		let centDup = this.center.copy();
		this.v = centDup.sub(sites[i]);
		this.v.normalize();
		this.v.mult(2);
		//off the screen, should be removed from ps
		return (this.center.x > width || this.center.x < 0 || this.center.y > height  || this.center.y < 0);
	} // end update()

	converge() {
		return this.stable;
	}//converge
	
} // end class Particle


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-17-emergentVoronoi.jpg')
}

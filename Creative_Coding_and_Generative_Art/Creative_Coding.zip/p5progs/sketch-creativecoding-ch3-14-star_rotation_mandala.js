// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// star_rotation_mandala.pde, chapter 3-14 Figure 3-19
// Description: Ch 3-14 Figure 3.19 star function.


function setup(){
  createCanvas(500, 500); //originally 1000x1000
  translate(width/2, height/2);
  background(0);
  var radOut = height/2.3;
  var radIn = radOut*.5;
  star(8, radIn, radOut);
}

function star(pointCount, innerRadius, outerRadius) {
  var theta = 0.0;
  // point count is 1/2 of total vertex count
  var vertCount = pointCount*2;
  var thetaRot = TWO_PI/vertCount;
  var tempRadius = 0.0;
  var x = 0.0, y = 0.0;

  beginShape();
  for (var i=0; i<pointCount; i++) {
    for (var j=0; j<2; j++) {
      tempRadius = innerRadius;

      // true if j is even
      if (j%2==0) {
        tempRadius = outerRadius;
      }

      x = cos(theta)*tempRadius;
      y = sin(theta)*tempRadius;
      vertex(x, y);
      theta += thetaRot;
    }
  }
  endShape(CLOSE);
} // end star
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch3-14-star_rotation_mandala.jpg')
}

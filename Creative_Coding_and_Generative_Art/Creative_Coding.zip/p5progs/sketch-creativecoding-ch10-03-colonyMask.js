// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// colonyMask.pde, chapter 10-03 Figures 10.2-4
// Description: Ch 10-03 Figures 10.2-4 - Masking to blackout background of an image

let img, msk;

function preload(){
	img = loadImage("data/colony.jpg");
	msk = loadImage("data/mask.jpg");
}

function setup() {
	background(0);
	createCanvas(300,280);
	img.loadPixels();
	msk.loadPixels();
	for (let y=0; y<img.height; y++){
		for (let x=0; x<img.width; x++){
			let c = color(img.get(x,y));
			let c2 = color(msk.get(x,y));
			if (red(c2) + green(c2) + blue(c2) > 600 ){
      	 		msk.set(x,y,c);
      		}
      		else {
        		msk.set(x,y,0);
      		} 
		}
	}
	msk.updatePixels();
	image(msk, 0, 0);
} // end setup

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch10-03-colonyMask.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// filterOpaque.pde, chapter 10-08 Figure 10.14
// Description: Ch 10-08 Figure 10.14 - Demo of the OPAQUE filter

function preload(){
	img = loadImage("data/bmc-logo.png");    // transparent logo
	bg = loadImage("data/brynmawr.png");     // background image
}

function setup() {
  createCanvas(708, 304);
  background(bg);
  image(img, 0, 0); // original
  img.filter(OPAQUE); // opaque
  image(img, width-img.width, 0);
} // end setup()
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch10-08-filterOpaque.jpg')
}

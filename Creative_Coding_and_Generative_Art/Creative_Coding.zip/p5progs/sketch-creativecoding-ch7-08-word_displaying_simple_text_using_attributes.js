// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// sketch_7_5.pde, chapter 7-08 Figure 7.5
// Description: Ch 7-08 Figure 7.2 Displaying simple text using attributes.

var sentence = "A man, a plan, a canal, Panama.";

function setup() {
  createCanvas(400, 100);
  smooth();
} // setup()

function draw() {
  background(200);
  fill(0);
  textSize(24);
  text(sentence, 10, height/2);
  line(10, height/2, 10+textWidth(sentence), height/2);
  
} // draw()


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch7-08-word_displaying_simple_text_using_attributes.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// blending.pde, chapter 10-06 Figures 10.9
// Description: Ch 10-06 Figures 10.9 - Different ways of blending of two images

function preload(){
	src = loadImage("data/Lenna.jpg");        // blending image
	dest = loadImage("data/prinzipal.jpg");   // background image
}
function setup() {

	createCanvas(639, 959);              // size sketch window as background image
	background(dest);                           // load image into background
	blend(src, 0, 0, src.width, src.height, 0, 0, dest.width, dest.height, DARKEST);

	// variations, comment the blend() call above
	//blend(src, 0, 0, dest.width/2, src.height, 0, 0, dest.width/2, src.height, DARKEST);
	//blend(src, 0, 0, src.width, src.height, dest.width/2, 0, dest.width/2, src.height, DARKEST);
	//blend(src, 0, 0, dest.width/2, src.height, 0, height-src.height, dest.width/2, src.height, LIGHTEST);
	//blend(src, 0, 0, src.width, src.height, dest.width/2, height-src.height, dest.width/2, src.height, LIGHTEST);

	// variation with OVERLAY, comment all the blend() calls above
	//let src2 = loadImage("data/brynmawr.png");        // blending image
	//blend(src2, 0, 0, src.width, src.height, 0, 700, width, height-700, OVERLAY);
} // end setup()
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch10-06-blending.jpg')
}

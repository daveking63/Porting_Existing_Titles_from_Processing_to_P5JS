// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// imageMask.pde, chapter 10-04 Figure 10.5
// Description: Ch 10-04 Figure 10.5 - Masking out the sky in an image

function preload(){
	img = loadImage("data/prinzipal.jpg");
}
function setup() {
  createCanvas(1278, 959);  //Twice the width so that we can display the result and the original side by side
  let msk = createImage(639,959); //the mask should be an image the same size as the original
  background(0);
  img.loadPixels();
  msk.loadPixels();
  for (let y=0; y<img.height; y++){
    for (let x=0; x<img.width; x++){
      let c = color(img.get(x,y));	
      if (red(c) + green(c) + blue(c) > 600 || blue(c) > 190) { // cloud or sky
      	 msk.set(x,y,0);
      }
      else {
        msk.set(x,y,c);
      } 
    }
  }
  msk.updatePixels();
  image(img, 0, 0);
  image(msk, img.width, 0);
} // end setup()

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch10-04-imageMask.jpg')
}

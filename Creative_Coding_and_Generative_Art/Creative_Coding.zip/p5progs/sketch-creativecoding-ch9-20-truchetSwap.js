// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// truchetSwap.pde, chapter 9-20 Figure 9.47
// Description: Ch 9-20 Figure 9.47 - Truchet tiling with swapping to maintain pattern/color continuity

let tileSize = 50;
let rows = 20;
let cols = 20;
let tiles = [];  //new Tile[rows][cols];
let ic; // orange
let oc; // blue

function setup() {

	createCanvas(1000, 1000);
	smooth();
	
	let ic = color(200, 100, 0);    // orange
	let oc = color(20, 100, 255);   // blue

	for (let i=0; i < rows; i++) {
		tiles[i] = [];
		for (let j = 0; j < cols; j++) {
			tiles[i][j] = new Tile(j*tileSize, i*tileSize, tileSize, ic, oc);
			colorSwap(i, j);
			tiles[i][j].display();
		}
	}
	// uncomment to draw grid
	//grid();
} // end setup()

// takes the row and column indices of the current tile and decides how to set its swapColor boolean variable
function colorSwap(i, j) {
  if (i > 0 && j == 0) {                                  // first tile of a row, starting from the 2nd row
    if (tiles[i-1][0].orient == tiles[i][0].orient) {     // same orientation as tile directly above
      tiles[i][0].swapColors = !tiles[i-1][0].swapColors; // set to opposite coloring of my neighbor above
    }
    else {
      tiles[i][0].swapColors = tiles[i-1][0].swapColors;  // set to same coloring of my neighbor above
    }
  }
  if (j > 0) {                                            // subsequent tiles in a row, including the first
    if (tiles[i][j-1].orient == tiles[i][j].orient) {
      tiles[i][j].swapColors = !tiles[i][j-1].swapColors; // set to opposite coloring of my neighbor to the left
    }
    else {
      tiles[i][j].swapColors = tiles[i][j-1].swapColors;  // set to same coloring of my neighbor to the left
    }
  }
}//colorswap

function grid() {
	stroke(50);
	for (let i=0; i < rows; i++) {
		line(0, i*tileSize, width, i*tileSize);
	}
	for (let j = 0; j < cols; j++) {
		line(j*tileSize, 0, j*tileSize, height);
	}
}//grid

class Tile {
  constructor(x, y, w, ic, oc) {
    this.x = x;
    this.y = y;
    this.sz = w;
    this.ic = ic;
    this.oc = oc;
    this.orient = randInt(0, 1);  // only two unique orientations
    this.swapColors;
  } //constructor()

  display() {
    push();

    translate(this.x, this.y);
    noStroke();
    if (this.swapColors) {
      fill(this.ic);
    }
    else {
      fill(this.oc);
    }
    rect(0, 0, this.sz, this.sz);

    translate(this.sz/2, this.sz/2);
    rotate(this.orient*PI/2);
    translate(-this.sz/2, -this.sz/2);
    stroke(255);
    strokeWeight(3);
    if (this.swapColors) {
      fill(this.oc);
    }
    else {
      fill(this.ic);
    }
    arc(0, 0, this.sz, this.sz, 0, PI/2);
    arc(this.sz, this.sz, this.sz, this.sz, PI, 3*PI/2);

    pop();
  } // end draw()
} // end class Tile

function randInt(low, high) {
	let r =  floor(random(low, high+1));
	r = constrain(r, low, high);
	return r;
} // end randInt()


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-20-truchetSwap.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// textVideo.pde, chapter 10-16 Figure 10.31
// Description: Ch 10-16 Figure 10.31 - Replacing video frame pixel blocks with squares or ascii text

var vid;
var vScale = 16;

function setup() {
	createCanvas(640, 480);
	pixelDensity(1);
	vid = createCapture(VIDEO);
	vid.size(width/vScale,height/vScale);
	vid.hide();
}

function draw() {
	background(0);
	vid.loadPixels();
	for (var y = 0; y < vid.height; y++) {
		for (var x = 0; x < vid.width; x++) {
			var index = (x + y * vid.width) * 4;
			var r = vid.pixels[index   ]; 
			var g = vid.pixels[index + 1];
			var b = vid.pixels[index + 2];
			c = color(r,g,b);
			fill(c);
			rect(x*vScale, y*vScale, vScale, vScale);
    }
  }
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch10-16-textVideo.jpg')
}

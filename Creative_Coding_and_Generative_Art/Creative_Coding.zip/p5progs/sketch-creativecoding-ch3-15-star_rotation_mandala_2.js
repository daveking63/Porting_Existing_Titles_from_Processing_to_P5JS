// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// star_rotatation_mandala_2.pde, chapter 3-15 Figure 3-20
// Description: Ch 3-15 Figure 3.20 star mandala plot 2.

function setup() {
	createCanvas(500, 500);
	background(0);
	noStroke();
	translate(width/2, height/2);

	var pointCount = 8;
	var steps = 50;
	var outerRadius = width*.5;
	var innerRadiusFactor = .7;
	var innerRadius = outerRadius*innerRadiusFactor;
	var outerRadiusRatio = outerRadius/steps;
	var innerRadiusRatio = innerRadius/steps;
	var shadeRatio = 255.0/steps;
	var rotationRatio = 45.0/steps;

	for (var i=0; i<steps; i++) { 
		stroke(255-shadeRatio*i, 100);
		fill(shadeRatio*i);
		push();
			rotate(rotationRatio*i*PI/180);
			star(pointCount, outerRadius-outerRadiusRatio*i, innerRadius-innerRadiusRatio*i);
		pop();
	}
}

function star(pointCount, innerRadius, outerRadius) {
	var theta = 0.0;
	// point count is 1/2 of total vertex count
	var vertCount = pointCount*2;
	var thetaRot = TWO_PI/vertCount;
	var tempRadius = 0.0;
	var x = 0.0, y = 0.0;

	beginShape();
		for (var i=0; i<pointCount; i++) {
			for (var j=0; j<2; j++) {
				tempRadius = innerRadius;
				// true if j is even
				if (j%2==0) {
					tempRadius = outerRadius;
				}
				x = cos(theta)*tempRadius;
				y = sin(theta)*tempRadius;
				vertex(x, y);
				theta += thetaRot;
			}
		}
	endShape(CLOSE);
} // end star
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch3-15-star_rotation_mandala_2.jpg')
}

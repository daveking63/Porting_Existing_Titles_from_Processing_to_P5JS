// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// video.pde, chapter 10-15 Figure 10.30
// Description: Ch 10-15 Figure 10.30 - capture of video from Web Camera

let vid;

function setup() {
	createCanvas(640,480);
	vid = createCapture(VIDEO);
	vid.hide();	
}

function draw(){
  image(vid, 0, 0);
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch10-15-video.jpg')
}

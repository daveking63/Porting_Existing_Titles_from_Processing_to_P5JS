// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// curveEllipse_page.pde, chapter 4-17 Figure 4.18
// Description: Ch 4-17 Figure 4.18 Examples of closed spline curves.

function setup() {
	createCanvas(800, 800);
	background(0);
	var cols = 10;
	var rows = 10;
	var formWidth = width/cols;
	var formRadius = formWidth/2;
	noFill();
	stroke(255);
	for (var i=0; i<rows; i++) {
		for (var j=0; j<cols; j++) {
			push();
				translate(formRadius+formWidth*j, formRadius+formWidth*i);
				curveEllipse(int(random(3, 25)), random(formRadius*.25, formRadius), random(-30, 30));
			pop();
		}
	}
}

function curveEllipse(pts, radius, tightness) {
	var theta = 0;
	var cx = 0, cy = 0;
	var ax = 0, ay = 0;
	var rot = TWO_PI/pts;

	curveTightness(tightness);
	beginShape();
		for (var i=0; i<pts; i++) {
			// need control before vertex 1 along the ellipse
			if (i==0) {
				cx = cos(theta - rot)*radius;
				cy = sin(theta - rot)*radius;
				ax = cos(theta)*radius;
				ay = sin(theta)*radius;
				curveVertex(cx, cy);
				curveVertex(ax, ay);
			} 
			else {
				ax = cos(theta)*radius;
				ay = sin(theta)*radius;
				curveVertex(ax, ay);
			}
			// close ellipse
			if (i==pts-1) {
				cx = cos(theta + rot)*radius;
				cy = sin(theta + rot)*radius;
				ax = cos(theta + rot*2)*radius;
				ay = sin(theta + rot*2)*radius;
				curveVertex(cx, cy);
				curveVertex(ax, ay);
			}
			theta += rot;
		}
	endShape();
} // end curveEllipse

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch4-17-curveEllipse_page.jpg')
}

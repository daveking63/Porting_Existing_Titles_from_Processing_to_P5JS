// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// imageMosaic.pde, chapter 10-18 Figure 10.34-5
// Description: Ch 10-18 Figure 10.34-5 - Creating an mosaic of an image using a library of small image tiles (icons)

let img;
let tiles; //tiles country flags -- 273 tiles
let tilesAvgRGB = [];
let size = 7; // five in original

function preload(){
	img = loadImage("data/lenna.jpg");
	
	tiles = [];
	for (i = 0; i < 273; i++){
		tileFile = 'data/tiles/Tile' + str(i) + '.png';
		tiles.push(loadImage(tileFile));
	}
}//preload

function setup(){
	pixelDensity(1);
	createCanvas(511,511);
	background(255);
	for (let i = 0; i < tiles.length; i++){
		tilesAvgRGB[i] = calcAvgRGB(tiles[i])
	}//for
	noLoop();
//} //setup

//function draw(){
	img.loadPixels();
	for (let x = 0; x < img.width; x += size){
		for (let y = 0; y < img.height; y += size){
			let c = avgRGB(img, x, y, size);
			if (red(c) + green(c) + blue(c) < 700){
				tileIndx = distColor(c);
				tiles[tileIndx].resize(size,size);
				image(tiles[tileIndx],x,y);
			}//if
		}//for
	}//for
} //draw

function avgRGB(img, x, y, s){
	let r = 0;
	let g = 0; 
	let b = 0;
	for (let i = x; i < x+s; i++){
		for (let j = y; j < y + s; j++){
			let c = color(img.get(i,j));
			r += red(c);
			g += green(c);
			b += blue(c);	
		}//for
	}//for
	r /= s * s;
	g /= s * s;
	b /= s * s;
	return color(r,g,b);
} //avgRGB

function calcAvgRGB(chkTile){
	chkTile.loadPixels();
	let r = 0;
	let g = 0; 
	let b = 0;
	let sx = chkTile.width;
	let sy = chkTile.height;
	for (y = 0; y < sy; y++){
		for (x = 0; x < sx; x++){
			let loc = (x + y * sx) * 4;
			let r1 = chkTile.pixels[loc   ]; 
			let g1 = chkTile.pixels[loc + 1];
			let b1 = chkTile.pixels[loc + 2];
			r += r1;
			g += g1;
			b += b1;	
		}//for
	}//for
	r /= sx * sy;
	g /= sx * sy;
	b /= sx * sy;
	return color(r,g,b);
}//calcAvgRGB

function distColor(c){
	let minDist = 255*3 + 1 //largest distance;
	let minIndx = int(-1);
	for (let i=0; i < tilesAvgRGB.length; i++){
		let cTA = tilesAvgRGB[i];
		let rTA = red(cTA);
		let gTA = green(cTA);
		let bTA = blue(cTA);
		let d = dist(red(c), green(c), blue(c), rTA, gTA, bTA);
		if (d < minDist){
			minDist = d;
			minIndx = i;
		}//if
	}//for
	return minIndx;
}//distColor
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch10-18-imageMosaic.jpg')
}

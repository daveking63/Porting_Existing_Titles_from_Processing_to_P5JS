// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// negative.pde, chapter 9-02 Figure 9.6
// Description: Ch 9-02 Figure 9.6 -  Convert image to the negative


function preload(){
	img = loadImage("data/prinzipal.jpg");
}

function setup() {
	createCanvas(639, 959);
	image(img, 0, 0);
	img.loadPixels();
	for (let x=0; x<img.width; x++) {
		for (let y=0; y<img.height; y++) {
    		let c = color(img.get(x,y));
      		let negColr = color(255-red(c), 255 - green(c), 255-blue(c));  		
    		img.set(x,y,negColr);
     	} //for
 	} //for
	img.updatePixels();
	image(img, 0, 0);
} // end setup()
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-02-negative.jpg')
}

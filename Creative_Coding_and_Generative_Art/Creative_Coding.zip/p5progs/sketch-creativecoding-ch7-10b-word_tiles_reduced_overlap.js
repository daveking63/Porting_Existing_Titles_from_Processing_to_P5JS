// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// sketch_7_10b.pde, chapter 7-04 Figure
// Description: Ch 7-10b Figure Word tiles reduced overlap
// Note: th

var inputTextFile = 'Obama.txt';
var stopWordsFile = 'stopwords.txt';
var stopWordsList = []
var fileContents = [];
var rawText,stopText;
var tokens = [];
var delimiters = " ,./?<>;:'\"[{]}\\|=+-_()*&^%$#@!~";
var table;
// originally 150 -- but has a tendency to go in an infinite 'fitting' loop
// trying to find spot where there is no overlap for some of the words.
var N = 95; 

function preload(){
	textdir = "data/";
	fileContents = loadStrings(textdir + inputTextFile);
	stopWordsFileContents = loadStrings(textdir + stopWordsFile);	
}

function setup(){
	createCanvas(800,800);
	
	//build stopwords list
	stopText = join(stopWordsFileContents, "\n");
	stopWordsList = stopText.split("\n");
	
	// Input and parse text file
	rawText = join(fileContents, " ");
	rawText = rawText.toLowerCase();
	tokens = splitTokens(rawText, delimiters);
	console.log(tokens.length + " tokens found in file: " + inputTextFile);
	
	// Create the word frequency table
	table = new WordFreq(tokens);
	console.log("Max frequency: " + table.maxFreq());
	//table.tabulate(N);
  	table.arrange(N); //create tiles for each word-frequency
} // setup()

function draw() {
  background(255);
  table.display(N);
} // draw()

class WordFreq {	
	// A Frequency table class for Words
	constructor(tokens){
	this.wordFrequency = [];
	this.nonStopWordCnt = 0;
	this.stopWordCnt = 0;
	this.wordTiles = [];
		
		for (var i = 0; i < tokens.length; i++){
			var tok = tokens[i];
			var stopResult = this.isStopWord(tok);
			if (!stopResult){index = this._search(tok, this.wordFrequency);}
			if (!this.isStopWord(tok)){
				var index = this._search(tok, this.wordFrequency);
				if (index == -1){
			    this.wordFrequency.push({word:tok, freq:1});
				}
				else {
					this.wordFrequency[index].freq++;	
				}
			} // if
		}// for
	} // constructor
	
	isStopWord(word){
		for(let i = 0; i < stopWordsList.length; i++){
			if (word == stopWordsList[i]){
				return true;
			}
		}
		return false;	
	} //isStopWord
	
	_search(token, wList){
		var srchTest = -1;
		for (var i = 0; i < wList.length; i ++){
			if (token == wList[i].word){
				srchTest = i;
			}
		}
		return srchTest
	} //_search
	
	tabulate(){
		console.log("There are " + this.N() + " non-stop words.");
		for (var i = 0; i < this.wordFrequency.length; i++){
			console.log(this.wordFrequency[i].word + ' ' + this.wordFrequency[i].freq);
		}
	}//tabulate
	
	arrange(numTilesIncluded) {  // arrange or map the first N tiles in sketch
		var tile1 = this.wordTiles[numTilesIncluded];
		for (var i=0; i < numTilesIncluded; i++) {
			var word = this.wordFrequency[i].word;
			var freq = this.wordFrequency[i].freq;
			this.wordTiles[i] = new WordTile(word, freq);
			this.wordTiles[i].setFontSize();
			this.wordTiles[i].setSize();
			var intersectFlag = true;
			while(intersectFlag){
				var x = random(width-this.wordTiles[i].tileW);
	        	var y = random(this.wordTiles[i].tileH, height);
	        	this.wordTiles[i].setXY(x, y);
				var tile1 = this.wordTiles[i];
				console.log('tile1 ' + i);
				intersectFlag = false;
				for (var j=0; j < i; j++) {
					var tile2 = this.wordTiles[j]
				    console.log('tile2 ' + j);
					// the first tile’s bounding box
				    var left1 = tile1.location.x;
				    var right1 = tile1.location.x + tile1.tileW;
				    var top1 = tile1.location.y - tile1.tileH;
				    var bot1 = tile1.location.y;
					// the second tile’s bounding box
				    var left2 = tile2.location.x;
				    var right2 = left2 + tile2.tileW;
				    var bot2 = tile2.location.y;
				    var top2 = bot2 - tile2.tileH;
	        	    intersectFlag = !(right1 < left2 || left1 > right2 || bot1 < top2 || top1 > bot2); // testing intersection
					if (intersectFlag){
			    		console.log("breaking out");
						break;
					} //if
				} //for
			} //while
		} //for
	} // arrange()
	/*
	intersect(tileNum) { // Is tile i clear of all tiles 0..i-1?
			var iFlag = false;
			console.log("called clear " +  tileNum);
			var tile1 = this.wordTiles[tileNum];
			var iFlag = true;
			for (var i=0; i < tileNum; i++) {
				var tile2 = this.wordTiles[i]
				// the first tile’s bounding box
			    var left1 = tile1.location.x;
			    var right1 = tile1.location.x + tile1.tileW;
			    var top1 = tile1.location.y - tile1.tileH;
			    var bot1 = tile1.location.y;
				// the second tile’s bounding box
			    var left2 = tile2.location.x;
			    var right2 = left2 + tile2.tileW;
			    var bot2 = tile2.location.y;
			    var top2 = bot2 - tile2.tileH;
			    // testing intersection - if true then intersects; false otherwise
			    console.log("comparing T1= "  + tileNum + " T2= " + i);
			    iFlag = !(right1 < left2 || left1 > right2 || bot1 < top2 || top1 > bot2); // testing intersection
				if (iFlag){
			    	console.log("breaking out");
					break;
				}
			} //for
			return iFlag;
    	//} // if
  	} // clear()
  	*/
  
	display(Num) {
	for (var i=0; i < Num; i++) {
		this.wordTiles[i].display();
		}
	}  // display()
	
	N(){
		return this.wordFrequency.length;
	} // N
	
	samples(){
		var k = [];
		for (i = 0; i < this.wordFrequency.length; i++){
			k[i] = this.wordFrequency[i].word;
		}
		return k;	
	} //samples
	
	counts(){
		var v = [];
		for (var i = 0; i < this.wordFrequency.length; i++){
			v[i] = this.wordFrequency[i].freq;
		}
		return v;
	}
	
	maxFreq(){
		var max = this.wordFrequency[0].freq;
		for (var i = 0; i < this.wordFrequency.length - 1; i++){
			for (var j = 1; j < this.wordFrequency.length; j++){
				if (this.wordFrequency[j].freq > max){max = this.wordFrequency[j].freq;}
			} //for
		} //for
		return max;
	} //max
	
	
} // wordFrequency

class WordTile{
  constructor(newWord,newFreq) { // Constructor
  	this.tileWord = newWord;
  	this.tileFreq = newFreq
    this.tileW;
    this.tileH;
    this.tileFS = 24;
    this.setSize();
    this.location = createVector(0, 0);
    this.tileColor = color(0);
  } // WordTile()
  
  setXY (x, y) {
    this.location.x = x;
    this.location.y = y;
  } // setXY()
  
  setFontSize() {
    this.tileFS = map(this.tileFreq, 1, 30, 10, 120);
    this.setSize();
  } // setFontSize()
  
  setSize() {
    textSize(this.tileFS);
    this.tileW = textWidth(this.tileWord);
    this.tileH = textAscent();
  } // setTileSize()
  
  display() {
    fill(this.tileColor);
    textSize(this.tileFS);
    text(this.tileWord, this.location.x, this.location.y);
  } // display()
} // class WordTile
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch7-10b-word_tiles_reduced_overlap.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// polygon_01.pde, chapter 3-08 Figure 3-11
// Description: Ch 3-08 Figure 3.11 Initial Polygon. 

function setup() {
	createCanvas(400, 400);
	background(255);
	fill(100);
	polygon(100.0);
}

function polygon(radius){

	var theta = 0.0;
	var x = 0.0;
	var y = 0.0;

	beginShape();

		// vertex 1
		x = cos(theta)*radius;
		y = sin(theta)*radius;
		vertex(x, y);

		// vertex 2
		theta = theta + PI/1.5;
		x = cos(theta)*radius;
		y = sin(theta)*radius;
		vertex(x, y);

		// vertex 3
		theta = theta + PI/1.5;
		x = cos(theta)*radius;
		y = sin(theta)*radius;
		vertex(x, y);

	endShape(CLOSE);
} // end polygon
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch3-08-polygon_01.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// recursiveTreeTransform.pde, chapter 8-05 Figure 8.17
// Description: Ch 8-05 Figure 8.17 Recursively draws a tree using transformations

function setup() {
	createCanvas(800, 800);
	background(255);
	stroke(156, 171, 61);
	translate(width/2, height);
	drawTree(175, -90);
} // end setup()

function drawTree(len, angle) {
	if (len > 2) {
		rotate(radians(angle));
		line(0, 0, len, 0);
		translate(len, 0);
		
		push();
			drawTree(len*0.75, -30);
		pop();
		
		push();
			drawTree(len*0.66, 50);
		pop();
	}
} // end drawTree()

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch8-05-recursiveTreeTransform.jpg')
}

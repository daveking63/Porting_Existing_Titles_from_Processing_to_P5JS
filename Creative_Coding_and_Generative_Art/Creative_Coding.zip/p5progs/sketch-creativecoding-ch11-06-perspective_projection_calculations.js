// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// perspective_projection_calculations.pde, chapter 11-06 Figure 11.8
// Description: Ch 11-06 No Figure 11.8 - Calculating perspective projection example.

let vecs = []; //new PVector[8];
let vecsLen = 8;

function setup() {
	createCanvas(500, 500);
	background(255);
	strokeWeight(20);
	
	let d = -10.0;
	let theta = -PI/4.0;
	let r = 400.0;
	let z; 
    let zNear = -20.0;
    let zFar = -50.0; //z pos of cube front pts
	z = zNear;
	
	for (let i=0; i<vecsLen; i++) {
	vecs[i] = new createVector(cos(theta)*r, sin(theta)*r, z);
	theta += TWO_PI/4;
		if (i==3) {
			z = zFar; // set z pos of cube back pts
			theta = -PI/4;
		}//if
	}//for
	
	translate(width/2, height/2);
	
	beginShape(POINTS);
		for (let i=0; i<vecs.length; i++) {
			let x = vecs[i].x*(d/vecs[i].z);
			let y = vecs[i].y*(d/vecs[i].z);
			vertex(x, y);
		}
	endShape();
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch11-06-perspective_projection_calculations.jpg')
}

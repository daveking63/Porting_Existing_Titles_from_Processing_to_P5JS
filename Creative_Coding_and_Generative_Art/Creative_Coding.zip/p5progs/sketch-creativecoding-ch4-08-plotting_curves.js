// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// plotting_curves.pde, chapter 4-08 Figure 4.7
// Description: Ch 4-08 Figure 4.7 Quadratic and cubic curve plot example.

function setup() {
	createCanvas(600, 600);
	background(255);
	noFill();
	strokeWeight(4);
	translate(width/2, 0);

	// draw quadratic curve
	var fx2Max = fx2(width/2);
	var fx2Scale = height/fx2Max;

	stroke(0, 0, 255);
	beginShape();
		for (var i=-width/2; i<width/2; i++) {
			vertex(i, fx2(i)*fx2Scale);
		}
	endShape();

	// draw cubic curve
	stroke(255, 127, 0);
	var fx3Max = fx3(width/2);
	var fx3Scale = height/(fx3Max*2);

	beginShape();
		for (var i=-width/2; i<width/2; i++) {
			vertex(i, height/2+fx3(i)*fx3Scale);
		}
	endShape();
}

// quadratic
function fx2(x) {
	return x*x;
}

// cubic
function fx3(x) {
	return x*x*x;
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch4-08-plotting_curves.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// pixelBufferMask.pde, chapter 10-06 Figures 10.6-7
// Description: Ch 10-06 Figures 10.6-7 - Applying the pixel buffer as a mask to an image

function preload(){
	img = loadImage("data/prinzipal.jpg");
}
function setup() {
	createCanvas(639, 959); 
	pixelDensity(1);  //important to set this variable or errors occur
	background(100, 130, 50, 75);
	for (let i=0; i<3000; i++) {
		rect(random(width), random(height), 5+random(20), 5+random(20));
		// circle variation
		//let r = float(5+random(20));
		//noStroke();
		//ellipse(random(width), random(height), r, r);
	} 
	loadPixels();
	img.loadPixels();
	for (let x=0; x<639; x++){
	    for (let y=0; y<959; y++){
			let indx = (x + y * width) * 4;

	    	let r = img.pixels[indx];
	    	let g = img.pixels[indx + 1];
	    	let b = img.pixels[indx +2];
	    	let a = img.pixels[indx + 3];
	    	
	    	let rd = pixels[indx];
	    	let gr = pixels[indx+1];
	    	let bl = pixels[indx+2];
	    	
	        if (rd + gr + bl > 600){
		    	pixels[indx] = r;
		    	pixels[indx+1] = g;
		    	pixels[indx+2] = b;
		    	pixels[indx+3] = a;
	      	}
		}
	}
	updatePixels();
} // end setup()
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch10-05-pixelBufferMask.jpg')
}

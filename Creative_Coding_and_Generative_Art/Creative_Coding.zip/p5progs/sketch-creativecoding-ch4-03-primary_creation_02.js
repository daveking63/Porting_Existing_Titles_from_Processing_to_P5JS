// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// primary_creation_02.pde, chapter 4-03 Figure 4.3
// Description: Ch 4-03 Figure 4.3 Plotting primes using return functions

function setup() {
	createCanvas(800, 600);
	background(0);
	var cols = 400;
	var rows = 300;
	var cellW = width/cols;
	var cellH = height/rows;
	noStroke();
    // no protect
	for (var i=0, k=0; i<rows; i++) {
		for (var j=0; j<cols; j++) {
			push();
				translate(cellW/2+cellW*j, cellH/2+cellH*i);
				if (isPrime(k)) {
					primeCell(cellW, cellH);
				} 
				else {
					compositeCell(cellW, cellH);
				}
			pop();
			k++;
		}
	}
}// end setup


function primeCell(w, h) {
	fill(255, 0, 0);
	ellipse(0, 0, w, h);
} // end primeCell

function compositeCell(w, h) {
	fill(255);
	rect(-w/2, -h/2, w, h);
} // end compositeCell

// return true or false
function isPrime(val) {
  if (val<2) {
    return false;
  } 
  for (var i=2; i<(val+2)/2; i++) {
    if (val%i==0) {
      return false;
    }
  }
  return true;
} // end isPrime

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch4-03-primary_creation_02.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// default_perspective_projection.pde, chapter 11-07 No Figure
// Description: Ch 11-07 No Figure - Default perspective projection example.

function setup() {// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition

	createCanvas(400, 400, WEBGL);
	noFill();
}

function draw() {
	//WEBGL auto translates upper left (0,0) to center of canvas
	//This first translates back so 0,0 is returned to upper left
	translate(-width/2, -height/2, 0);
	background(255);
	translate(width/2, height/2);
	rotateY(frameCount*PI/360.0);
	rotateX(frameCount*PI/720.0);
	box(200);
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch11-07-default_perspective_projection.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// recursiveTree.pde.pde, chapter 8-04 Figure 8-17
// Description: Ch 8-04 Figure 8-17 Recursively draws a tree

function setup() {
	createCanvas(800, 800);
	background(255);
	stroke(156, 171, 61);
	drawTree(width/2, height, 175, 90);
} // end setup()

function drawTree(x0, y0, len, angle) {
	if (len > 2) {
		var x1 = float(x0) + float(cos(radians(angle))*len);
		var y1 = float(y0) - float(sin(radians(angle))*len);

		line(x0, y0, x1, y1);
      
		drawTree(x1, y1, len * 0.75, angle + 30);
		drawTree(x1, y1, len * 0.66, angle - 50);

		// variation 1
		//drawTree(x1, y1, len * 0.75, angle + 10);
		//drawTree(x1, y1, len * 0.66, angle - 50);

		// variation 2
		//change if condition to len > 10
		//drawTree(x1, y1, len * 0.75, angle + 20);
		//drawTree(x1, y1, len * 0.66, angle - 20);
	}
} // end drawTree()
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch8-04-recursiveTree.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// recursive_circles.pde, chapter 8-03 Figure 8-9
// Description: Ch 8-03 Figure 8-9 Recursivesly drawn squares (boxes)

function setup() {
	createCanvas(800, 800);
	background(255);
	rectMode(CENTER);
	noFill();
	stroke(0);
	drawBox(width/2, height/2, width/2);
} // end setup()

// Draw boxes recursively, centered at cx, cy, with size d.
function drawBox(cx, cy, d) {  
	strokeWeight(0.05*d);
	stroke(d, 0, d/2);

	rect(cx, cy, d, d);

	// Base case.
	if (d < 10) return; //originally 20
		drawBox(cx-d/2, cy-d/2, d/2);
		drawBox(cx+d/2, cy-d/2, d/2);
		drawBox(cx-d/2, cy+d/2, d/2);
		drawBox(cx+d/2, cy+d/2, d/2);
} // end drawBoxes()
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch8-03-recursiveBoxes.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// star_rotatation_mandala_3.pde, chapter 3-16 Figure 3-23
// Description: Ch 3-16 Figure 3.23 star mandala plot 3.

function setup() {
	createCanvas(500, 500);
	background(0);
	noStroke();
	translate(width/2, height/2);

	var pointCount = int(random(3, 12));
	var steps = int(random(30, 80));
	var outerRadius = width*random(.3, .6);
	var innerRadiusFactor = random(.2, .9);
	var innerRadius = outerRadius*innerRadiusFactor;
	var outerRadiusRatio = outerRadius/steps;
	var innerRadiusRatio = innerRadius/steps;
	var randCol = random(175, 255);
	var shadeRatio = randCol/steps;
	var rotationRatio = random(25.0, 145.0)/steps;

	for (var i=0; i<steps; i++) { 
		fill(shadeRatio*i);
		stroke(randCol-shadeRatio*i, 100);
		push();
			rotate(rotationRatio*i*PI/180);
			star(pointCount, outerRadius-outerRadiusRatio*i, innerRadius-innerRadiusRatio*i);
		pop();
	}
}

function star(pointCount, innerRadius, outerRadius) {
	var theta = 0.0;
	// point count is 1/2 of total vertex count
	var vertCount = pointCount*2;
	var thetaRot = TWO_PI/vertCount;
	var tempRadius = 0.0;
	var x = 0.0, y = 0.0;

	beginShape();
		for (var i=0; i<pointCount; i++) {
			for (var j=0; j<2; j++) {
				tempRadius = innerRadius;
				// true if j is even
				if (j%2==0) {
					tempRadius = outerRadius;
				}
				x = cos(theta)*tempRadius;
				y = sin(theta)*tempRadius;
				vertex(x, y);
				theta += thetaRot;
			}
		}
	endShape(CLOSE);
} // end star
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch3-16-star_rotation_mandala_3.jpg')
}

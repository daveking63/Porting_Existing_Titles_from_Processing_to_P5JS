// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// Sketch 5-5b.pde, chapter 5-05b No Figure
// Description: Ch 5-05b No Figure Visualizing Time Series (AAPL Stock prices) - Read Data and setup.

var price = [];
var lines;
var pieces, minPrice, maxPrice;
var X1, Y1, X2, Y2;

function preload(){
	// Read the data file...
	lines = loadStrings("data/AAPLStock.txt");
}

function setup() {
	// drawing setup
	createCanvas(600, 400);

	X1 = 50; 
	Y1 = 50;
	X2 = width - 50; 
	Y2 = height - Y1;

	smooth();

	// Parse the needed data
	for (var i=0; i<lines.length; i++) {
		// First split each line using commas as separator
		pieces = split(lines[i], ",");
		// get the closing price of stock
		price[i] = float(pieces[5]);
	}
	console.log("Data Loaded: "+price.length+" entries.");

	// determine min and max stock price for the year
	minPrice = min(price);
	maxPrice = max(price);
	console.log("Min: "+minPrice);
	console.log("Max: "+maxPrice);
} // setup()

function draw() {
	background(0);
	// draw plot bounding box
	rectMode(CORNERS);
	noStroke();
	fill(255);
	rect(X1, Y1, X2, Y2);
} // draw()
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch5-05b-time_series_backdrop_and_read_data.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// sepiaPalette.pde, chapter 9-13 Figure 9.25
// Description: Ch 9-13 Figure 9.25 -  Create and visualize a Sepia palette

let palette = []; //new color[256];
let s = 10;
let r,g,b,rd,gr,bl;

function setup() {

	createCanvas(321, 81);
	// yellow sepia
	r = 255;
	g = 240;
	b = 192;
	// alternative - red sepia: let r = 255; let g = 220; let b = 192

	for (let i=0; i<256; i++) {
		rd = int(r*i/255);
		gr = int(g*i/255);
		bl = int(b*i/255);
        palette[i] = color(rd, gr, bl);
		//print(i,palette[i],rd,gr,bl);
		let x = int(i%32)*s;
		let y = int(i/32)*s;
	    print(i, x, y);
		fill(palette[i]);
		stroke(255,255,255);
		rect(x, y, s, s);
	}//for
}//setup
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-13-sepiaPalatte.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// animated_rectangle_painting.pde, chapter 4-04 Figure 4.4
// Description: Ch 4-04 Figure 4.4 Introducing Processing's draw() function.

function setup(){
  createCanvas(800, 800);
  background(0);
  noFill();
}

function draw(){
  stroke(255, random(255));
  rect(random(width), random(height), random(5, 20), random(5, 20));
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch4-04-animated_rectangular_painting.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// spiral01.pde, chapter 4-01 Figure 4.1
// Description: Ch 4-01 Figure 4.1 Star spiral table plot.

// global variables
var x, y, radius;

function setup(){
	createCanvas(400, 400);
	background(255);
	x = width/2;
	y = height/2;
	radius = width*0.5;

	push();
		translate(x, y);
		var pts = 600;
		var rots = 10;
		var fall_off = 0.992;

		drawSpiral(pts, rots, radius, fall_off);
	pop();

	drawFrame();
} // end Setup

function drawSpiral(pts, rots, radius, fallOff){
	var x = 0;
	var y = 0;
	var theta = 0;
	beginShape();
		for(var i=0; i<pts; i++){
			x = cos(theta)*radius;
			y = sin(theta)*radius;
			vertex(x, y);
			radius*=fallOff;
			theta += TWO_PI*rots/pts;
		}
	endShape();
}// end drawSpiral

function drawFrame(){
	noFill();
	strokeWeight(20);
	rect(x-radius-1, y-radius-1, radius*2, radius*2);
}// end drawFrame
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch4-01-spiral01.jpg')
}

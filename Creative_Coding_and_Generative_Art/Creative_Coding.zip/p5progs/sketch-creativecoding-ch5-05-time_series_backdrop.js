// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// Sketch 5-5.pde, chapter 5-05 No Figure
// Description: Ch 5-05 No Figure Visualizing Time Series (AAPL Stock prices) - Setup.

var price = [];
var X1, Y1, X2, Y2;

function setup() {
	// drawing setup
	createCanvas(600, 400);

	X1 = 50; 
	Y1 = 50;
	X2 = width - 50; 
	Y2 = height - Y1;

	smooth();
} // setup()

function draw() {
  background(0);
  // draw plot bounding box
  rectMode(CORNERS);
  noStroke();
  fill(255);
  rect(X1, Y1, X2, Y2);
} // draw()
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch5-05-time_series_backdrop.jpg')
}

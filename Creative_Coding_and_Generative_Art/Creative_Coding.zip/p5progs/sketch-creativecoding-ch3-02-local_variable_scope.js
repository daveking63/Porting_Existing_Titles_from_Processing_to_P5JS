// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// local_variable_scope.pde, chapter 3-02 - No Figure
// Description: Ch 3-02 Variable scope example.

function setup() {
	// not part of original code - simply for displaying reminder
	createCanvas(400, 300);
	background(225); 
	textSize(15); 
	text("Ch3-2 local_variable: See Console for Output", 30, 150);
	//
	
	let locVar1 = 3;
	print("locVar1 in setup = " + locVar1);

	// nested empty block as an example
	{
		print("locVar1 nested in setup = " + locVar1);

		let locVar2 = 290;
		print("locVar2 nested in setup = " + locVar2);
	}

	// uncommented this will generate an error
	// println("local locVar2 out of scope = " + locVar2);
}

function myFunction() {
	// uncommented these will both generate errors
	// println("local locVar1 out of scope = " + locVar1);
	// println("local locVar2 out of scope = " + locVar2);
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch3-02-local_variable_scope.jpg')
}

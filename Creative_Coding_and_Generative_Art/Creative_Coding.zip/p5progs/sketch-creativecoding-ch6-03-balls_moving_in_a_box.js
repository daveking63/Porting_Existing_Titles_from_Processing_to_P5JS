// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// sketch_6_3.pde, chapter 6-03 Figure 6.11
// Description: Ch 6-03 Figure 6.11 Balls in a box

var b;

function setup() {
  createCanvas(400, 400);
  smooth();
  // Create a 200*200 box with 50 balls
  b = new box(100, 100, 200, 200, 50);
} // setup()

function draw() {
  background(255);
  b.update();
  b.display();
} // draw()

class box{
	constructor(x, y, w, h, n){
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.c = color(255,0,0);
		this.nBalls = n;
		this.ballRadius = 2;
		this.balls = [];
	    // Create balls...
    	for (var i=0; i < this.nBalls; i++) {
      		this.balls[i] = new ball(this.w/2, this.h/2, this.ballRadius, this.c);
    	}
  }
    update(){
		// move each ball...
		for (var i=0; i < this.nBalls; i++) {
			this.balls[i].move();
    	}
    } // update
    display() {
		// draw box
		push();
			translate(this.x, this.y);
			stroke(0);
			fill(255);
			rect(0, 0, this.w, this.h);     
			// draw balls
			for (var i=0; i < this.nBalls; i++) {
				this.balls[i].display();
			}
		pop();
	} // display()    

} // class box

class ball{// Define the ball class
	constructor(x, y, r, c){
		this.location = createVector(x,y);
		this.radius = r;
		this.ballColor = c;
		this.speed = createVector(random(1, 3), random(1, 3));      // The speed at which the ball is moving
 	}
	display(){
		noStroke();
		fill(this.ballColor);
		ellipse(this.location.x, this.location.y, 2*this.radius, 2*this.radius);
	}
	move() {      
		this.location.add(this.speed);  
		this.bounce();
	} //move()
	bounce() {
		if (this.location.x > (b.w-this.radius)) { // bounce against the right edge
			this.location.x = b.h-this.radius;
			this.speed.x = -this.speed.x;
		}
		if (this.location.x < this.radius) { // bounce against the left edge
			this.location.x = this.radius;
			this.speed.x = -this.speed.x;
		}
		if (this.location.y > (b.h-this.radius)) { // bounce against the bottm edge
			this.location.y = b.h-this.radius;
			this.speed.y = -this.speed.y;
		}
		if (this.location.y < this.radius) { // bounce against the top edge
			this.location.y = this.radius;
			this.speed.y = -this.speed.y;
	}
  } // bounce()												
} // class ball
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch6-03-balls_moving_in_a_box.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// sketch_6_2.pde, chapter 6-02 No Figure
// Description: Ch 6-02 No Figure Display 3 red moving ball objects.

var b1, b2, b3;

function setup() {
  createCanvas(400, 400);
  smooth();  
  // create the balls
  b1 = new ball();
  b2 = new ball();
  b3 = new ball();
} // setup()

function draw() {
	background(255);
	// display the balls
	b1.move();
	b1.display();
	b2.move();
	b2.display();
	b3.move();
	b3.display();
} // draw()

class ball {// Define the ball class
	constructor(){
  	  	this.x = random(width);
		this.y = random(height);
		this.radius = 25;
		this.ballColor = color(255, 0, 0);
		this.speed = 5.0;      // The speed at which the ball is moving
		this.gravity = 0.1;    // the rate of increase of speed
		this.dx = 1;           // amount of lateral movement
		this.dampen = -0.9;    // amount of dampening after each bounce
 	}
	display(){
		noStroke();
		fill(this.ballColor);
		ellipse(this.x, this.y, 2*this.radius, 2*this.radius);
	}
	move() {    
		this.x = this.x + this.dx;
		this.y = this.y + this.speed;
		this.speed = this.speed + this.gravity;    
		// check to see if it bounces
		this.bounce();
	} //move()
	bounce(){
	    if (this.x > (width-this.radius)) {   // bounce against the right edge
			this.x = width-this.radius;
			this.dx = -this.dx;
	    }
		if (this.x < this.radius) {   // bounce against the left edge
			this.x = this.radius;
			this.dx = -this.dx;
		}
		if (this.y > (height-this.radius)) {   // bounce against the bottom edge
			this.y = height-this.radius;
			this.speed = this.speed * this.dampen ;
		}
	} // bounce()												
} // class ball

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch6-02-three_red_balls_moving.jpg')
}

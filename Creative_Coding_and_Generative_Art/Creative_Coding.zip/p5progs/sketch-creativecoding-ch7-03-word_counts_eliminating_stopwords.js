// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// sketch_7_3.pde, chapter 7-03 No Figure
// Description: Ch 7-03 No Figure Word frequencies without stop words

var inputTextFile = 'Obama.txt';
var stopWordsFile = 'stopwords.txt';
var fileContents = [];
var rawText,stopText;
var tokens = [];
var wordFrequency = {};
var keys = [];
var delimiters = " ,./?<>;:'\"[{]}\\|=+-_()*&^%$#@!~";
var wCnt = 0;

function preload(){
	textdir = "data/";
	fileContents = loadStrings(textdir + inputTextFile);
	stopWordsFileContents = loadStrings(textdir + stopWordsFile);	
}

function setup(){
	
	// not part of original code - simply for displaying reminder
	createCanvas(400, 300);
	background(225);
	textSize(15); 
	text("Ch7-03 no stop words: See Console for Output", 30, 150);
	//
	
	//build stopwords list
	stopText = join(stopWordsFileContents, "\n");
	var stopWordsList = stopText.split("\n");
	// Input and parse text file
	rawText = join(fileContents, " ");
	rawText = rawText.toLowerCase();
	tokens = splitTokens(rawText, delimiters);
	
	for (var i = 0; i < tokens.length ; i++){
		var word = tokens[i];
		stopResult = search(word,stopWordsList);
		if (stopResult == -1){
			sResult = search(word,keys);
			if (sResult == -1){
				keys.push(word);
				wordFrequency[word] = 1
			}
			else {
				wordFrequency[word] = wordFrequency[word] + 1;
			}
		}
	}
	console.log('There were ' + keys.length + ' words');
	for (var i=0; i < keys.length ; i++) { // 
		var key = keys[i];
		if (wordFrequency != undefined){
			console.log(key + ' ' + wordFrequency[key]);
		}
	}
}

function search(sWord,wordList){
	var found = -1;
	for (var i=0; i < wordList.length; i++){
		if(sWord === wordList[i]){
			found = i;
			break;
		}
	}
	return found;
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch7-03-word_counts_eliminating_stopwords.jpg')
}

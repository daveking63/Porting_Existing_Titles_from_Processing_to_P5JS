// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// sepia.pde, chapter 9-14 Figure 9.27
// Description: Ch 9-14 Figure 9.27 -  Convert image to sepia tone


function preload(){
	img = loadImage("data/lenna.jpg");
}

function setup(){
	createCanvas(639, 959);
	image(img, 0, 0);
	img.loadPixels();
	for (let x=0; x<img.width; x++) {
		for (let y=0; y<img.height; y++) {
    		let c = color(img.get(x,y));
			let r = red(c)*0.393+green(c)*0.769+blue(c)*0.189;
			let g = red(c)*0.349+green(c)*0.686+blue(c)*0.168;
			let b = red(c)*0.272+green(c)*0.534+blue(c)*0.131;
      		let sepiaColr = color(r, g, b);  		
    		img.set(x,y,sepiaColr);
     	} //for
 	} //for
	img.updatePixels();
	image(img, 0, 0);
} // end setup()

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-14-sepia.jpg')
}

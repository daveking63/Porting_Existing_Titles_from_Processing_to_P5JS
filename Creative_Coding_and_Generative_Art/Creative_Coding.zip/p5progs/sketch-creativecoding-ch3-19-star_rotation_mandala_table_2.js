// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// star_rotatation_mandala_table2.pde, chapter 3-19 Figure 3-25
// Description: Ch 3-19 Figure 3.25 Star spiral table2 plot.

function setup() {
  createCanvas(1000, 1000);
  background(255);
  strokeWeight(3);
  //presets
  var cols = 4;
  var rows = 4;
  var outerRadius = width/cols;
  
  // randomly generated
  var pointCount;
  var steps;
  var innerRadius;
  var outerRadiusRatio;
  var innerRadiusRatio;
  var shadeRatio;
  var rotationRatio;
  
  translate(outerRadius/2, outerRadius/2);
  for (var i=0; i<cols; i++) {
    for (var j=0; j<rows; j++) {
      pointCount = int(random(5, 15));
      steps = int(random(4, 15));
      innerRadius = outerRadius*random(.3, .9);
      outerRadiusRatio = outerRadius/steps;
      innerRadiusRatio = innerRadius/steps;
      var randCol = random(225, 255);
      shadeRatio = randCol/steps;
      rotationRatio = random(90, 200)/steps;
      push();
      translate(outerRadius*i, outerRadius*j);
      
      strokeWeight(1);
      rect(-outerRadius/2, -outerRadius/2, outerRadius, outerRadius);
      
      strokeWeight(4);
      for (var k=0; k<steps; k++) { 
        if (k%int(random(1, 6))==0) {
          stroke(0, 255);
        } 
        else {
          stroke(0, 255);
          //noStroke();
        }
        //fill(randCol-shadeRatio*k);
        noFill();
        push();
        scale(.4);
        rotate(rotationRatio*k*PI/180);
        star(pointCount, outerRadius-outerRadiusRatio*k, innerRadius-innerRadiusRatio*k);
        pop();
      }
      pop();
    }
  }
}

function star(pointCount, innerRadius, outerRadius) {
	var theta = 0.0;
	// point count is 1/2 of total vertex count
	var vertCount = pointCount*2;
	var thetaRot = TWO_PI/vertCount;
	var tempRadius = 0.0;
	var x = 0.0, y = 0.0;

	beginShape();
		for (var i=0; i<pointCount; i++) {
			for (var j=0; j<2; j++) {
				tempRadius = innerRadius;
				// true if j is even
				if (j%2==0) {
					tempRadius = outerRadius;
				}
				x = cos(theta)*tempRadius;
				y = sin(theta)*tempRadius;
				vertex(x, y);
				theta += thetaRot;
			}
		}
	endShape(CLOSE);
} // end star
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch3-19-star_rotation_mandala_table_2.jpg')
}

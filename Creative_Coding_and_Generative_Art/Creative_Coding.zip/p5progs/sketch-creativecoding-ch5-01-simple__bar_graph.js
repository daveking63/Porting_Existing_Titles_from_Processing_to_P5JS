// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// sketch_5_1.pde, chapter 5-01 Figure 5.3
// Description: Ch 5-01 Figure 5.3 A Simple Bar Graph

var energySource = ["Petroleum", "Coal", "Natural Gas", "Nuclear", "Renewable", "Hydropower"];
var consumption = [40.0, 23.0, 22.0, 8.0, 4.0, 3.0];

function setup() {
	createCanvas(400, 400);
	smooth();
} // setup()

function draw() {
	// set up plot dimensions relative to screen size
	var x = width*0.1;
	var y = height*0.9;
	var delta = width*0.8/consumption.length;
	var w = delta*0.8;

	background(255);

	for (i = 0; i < consumption.length; i++) {
		// draw the bar for ith data value
		// first compute the height of the bar relative to sketch window
		var cVal = consumption[i];
		var h = map(cVal, 0, 100, 0, height); 
		fill(0);
		rect(x, y-h, w, h);
		x = x + delta;
	}
} // draw()
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch5-01-simple__bar_graph.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// simple_house2.pde, Ch2-01 No Figure - Simple house drawing simulating perspective.2
// Description: Ch 2-01 No Figure - Simple house drawing simulating perspective.
function setup(){
	createCanvas(400, 600);
	// house
	rect(50, 250, 300, 300);
	// roof
	triangle(50, 250, 350, 250, 200, 50);
	// door
	rect(175, 450, 50, 100);
	// door knob
	ellipse(185, 515, 6, 6);
	// left windows
	rect(85, 300, 40, 40);
	rect(130, 300, 40, 40);
	rect(85, 345, 40, 40);
	rect(130, 345, 40, 40);
	// right windows
	rect(230, 300, 40, 40);
	rect(275, 300, 40, 40);
	rect(230, 345, 40, 40);
	rect(275, 345, 40, 40);
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch2-01-simple_house.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// pointillism.pde, chapter 10-14 Figures 10.27
// Description: Ch 10-14 Figures 10.27 -  Simulation of the pointillism effect by drawing many randomly sampled small dots

function preload(){
	img = loadImage("data/pembroke.jpg");  
}

function setup() {
	createCanvas(604, 446);   
	image(img, 0, 0);
	noStroke();
	img.loadPixels();

	//cover with random circles
	for (let i=0; i<10000; i++) {
			let x = int(random(width));
			let y = int(random(height));
			let c = color(img.get(x,y))
            //canvas randomly filled with ellipses based on underlying pixel colors
			fill(red(c), green(c), blue(c), 100);
			ellipse(x, y, 7, 7); 
	} //for
}//setup

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch10-14-pointillism.jpg')
}

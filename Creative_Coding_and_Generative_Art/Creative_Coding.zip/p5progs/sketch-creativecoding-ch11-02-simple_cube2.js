// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// simple_cube2.pde, chapter 11-02 No Figure
// Description: Ch 11-02 No Figure - P5 box() example2.


// simple_cube2.pde, chapter 11
// Processing's box() example 2.

function setup(){
	createCanvas(600, 600, WEBGL);
	strokeWeight(6);
	//translate(width/2, height/2);
	rotateY(PI/4);
	rotateX(PI/4);
	box(240);
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch11-02-simple_cube2.jpg')
}

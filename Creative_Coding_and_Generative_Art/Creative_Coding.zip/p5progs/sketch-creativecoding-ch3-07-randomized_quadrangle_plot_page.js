// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// randomized_quadrangle_plot_page.pde, chapter 3-07 Figure 3.7
// Description: Ch 3-07 Figure 3.7 Generates a table structure of random quadrangles.

function setup() {
	createCanvas(800, 800);
	background(255);

	var cols = 8;
	var rows = 8;
	var gap = 30;
	var cellW = (width - gap*(cols+1))/cols; // account for gaps on edges and between quads.
	var cellH = (height - gap*(rows+1))/rows; // account for gaps on edges and between quads.
	var jitterFactor = .5/64; //show jitter form 0-.5

	fill(0);

	for (var i=0; i<rows; i++) {
		for (var j=0; j<cols; j++) {
			var totalCounter = i*cols+j;
			plotRandomizedQuad (gap + cellW*j + gap*j, gap + cellH*i + gap*i, cellW, cellH, 
			jitterFactor*totalCounter, jitterFactor*totalCounter);
		}
	}
} // end setup

function plotRandomizedQuad(x, y, w, h, randW, randH){
	var jitterW = w*randW;
	var jitterH = h*randH;
	beginShape();
		vertex(x+random(-jitterW, jitterW), y+random(-jitterH, jitterH));
		vertex(x+random(-jitterW, jitterW), y+h+random(-jitterH, jitterH));
		vertex(x+w+random(-jitterW, jitterW), y+h+random(-jitterH, jitterH));
		vertex(x+w+random(-jitterW, jitterW), y+random(-jitterH, jitterH));
	endShape(CLOSE);
} // end plotRandomizedQuad


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch3-07-randomized_quadrangle_plot_page.jpg')
}

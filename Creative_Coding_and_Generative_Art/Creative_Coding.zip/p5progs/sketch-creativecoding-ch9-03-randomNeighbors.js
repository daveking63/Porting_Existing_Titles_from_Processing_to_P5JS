// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// randomNeighbor.pde, chapter 9-03 Figure 9.8-10
// Description: Ch 9-03 Figure 8-10 - eplacing every pixel with one of its 8 neighbors and itself

function preload(){
	img = loadImage("data/fall.jpg");
}

function setup() {
  createCanvas(658, 439);
  image(img, 0, 0);
} // end setup()

function draw() {
  img.loadPixels;
  for (let y=1; y<img.height-1; y++) {
    for (let x=1; x<img.width-1; x++) {
      let newX = randInt(x-1, x+1);
      let newY = randInt(y-1, y+1);
      img.set(x, y, img.get(newX, newY));
    }
  }
  img.updatePixels();
image(img, 0, 0);
  
} // end draw()

// returns a randomly generated integer between low and high, including low and high
function randInt(low, high) {
  let r =  floor(random(low, high+1));
  //Processing's random(low, high) occasionally returns high,
  //even though the references say it doesn't
  r = constrain(r, low, high);
  return r;
} // end randInt()
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-03-randomNeighbors.jpg')
}

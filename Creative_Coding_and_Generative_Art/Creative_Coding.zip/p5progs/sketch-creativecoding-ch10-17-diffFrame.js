// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// diffFrame.pde, chapter 10-17 Figure 10.32
// Description: Ch 10-17 Figure 10.32 - Display the pixel differences in successive frames in a video

var video;
// Previous Frame
var prevFrame;

function setup() {
  createCanvas(320, 240);
  pixelDensity(1);
  video = createCapture(VIDEO);
  video.size(width, height);
  video.hide();
  // Create an empty image the same size as the video
  prevFrame = createImage(video.width, video.height, RGB);
}

function draw() {
  image(prevFrame, 0, 0);

  loadPixels();
  video.loadPixels();
  prevFrame.loadPixels();
  
  prevFrame.blend(video, 0, 0, width, height, 0, 0, width, height, DIFFERENCE); 
  image(prevFrame, 0, 0);
  prevFrame.copy(video, 0, 0, width, height, 0, 0, width, height);

}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch10-17-diffFrame.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// sketch_7_2.pde, chapter 7-02 No Figure
// Description: Ch 7-02 No Figure Word frequencies

var inputTextFile = 'Obama.txt';
var fileContents = [];
var rawText;
var tokens = [];
var wordFrequency = {};
var keys = [];
var delimiters = " ,./?<>;:'\"[{]}\\|=+-_()*&^%$#@!~";
var wCnt = 0;

function preload(){
	textdir = "data/";
	fileContents = loadStrings(textdir + inputTextFile);	
}

function setup(){
	
    // not part of original code - simply for displaying reminder
	createCanvas(400, 300);
	background(225); 
	textSize(15); 
	text("Ch7-02 word counts: See Console for Output", 30, 150);
	//	
	
// Input and parse text file
	rawText = join(fileContents, " ");
	rawText = rawText.toLowerCase();
	tokens = splitTokens(rawText, delimiters);
	
	for (var i = 0; i < tokens.length ; i++){
		var word = tokens[i];
		sResult = search(word,keys);
		if (sResult == -1){
			keys.push(word);
			wordFrequency[word] = 1
		}
		else {
			wordFrequency[word] = wordFrequency[word] + 1;
		}
	}
	console.log('There were ' + keys.length + ' words');
	for (var i=0; i < keys.length ; i++) { // 
		var key = keys[i];
		if (wordFrequency != undefined){
			console.log(key + ' ' + wordFrequency[key]);
		}
	}
}

function search(sWord,wordList){
	var found = -1;
	for (var i=0; i < wordList.length; i++){
		if(sWord === wordList[i]){
			found = i;
			break;
		}
	}
	return found;
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch7-02-word_counts.jpg')
}

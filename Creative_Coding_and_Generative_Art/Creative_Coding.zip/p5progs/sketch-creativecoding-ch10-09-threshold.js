// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// threshold.pde, chapter 10-09 Figure 10.15
// Description: Ch 10-09 Figure 10.15 - Demo of the THRESHOLD filter

let n = 4; // number of filter values
let imgs = [];

function preload(){
	for (let i = 0; i < n; i++){
		imgs[i] = loadImage("data/woods2.jpg")
    }
}

function setup() {
  createCanvas(1736, 434); // 4 * image width = 4 * 434
  image(imgs[0], 0, 0);
  for (let i=1; i<n; i++) {
    imgs[i].filter(THRESHOLD, i/4.0);
    image(imgs[i], imgs[i].width*i, 0);
  }
} // end setup()
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch10-09-threshold.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// sepiaWithPalette.pde, chapter 9-15 Figure.27
// Description: Ch 9-15 Figure 9.27 - Convert an image to Sepia with a palette

let palette = []; // length of 256
// yellow sepia
let r = 255; let g= 240; let b = 192;
// red sepia - substitute
// let r = 255; let g = 220; let b = 192;
let rd, gr, bl;

function preload(){
	img = loadImage("data/Lenna.jpg");
}

function setup() {

	createCanvas(512, 512); // size of image
	image(img, 0, 0);
	img.loadPixels();
	
	for (let i=0; i<256; i++) {
		rd = int(r*i/255);
		gr = int(g*i/255);
		bl = int(b*i/255);
        palette[i] = color(rd, gr, bl);
	}

	for (let x=0; x<img.width; x++) {
		for (let y=0; y<img.height; y++) {
    		let c = color(img.get(x,y));
      		let gray = int(red(c)*0.299+green(c)*0.587+blue(c)*0.114);  		
    		img.set(x,y,palette[gray]);
     	} //for
 	} //for
	img.updatePixels();
	image(img, 0, 0);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-15-sepiaWithPalette.jpg')
}

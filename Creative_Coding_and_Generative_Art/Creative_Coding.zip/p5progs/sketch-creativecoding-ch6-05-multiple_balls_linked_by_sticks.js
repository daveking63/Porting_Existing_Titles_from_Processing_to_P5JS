// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// sketch_6_5.pde, chapter 6-05 Figure 6.16
// Description: Ch 6-05 Figure 6.16 Multiple balls and sticks

// Allocate the ball and stick arrays
var balls = [];
var sticks = [];
var stickLen = 80;
var nBalls = 10;
var nSticks = nBalls - 1;

function setup() {
	createCanvas(400, 400);
	smooth();
	// create the balls and sticks and link them up
	for (var i=0; i < nBalls; i++) {
		balls[i] = new ball(width/2+stickLen*i, height/2, 10, color(0));
		if (i > 0) {
			sticks[i-1] = new stick(balls[i-1], balls[i]);
		}
	}
} // setup()

function draw() {
	background(255);
	// Animate
	for (var i=0; i < nSticks; i++) {
		sticks[i].update();
		sticks[i].display();
	}
} // draw()

class ball{// Define the ball class
	constructor(x, y, r, c){
		this.location = createVector(x,y);
		this.radius = r;
		this.ballColor = c;
		this.speed = createVector(random(1, 3), random(1, 3));      // The speed at which the ball is moving
 	}
	display(){
		noStroke();
		fill(this.ballColor);
		ellipse(this.location.x, this.location.y, 2*this.radius, 2*this.radius);
	}
	move() {      
		this.location.add(this.speed);  
		this.bounce();
	} //move()
	bounce() {
		if (this.location.x > (width-this.radius)) { // bounce against the right edge
			this.location.x = width-this.radius;
			this.speed.x = -this.speed.x;
		}
		if (this.location.x < this.radius) { // bounce against the left edge
			this.location.x = this.radius;
			this.speed.x = -this.speed.x;
		}
		if (this.location.y > (height-this.radius)) { // bounce against the bottm edge
			this.location.y = height-this.radius;
			this.speed.y = -this.speed.y;
		}
		if (this.location.y < this.radius) { // bounce against the top edge
			this.location.y = this.radius;
			this.speed.y = -this.speed.y;
		}
	} // bounce()												
} // class ball

class stick {
	constructor(b1,b2){
		this.b1 = b1;
		this.b2 = b2;
		//stick length originally labeled r
		this.sLen = float(this.b1.location.dist(this.b2.location));
	}
	display() {
	    // first display the balls
	    this.b1.display();
	    this.b2.display();
   		// display the stick
	    stroke(255, 0, 0);
	    strokeWeight(5);
	    line(this.b1.location.x, this.b1.location.y, this.b2.location.x, this.b2.location.y);
	} // display()
	update() {
		this.b1.move();
		this.b2.move();
		this.constrainLength();
	} // update()
	constrainLength(){
	    var k = 0.1 ;
	    var delta = p5.Vector.sub(this.b2.location,this.b1.location)
	    var deltaLength = delta.mag();
	    var d = ((deltaLength - this.sLen) / deltaLength);
	    this.b1.location.x += delta.x * k * d/2;
	    this.b1.location.y += delta.y * k * d/2;
	    this.b2.location.x -= delta.x * k * d/2;
	    this.b2.location.y -= delta.y * k * d/2;
	} // constrainLength

} // class stick
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch6-05-multiple_balls_linked_by_sticks.jpg')
}

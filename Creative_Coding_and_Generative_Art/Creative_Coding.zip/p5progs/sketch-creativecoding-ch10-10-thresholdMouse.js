// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// thresholdMouse.pde, chapter 10-10 No Figure
// Description: Ch 10-10 No Figure Dynamically applying the THRESHOLD filter according to the mouse y position

let img;

function preload(){
	img = loadImage("data/woods2.jpg")
}

function setup() {
  createCanvas(434, 434);
  image(img, 0, 0);
} // end setup()

function draw(){}

function mouseDragged() {
  let t = float(map(mouseY, 0, height, 0.0, 1.0));
  image(img, 0, 0);
  filter(THRESHOLD, t);
} // end mouseDragged()


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch10-10-thresholdMouse.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// sketch_7_4.pde, chapter 7-04 No Figure
// Description: Ch 7-04 No Figure WordFrequency class

var inputTextFile = 'Obama.txt';
var stopWordsFile = 'stopwords.txt';
var stopWordsList = []
var fileContents = [];
var rawText,stopText;
var tokens = [];
var delimiters = " ,./?<>;:'\"[{]}\\|=+-_()*&^%$#@!~";
var table;

function preload(){
	textdir = "data/";
	fileContents = loadStrings(textdir + inputTextFile);
	stopWordsFileContents = loadStrings(textdir + stopWordsFile);	
}

function setup(){
	
	// not part of original code - simply for displaying reminder
	createCanvas(400, 300);
	background(225); 
	textSize(15); 
	text("Ch7-04 word frequency class: See Console for Output", 30, 150);
	//
	
	//build stopwords list
	stopText = join(stopWordsFileContents, "\n");
	stopWordsList = stopText.split("\n");
	
	// Input and parse text file
	rawText = join(fileContents, " ");
	rawText = rawText.toLowerCase();
	tokens = splitTokens(rawText, delimiters);
	console.log(tokens.length + " tokens found in file: " + inputTextFile);
	
	// Create the word frequency table
	table = new WordFreq(tokens);
	table.tabulate();
	console.log("Max frequency: " + table.maxFreq());
	
} //setup

class WordFreq {	
	// A Frequency table class for Words
	constructor(tokens){
		this.wordFrequency = [];
		this.nonStopWordCnt = 0;
		this.stopWordCnt = 0;
		
		for (var i = 0; i < tokens.length; i++){
			var tok = tokens[i];
			var stopResult = this.isStopWord(tok);
			if (!stopResult){index = this._search(tok, this.wordFrequency);}
			if (!this.isStopWord(tok)){
				var index = this._search(tok, this.wordFrequency);
				if (index == -1){
			    this.wordFrequency.push({word:tok, freq:1});
				}
				else {
					this.wordFrequency[index].freq++;	
				}
			} // if
		}// for
	} // constructor
	
	isStopWord(word){
		for(let i = 0; i < stopWordsList.length; i++){
			if (word == stopWordsList[i]){
				return true;
			}
		}
		return false;	
	} //isStopWord
	
	_search(token, wList){
		var srchTest = -1;
		for (var i = 0; i < wList.length; i ++){
			if (token == wList[i].word){
				srchTest = i;
			}
		}
		return srchTest
	} //_search
	
	tabulate(){
		console.log("There are " + this.N() + " non-stop words.");
		for (var i = 0; i < this.wordFrequency.length; i++){
			console.log(this.wordFrequency[i].word + ' ' + this.wordFrequency[i].freq);
		}
	}
	
	N(){
		return this.wordFrequency.length;
	} // N
	
	samples(){
		var k = [];
		for (i = 0; i < this.wordFrequency.length; i++){
			k[i] = this.wordFrequency[i].word;
		}
		return k;	
	} //samples
	
	counts(){
		var v = [];
		for (var i = 0; i < this.wordFrequency.length; i++){
			v[i] = this.wordFrequency[i].freq;
		}
		return v;
	}
	
	maxFreq(){
		var max = this.wordFrequency[0].freq;
		for (var i = 0; i < this.wordFrequency.length - 1; i++){
			for (var j = 1; j < this.wordFrequency.length; j++){
				if (this.wordFrequency[j].freq > max){max = this.wordFrequency[j].freq;}
			} //for
		} //for
		return max;
	} //max
	
	
} // wordFrequency
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch7-04-word_frequency_class.jpg')
}

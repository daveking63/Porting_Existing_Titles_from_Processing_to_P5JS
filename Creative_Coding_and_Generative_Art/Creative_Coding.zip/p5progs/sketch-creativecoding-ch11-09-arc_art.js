// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// arc_art.pde, chapter 11-01 No Figure 
// Description: Ch 11-09 No Figure Arc spiral art
// Note: not sure where this fits in the chapter

var arcSp;

function setup() {
	createCanvas(600, 600);
	arcSp = new ArcSpiral(900, 80);
}

function draw() {
	noStroke();
	fill(0, 1);
	rect(-1, -1, width+1, height+1);
	strokeWeight(13);
	translate(width/2, height/2);
	rotate(frameCount*PI/360);
	arcSp.display();
}

//Processing inner class
class ArcSpiral {
	constructor(r, arcCount) { 
		this.r = r;
		this.arcCount = arcCount;
  }

	display() {
		var r2 = this.r;
		var theta = 0;
		fill(255-abs(sin(frameCount*PI/1440)*255));
		stroke(abs(sin(frameCount*PI/1440)*255));
		for (var i=0; i<this.arcCount*2; i++) {
			arc(0, 0, r2, r2, theta, theta+TWO_PI/this.arcCount, CHORD);
			theta += TWO_PI/this.arcCount;
			r2 -= width/this.arcCount;
    }
  }
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch11-09-arc_art.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// ragged.pde, chapter 9-08 Figure 9.19
// Description: Ch 9-08 Figure 9.19 - Demonstration of ragged arrays

var ragged = [];
var arryRows = 10;
var maxLen = 10; // originally 100

function setup() {
	
	// not part of original code - simply for displaying reminder
	createCanvas(400, 300);
	background(225); 
	textSize(15); 
	text("Ch9-08 ragged: See Console for Output", 30, 150);
	//

	  for (var i=0; i<arryRows; i++) {
	    ragged[i] = [];
	    var len = round(random(1,maxLen));
	    for (var j=0; j<len; j++){
	       // simply arbitrary holder -- could be null, zeros, ones, random...
	    	ragged[i][j] = null;
	   }
  }

	for (i=0; i<ragged.length; i++) {
		print(ragged);
	}
  
}  // end setup()

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-08-ragged.jpg')
}

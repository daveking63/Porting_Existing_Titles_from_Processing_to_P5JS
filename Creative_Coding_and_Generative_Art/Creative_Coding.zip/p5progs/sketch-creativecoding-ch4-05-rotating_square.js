// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// rotating_square.pde, chapter 4-045 No figure
// Description: Ch 4-05 No figure - Combining animation and transformations.

// declare global variables
// for moving square
var x, y, w;
var spdX, spdY, theta, rotSpd;

function setup() {
	createCanvas(600, 600);
	// initialize global variables
	x = width/2;
	y = height/2;
	w = 150;
	spdX = 2.1;
	spdY = 1.5;
	rotSpd = PI/180;
	fill(0, 175, 175);
	noStroke();
}

function draw() {
	background(255, 127, 0);
	push();
		translate(x, y);
		rotate(theta);
		rect(-w/2, -w/2, w, w);
	pop();
	x += spdX;
	y += spdY;
	theta += rotSpd;
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch4-05-rotating_square.jpg')
}

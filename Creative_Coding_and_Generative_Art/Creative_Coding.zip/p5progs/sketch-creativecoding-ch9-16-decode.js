// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// decode.pde, chapter 9-16 Figure 9.29
// Description: Ch 9-16 Figure 9.29 - Decodes an encoded image, assuming information stored in least significant 4 bits


var img;
var clearMask = 0xF0F0F0; 

function preload(){
	img = loadImage("data/encoded.png")
}

function setup() {
	createCanvas(658,439);
	image(img, 0, 0);
	img.loadPixels();
	var pCount = 0;
	for (let x=0; x<img.width; x++) {
		for (let y=0; y<img.height; y++) {
    		let c = color(img.get(x,y));
    		let r = red(c);
    		r = r & ~clearMask;
    		r = r << 4;
    		let g = green(c);
    		g = g & ~clearMask;
    		g = g << 4;
			let b = green(c);
    		b = b & ~clearMask;
    		b = b << 4;
    		if (pCount < 200){
    			console.log(c + "r " +  r);
    			console.log(c + "g " +  g);
    			console.log(c + "b " +  b);
    		}
    		pCount++;
    		let eColr = color(r, g, b);
    		img.set(x,y,eColr);
     	} //for
 	} //for
	img.updatePixels();
	image(img, 0, 0);
} // end setup()
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-16-decode.jpg')
}

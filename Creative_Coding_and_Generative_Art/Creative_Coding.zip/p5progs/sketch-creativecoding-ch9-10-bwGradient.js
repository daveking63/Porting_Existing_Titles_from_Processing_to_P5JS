// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// bwGradient.pde, chapter 9-10 Figure 9.22
// Description: Ch 9-10 Figure 9.22 - black to white gradient from top to bottom (or left to right);

let direct = 0; // 0 is top to bottom, 1 left to right
let c;

function setup() {
  createCanvas(400, 400);
  
  let img = createImage(400,400);
  img.loadPixels();

  for (let i = 0; i < width; i++) {
  for (let j = 0; j < height; j++) {
	if (direct == 0){c = color(255 - j);}
	else {c= color(255 - i);}
    img.set(i, j, c);
    } //for
  } //for
  img.updatePixels();
  image(img, 0, 0); 
} //setup



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-10-bwGradient.jpg')
}

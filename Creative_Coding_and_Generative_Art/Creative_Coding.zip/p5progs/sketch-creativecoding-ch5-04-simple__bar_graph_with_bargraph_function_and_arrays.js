// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// Sketch 5-4.pde, chapter 5-04 No Figure
// Description: Ch 5-04 No Figure Bar Graph using a barGraph() function with arrays

var energySource = ["Petroleum", "Coal", "Natural Gas", "Nuclear", "Renewable", "Hydropower"];
var consumption = [40.0, 23.0, 22.0, 8.0, 4.0, 3.0];

function setup() {
	createCanvas(400, 400);
	smooth();
} // setup()

function draw() {
	background(255);
	barGraph(consumption);
} // draw()

function barGraph(data) {
	// set up plot dimensions relative to screen size
	var x = width*0.1;
	var y = height*0.9;
	var delta = width*0.8/data.length;
	var w = delta*0.8;
	for (var i = 0; i < data.length; i++){
		// draw the bar for ith data value
		// first compute the height of the bar relative to sketch window
		dVal = data[i];
		var h = map(dVal, 0, 100, 0, height);
		fill(0);
		rect(x, y-h, w, h);
		x = x + delta;
	}
} // barGraph()

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch5-04-simple__bar_graph_with_bargraph_function_and_arrays.jpg')
}

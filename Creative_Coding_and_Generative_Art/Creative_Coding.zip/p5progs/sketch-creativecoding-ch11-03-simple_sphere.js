// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// simple_sphere.pde, chapter 11-03 Figure 11.2
// Description: Ch 11-03 No Figure 11.2 - Example sphere showcasing P5's simplified approach to 3D.

function setup(){
	createCanvas(600, 600, WEBGL);
}

function draw() {
	background(0);
	ambientLight(40, 20, 40)
	directionalLight(185, 195, 255, -1, 1.25, -1);
	ambientMaterial(250);
	sphere(160, 100, 100);
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch11-03-simple_sphere.jpg')
}

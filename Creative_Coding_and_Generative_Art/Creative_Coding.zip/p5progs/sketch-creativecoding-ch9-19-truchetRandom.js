// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// truchetRandom.pde, chapter 9-19 Figure 9.43
// Description: Ch 9-19 Figure 9.43 - Truchet tiling with random orientation

let tileSize = 24;
let rows = 35;
let cols = 35;
let tiles = [];  //new Tile[rows][cols];

function setup() {
	createCanvas(840, 840);
	smooth();
	background(255);

	for (let i=0; i < rows; i++) {
		tiles[i] = [];
		for (let j = 0; j < cols; j++) {
			tiles[i][j] = new Tile(j*tileSize, i*tileSize, tileSize);
			tiles[i][j].display();
		}
	}
} // end setup()

class Tile {
  constructor(x, y, w) {
    this.x = x; // x, y coords of top left corner of tile
    this.y = y;
    this.sz = w;// size of tile
    this. orient = randInt(0, 3); // orientation of tile
  } // end Tile()

  display() {
	push();    
		translate(this.x, this.y);          // move to tile’s x-y location (upper left corner)
		translate(this.sz/2, this.sz/2);    // move to the center of the tile
		rotate(this.orient*PI/2);      // rotate by the appropriate angle
		translate(-this.sz/2, -this.sz/2);  // move back to the upper left corner

		fill(0);
		triangle(this.sz, 0, this.sz, this.sz, 0, this.sz);

		// variation with a pair of arcs
		//stroke(0);
		//noFill();
		//arc(0, 0, this.sz, this.sz, 0, PI/2);
		//arc(this.sz, this.sz, this.sz, this.sz, PI, 3*PI/2);

	pop();
	} // end draw()
} // end class Tile

function randInt(low, high) {
	let r =  floor(random(low, high+1));
	r = constrain(r, low, high);
	return r;
} // end randInt()
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-19-truchetRandom.jpg')
}

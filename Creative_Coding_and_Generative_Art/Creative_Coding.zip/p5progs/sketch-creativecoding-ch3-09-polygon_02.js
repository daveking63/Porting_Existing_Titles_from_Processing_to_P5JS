// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// polygon_02.pde, chapter 3-09 Figure 3-12
// Description: Ch 3-09 Figure 3.12 Polygon 2. 

function setup(){
	createCanvas(400, 400);
	background(255);
	fill(100);
	polygon(100.0);
}

function polygon(radius) {

	var theta = 0.0;
	var x = 0.0;
	var y = 0.0;

	beginShape();

		// vertex 1
		x = width/2 + cos(theta)*radius;
		y = height/2 + sin(theta)*radius;
		vertex(x, y);

		// vertex 2
		theta = theta + PI/1.5;
		x = width/2 + cos(theta)*radius;
		y = height/2 + sin(theta)*radius;
		vertex(x, y);

		// vertex 3
		theta = theta + PI/1.5;
		x = width/2 + cos(theta)*radius;
		y = height/2 + sin(theta)*radius;
		vertex(x, y);


	endShape(CLOSE);
} // end polygon
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch3-09-polygon_02.jpg')
}

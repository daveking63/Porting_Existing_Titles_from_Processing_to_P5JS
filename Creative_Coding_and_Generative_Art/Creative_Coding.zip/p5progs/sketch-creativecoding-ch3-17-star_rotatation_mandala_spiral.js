// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// star_rotatation_mandala_spiral.pde, chapter 3-17 No Figure
// Description: Ch 3-17 No Figure star mandala plot spiral plot.

function setup() {
  createCanvas(800, 800);
  background(255);
  
  //presets
  var nodes = 30;
  var spiralRadius = width*.4;
  var spiralTheta = 0.0;
  var x = 0.0, y = 0.0;
  
  var outerRadius = 170.0;
  
  // randomly generated
  var pointCount = 0;
  var steps = 0;
  var innerRadius = 0.0;
  var outerRadiusRatio = 0.0;
  var innerRadiusRatio = 0.0;
  var shadeRatio = 0.0;
  var rotationRatio = 0.0;
  
  translate(width/2, height/2);
  for (var i=0; i<nodes; i++) {
      pointCount = int(random(5, 15));
      steps = int(random(4, 15));
      innerRadius = outerRadius*random(.3, .9);
      outerRadiusRatio = outerRadius/steps;
      innerRadiusRatio = innerRadius/steps;
      var randCol = random(225, 255);
      shadeRatio = randCol/steps;
      rotationRatio = random(90, 200)/steps;
      push();
      x = cos(spiralTheta)*spiralRadius;
      console.log(x);
      y = sin(spiralTheta)*spiralRadius;
      translate(x, y);
      for (var k=0; k<steps; k++) { 
        if (k%int(random(1, 6))==0) {
          stroke(0, 50);
        } 
        else {
          noStroke();
        }
        fill(randCol-shadeRatio*k);
        push();
        scale(.4);
        rotate(rotationRatio*k*PI/180);
        star(pointCount, outerRadius-outerRadiusRatio*k, innerRadius-innerRadiusRatio*k);
        pop();
      }
      pop();
      outerRadius *= .93;
      spiralRadius -=15;
      spiralTheta += TWO_PI/(nodes*.5);
    }
}

function star(pointCount, innerRadius, outerRadius) {
	var theta = 0.0;
	// point count is 1/2 of total vertex count
	var vertCount = pointCount*2;
	var thetaRot = TWO_PI/vertCount;
	var tempRadius = 0.0;
	var x = 0.0, y = 0.0;

	beginShape();
		for (var i=0; i<pointCount; i++) {
			for (var j=0; j<2; j++) {
				tempRadius = innerRadius;
				// true if j is even
				if (j%2==0) {
					tempRadius = outerRadius;
				}
				x = cos(theta)*tempRadius;
				y = sin(theta)*tempRadius;
				vertex(x, y);
				theta += thetaRot;
			}
		}
	endShape(CLOSE);
} // end star
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch3-17-star_rotatation_mandala_spiral.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// convolution.pde, chapter 10-13 Figure 10.22-26
// Description: Ch 10-13 Figure 10.22-26 - 9 convolution filters - Press '0'-'7' to cycle through the filters
	
let ks= [
		[[1, 1, 1], [1, 1, 1], [1, 1, 1]], //kernel0 -  
		[[1, 2, 1], [2, 4, 2], [1, 2, 1]], ////kernel1
		[[0, -2, 0], [-2, 11, -2], [0, -2, 0]], //kernel2
		[[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]], //kernel3
		[[1, 1, 1], [1, -7, 1], [1, 1, 1]], //kernel4
		[[0, -1, 0], [-1, 4, -1], [0, -1, 0]], //kernel5
		[[-1, -1, -1], [-1, 8, -1], [-1, -1, -1]], //kernel6
		[[1,1,0],[1,0,-1],[0,-1,-1]] //kernel7
		];
		

var img, img2;
var filters = [];

var matrixsize = 3;
var iWdth = 639;
var iHght = 959;

let xstart = 0;
let ystart = 0;
let xend = 639;
let yend = 959;

let pCount = 0;
	
function preload() {
	img = loadImage("data/prinzipal.jpg");
}

function setup() {
	createCanvas(iWdth*2,iHght);
	pixelDensity(1);
	img2 = createImage(iWdth,iHght);
	
	img.loadPixels();
	img2.loadPixels();
	
	filters = defineFilters();
	applyFilter(0);
}

function draw() {}

function defineFilters(){
	// Filter(kernel, normalize, bOffset, name);
	let iFilters = [];
	iFilters[0] = new Filter(ks[0], 9, 0, "Mean"); 
	iFilters[1] = new Filter(ks[1], 9, 0, "Motion Blur");
	iFilters[2] = new Filter(ks[2], 3, 0, "Sharpen");
	iFilters[3] = new Filter(ks[3], 1, 0, "Mean Removal");
	iFilters[4] = new Filter(ks[4], 1, 0, "Mystery");
	iFilters[5] = new Filter(ks[5], 1, 0, "Edge Detection Horizontal/Vertical");
	iFilters[6] = new Filter(ks[6], 1, 0, "Edge Detection with Diagonal");
	iFilters[7] = new Filter(ks[7], 1, 127, "Emboss");
    return iFilters;
}//defineFilters

function applyFilter(n){
	for (var x = xstart; x < xend; x++ ) {
		for (var y = ystart; y < yend; y++ ) {
			// Each pixel location (x,y) gets passed into a function called convolution()
			// The convolution() function returns a new color to be displayed.
			let result = filters[n].convolute(x ,y , matrixsize, img);
			var loc = (x + y * img.width) * 4;
			img2.pixels[loc    ] = result[0];
			img2.pixels[loc + 1] = result[1];
			img2.pixels[loc + 2] = result[2];
			img2.pixels[loc + 3] = 255;      
		}
	}
	img2.updatePixels();
	image(img, 0, 0);
	image(img2, width/2, 0);
	fill(255);
	textSize(20);
	text(filters[n].name, width/2+width/25, height/25);
}

function keyTyped(){
	print(key);
	if (key === '0'){ applyFilter(0);}
	if (key === '1'){ applyFilter(1);}
	if (key === '2'){ applyFilter(2);}
	if (key === '3'){ applyFilter(3);}
	if (key === '4'){ applyFilter(4);}
	if (key === '5'){ applyFilter(5);}
	if (key === '6'){ applyFilter(6);}
	if (key === '7'){ applyFilter(7);}
	if (key === '8'){ applyFilter(8);}
}

class Filter{
	constructor(kernel, normalizer, bOffset, name){
		this.kernel = kernel;
		this.normalizer = normalizer;
		this.bOffset = bOffset; // brightness offset
		this.name = name;
	}
	convolute(x, y, matrixsize, aImg) {
		let matrix = this.kernel;
		var rtotal = 0.0;
		var gtotal = 0.0;
		var btotal = 0.0;
		var halfsize = floor(matrixsize / 2);

		// Loop through convolution matrix
		for (var i = 0; i < matrixsize; i++ ) {
			for (var j = 0; j < matrixsize; j++ ) {
				// What pixel are we testing
				var xloc = x + i-halfsize;
				var yloc = y + j-halfsize;
				var loc = (xloc + aImg.width * yloc) * 4;

				// Make sure we haven't walked off the edge of the pixel array
				// It is often good when looking at neighboring pixels to make sure we have not gone off the edge of the pixel array by accident.
				loc = constrain(loc, 0, aImg.pixels.length-1);
				// Calculate the convolution
				// We sum all the neighboring pixels multiplied by the values in the convolution matrix.
				rtotal += aImg.pixels[loc    ] * matrix[i][j]/this.normalizer;
				gtotal += aImg.pixels[loc + 1] * matrix[i][j]/this.normalizer;
				btotal += aImg.pixels[loc + 2] * matrix[i][j]/this.normalizer;
			}
		}

		// Make sure RGB is within range
		rtotal = constrain(rtotal,0,255);
		gtotal = constrain(gtotal,0,255);
		btotal = constrain(btotal,0,255);

		// Return an array with the three color values
		return [rtotal+this.bOffset, gtotal+this.bOffset, btotal+this.bOffset];
	}//apply
}//class
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch10-13-convolution.jpg')
}

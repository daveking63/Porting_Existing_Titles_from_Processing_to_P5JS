// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// ten_thousand_rectangles.pde, chapter 2-02 Figure 2.7
// Description: Ch 2-02 Figure 2.7 Ten-Thousand Rectangles - drawing with a for loop.
   
function setup(){
	createCanvas(1100, 1100);
	background(255);
	noFill();
	stroke(0, 0, 0, 150);
	for (var i=0; i<10000; i++) {
		var w = random(10, 70);
		var h = random(10, 70);
		rect(random(width-w), random(height-h), w, h);
	}
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch2-02-ten_thousand_rectangles.jpg')
}

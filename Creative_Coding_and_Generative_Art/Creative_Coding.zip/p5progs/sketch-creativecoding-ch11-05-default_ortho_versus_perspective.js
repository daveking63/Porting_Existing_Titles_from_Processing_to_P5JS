// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// default_ortho_versus_perspective.pde, chapter 11-05 No Figure
// Description: Ch 11-05 No Figure - Example showcasing ortho and perspective projections.

function setup() {
	createCanvas(800, 400, WEBGL);
}

function draw() {
	//WEBGL auto translates upper left (0,0) to center of canvas
	//This first translates back so 0,0 is returned to upper left
	translate(-width/2, -height/2, 0);
	background(200);
	noFill();

	push();
		translate(width/4, height/2,0,-40);
		rotateY(frameCount*PI/360.0);
		rotateX(frameCount*PI/720.0);
		box(200);
		perspective();
	pop();

	push();
		translate(width-width/4, height/2);
		rotateY(frameCount*PI/360.0);
		rotateX(frameCount*PI/720.0);
		box(200);
		ortho();
		pop();
  
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch11-05-default_ortho_versus_perspective.jpg')
}

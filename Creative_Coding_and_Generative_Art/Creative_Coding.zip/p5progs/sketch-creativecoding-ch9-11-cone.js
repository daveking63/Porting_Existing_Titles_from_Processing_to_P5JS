// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// cone.pde, chapter 9-11Figure 9.23
// Description: Ch 9-11 Figure 9.23 - blue to orange gradiant from center out

function setup() {
	createCanvas(400, 400);

	let img = createImage(400,400);
	img.loadPixels();

	for (let y=0; y<height; y++) {
		for (let x=0; x<width; x++) { 
			let distance = dist(x, y, width/2, height/2);
			//blue to orange
			let r = map(distance, 0, width/2, 20, 200);
			let g = map(distance, 0, width/2, 20, 100);
			let b = map(distance, 0, width/2, 140, 0);
			let index = (x + y * width) * 4;
			img.pixels[index] = r;
			img.pixels[index + 1] = g;
			img.pixels[index + 2] = b;
			img.pixels[index + 3] = 255;
			} //for
	} //for
	img.updatePixels();
	image(img, 0, 0); 
} //setup

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-11-cone.jpg')
}

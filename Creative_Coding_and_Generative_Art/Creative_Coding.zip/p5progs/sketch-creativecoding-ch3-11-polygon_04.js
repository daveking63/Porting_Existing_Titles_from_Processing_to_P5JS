// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// polygon_04.pde, chapter 3-11 Figure 3-15
// Description: Ch 3-11 Figure 3.15 Polygon 4.

function setup(){
  createCanvas(400, 400);
  background(255);
  fill(100);
  translate(width/2, height/2);
  rotate(PI/7);
  polygon(7, 100.0);
}

function polygon(sideCount, radius) {

  var theta = 0.0;
  var x = 0.0;
  var y = 0.0;

  beginShape();
  for (var i=0; i<sideCount; i++) {
    x = cos(theta)*radius;
    y = sin(theta)*radius;
    vertex(x, y);
    theta += TWO_PI/sideCount;
  }
  endShape(CLOSE);
} // end polygon
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch3-11-polygon_04.jpg')
}

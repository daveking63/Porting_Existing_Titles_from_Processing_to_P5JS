// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// polygonal_wallpaper.pde, chapter 3-13 Figure 3-16
// Description: Ch 3-13 Figure 3.16 create polygonal wallpaper.

function setup() {
	createCanvas(800, 800);
	background(255);
	noFill();
	var polyCount = 3000;
	var sideCount = 0;
	var radius = 0.0;
	var rotation = 0.0;

	for (var i=0; i<polyCount; i++) {
		sideCount = int(random(3, 15));
		radius = random(2, 20);
		rotation = random(TWO_PI);
		push();
			translate(random(width), random(height));
			rotate(rotation);
			polygon(sideCount, radius);
		pop();
	}
}

function polygon(sideCount, radius) {

	var theta = 0.0;
	var x = 0.0;
	var y = 0.0;

	beginShape();
	for (var i=0; i<sideCount; i++) {
		x = cos(theta)*radius;
		y = sin(theta)*radius;
		vertex(x, y);
		theta += TWO_PI/sideCount;
	}
	endShape(CLOSE);
} // end polygon
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch3-13-polygonal_pattern.jpg')
}

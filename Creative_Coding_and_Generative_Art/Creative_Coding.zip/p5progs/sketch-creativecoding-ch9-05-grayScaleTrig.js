// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// grayScaleTrig.pde, chapter 9-05 Figure 9.13-14
// Description: Ch 9-05 Figure 9.13-14 - 2D array visualized with periodic gradient shading

var rows = 100;
var cols = 100;
var grays = [];
var cellSize = 5;
var inc =[];

function setup() {
	createCanvas(500, 500);
	noStroke();
	// uncomment for full color variation
	//colorMode(HSB);

	for (let i = 0; i < rows; i++) {
		grays[i] = [];
		for (let j = 0; j < cols; j++) {
			let x = map(i, 0, rows-1, 0, 2*PI);
			let y = map(j, 0, cols-1, 0, 2*PI);
			let z = sin(x)*cos(y);
			grays[i][j] = map(z, -1.0, 1.0, 0.0, 255.0);
		}
	}
	for (var i = 0; i < rows; i++) {
		for (var j = 0; j < cols; j++) {
	  		fill(grays[i][j]);
			// full color variation, uncomment colorMode(HSB) above
			//fill(grays[i][j], 255, 255);
			push();
			// j is the column index, which correspond to the x  screen coordinate
				translate(j*cellSize, i*cellSize); 
				rect(0, 0, cellSize, cellSize);
			pop();
		}
	}
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-05-grayScaleTrig.jpg')
}

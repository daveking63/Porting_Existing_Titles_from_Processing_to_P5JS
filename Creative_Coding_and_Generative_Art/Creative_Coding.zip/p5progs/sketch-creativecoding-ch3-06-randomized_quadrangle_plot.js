// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// randomized_quadrangle_plot.pde, chapter 3-06 No Figure
// Description: Ch 3-06 Using Processing's drawing functions with randomization. 

function setup() {
	createCanvas(600, 600);
	background(255);
	plotRandomizedQuad (200, 200, 200, 200, 0.2, 0.2);
} // end setup

function plotRandomizedQuad(x, y, w, h, randW, randH) {
	var jitterW = w*randW;
	var jitterH = h*randH;
	beginShape();
		vertex(x+random(-jitterW, jitterW), y+random(-jitterH, jitterH));
		vertex(x+random(-jitterW, jitterW), y+h+random(-jitterH, jitterH));
		vertex(x+w+random(-jitterW, jitterW), y+h+random(-jitterH, jitterH));
		vertex(x+w+random(-jitterW, jitterW), y+random(-jitterH, jitterH));
	endShape(CLOSE);
} // end plotRandomizedQuad

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch3-06-randomized_quadrangle_plot.jpg')
}

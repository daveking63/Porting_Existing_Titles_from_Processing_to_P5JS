// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// severe_perspective_projection.pde, chapter 11-08 No Figure
// Description: Ch 11-08 No Figure - Severe perspective projection examples.

let depth = 100;  //z - dimension originally 75
let sw = 2; //stroke weight - originally 1
let bWidth = 75; //originally 75

function setup(){
	createCanvas(600, 200, WEBGL);
	background(0);
	noFill();
	stroke(255);
    strokeWeight(2);

	push();
		translate(-width/2, 0, depth);
		let fov = PI/1.3;
		let cameraZ = (height/2.0) / tan(fov/2.0);
		perspective(fov, float(width)/float(height),
	            cameraZ/5.0, cameraZ*5.0);
		box(bWidth);
	pop();

	push();
		//translate(width/2, height/2, depth);
        translate(0,0,100);
		fov = PI/1.3;
		perspective(fov, float(width)/float(height), 
		            cameraZ/10.0, cameraZ*10.0);
		box(bWidth);
	pop();

	push();
		translate(width-width/2, 0, depth);
		fov = PI/1.3;
		perspective(fov, float(width)/float(height), 
		            cameraZ/10.0, cameraZ*10.0);
		box(bWidth);
	pop()
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch11-08-severe_perspective_projection.jpg')
}

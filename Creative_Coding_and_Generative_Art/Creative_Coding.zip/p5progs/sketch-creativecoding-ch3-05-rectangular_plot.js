// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// rectangular_plot.pde, chapter 3-05 Figure 3.6
// Description: Ch 3-05 Figure 3.6 Creating a rectangle using shape

function setup(){
  createCanvas(600, 600);
  background(255);
  plotRect(100, 100, 400, 400);
} // end setup

function plotRect(x, y, w, h) {
	beginShape();
		vertex(x, y);
		vertex(x, y+h);
		vertex(x+w, y+h);
		vertex(x+w, y);
	endShape(CLOSE);
} // end plotRect
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch3-05-rectangular_plot.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// simple_cube.pde, chapter 11-01 Figure 11-1
// Description: Ch 11-01 Figure 11-1 - P5 box() example.

function setup() {
  createCanvas(400, 400, WEBGL);
  noFill();
}

function draw() {
  background(255);
  //translate(width/2, height/2);
  rotateY(frameCount*PI/360.0);
  rotateX(frameCount*PI/720.0);
  box(200);
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch11-01-simple_cube.jpg')
}

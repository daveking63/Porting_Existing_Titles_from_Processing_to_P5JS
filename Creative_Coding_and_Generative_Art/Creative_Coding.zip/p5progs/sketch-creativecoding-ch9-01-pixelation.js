// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// pixelation.pde, chapter 9-01 Figure 9.3-4
// Description: Ch 9-01 Figure 9.3-4 - Creates a pixelation effect on an image


// pixelation.pde, chapter 9
// Creates a pixelation effect on an image

function preload(){
	img = loadImage("data/lenna.jpg");
}

function setup() {

  var resolution = 50;

  createCanvas(512, 512);
  var xInc = width/resolution;
  var yInc = height/resolution;

  for (var y=0; y<img.height; y+=yInc) {
    for (var x=0; x<img.width; x+=xInc) {
      fill(img.get(x, y));
      rect(x, y, xInc, yInc);
      // variation with line()
      //strokeWeight(3);
      //stroke(img.get(x, y));
      //line(x, y, x+10, y+10);
    }
  }
} // end setup()
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-01-pixelation.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// sketch_6_7.pde, chapter 6-06 No Figure
// Description: Ch 6-07 No Figure Several widgets

var pieces = [];
var N = 10;
var pColor;
var pLocation;
var pChoice;

function setup(){
	createCanvas(400, 400);
	smooth();

	for (var i=0; i < N; i++) {
		pColor = color(random(50, 200), random(50, 200), random(50, 200));
		pLocation = createVector(random(width), random(height));
		pChoice= int(random(2));

		if (pChoice == 0) {
			pieces[i] = new disc(pLocation, 20, pColor);
		}
		else {  
			pieces[i] = new hexagon(pLocation, 20, pColor);
		}
	}
} // setup()

function draw(){
	background(255);
	for (var i=0; i < N; i++) {
		pieces[i].move();
		pieces[i].display();
	}
} // draw()

class widget {
	constructor(loc, s, c){
		this.location = loc; // p5.Vector
		this.sz = s; // size
		this.col = c; // color
	}
} // class widget

class disc extends widget {
	constructor(loc, s, c){
		super(loc, s, c);
		this.r = s/2.0;
		this.speed = createVector(random(1, 3), random(1, 3));
	}
	display() {
		noStroke();
		fill(this.col);
		ellipse(this.location.x, this.location.y, this.sz, this.sz);
	} // display()
	
	setSpeed(s) {
		this.speed = s;
	} // setSpeed() 
	 
	move() {
		this.location.add(this.speed);
		this.bounce();
	} // move()
	
	bounce() {
		if (this.location.x > (width-this.r)) { // bounce against the right edge
			this.location.x = width-this.r;
			this.speed.x = -this.speed.x;
		}
		if (this.location.x < this.r) { // bounce against the left edge
			this.location.x = this.r;
			this.speed.x = -this.speed.x;
		}
		if (this.location.y > (height-this.r)) { // bounce against the bottm edge
			this.location.y = height-this.r;
			this.speed.y = -this.speed.y;
		}
		if (this.location.y < this.r) { // bounce against the top edge
			this.location.y = this.r;
			this.speed.y = -this.speed.y;
		}
	} // bounce() 
} // class disc

class hexagon extends widget {
	constructor(loc, s, c){
		super(loc, s, c);
		this.nSides = 6;
		this.theta = 0.0;
		this.r = this.sz/2.0;
		this.rot = 0.0;
		this.speed = createVector(random(-2,2), random(-2,2));
	}
	display() {
		noStroke();
		fill(this.col);
		beginShape();
			for (var i = 0; i <this.nSides; i++){
				var x1 = this.location.x + this.r*cos(this.theta);
				var y1 = this.location.y + this.r*sin(this.theta);
				vertex(x1, y1);
				this.theta += PI/3.0;
			}
		endShape();
	} // display()
	
	setSpeed(s) {
		s.mult(-2);
		this.speed = s;
	} // setSpeed() 
	 
	move() {
		this.rot += 0.01;
		this.location.add(this.speed);
		this.bounce();
	} // move()
	
	bounce() {
		if (this.location.x > (width-this.r)) { // bounce against the right edge
			this.location.x = width-this.r;
			this.speed.x = -this.speed.x;
		}
		if (this.location.x < this.r) { // bounce against the left edge
			this.location.x = this.r;
			this.speed.x = -this.speed.x;
		}
		if (this.location.y > (height-this.r)) { // bounce against the bottm edge
			this.location.y = height-this.r;
			this.speed.y = -this.speed.y;
		}
		if (this.location.y < this.r) { // bounce against the top edge
			this.location.y = this.r;
			this.speed.y = -this.speed.y;
		}
	} // bounce() 
} // class disc
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch6-07-several_widgets.jpg')
}

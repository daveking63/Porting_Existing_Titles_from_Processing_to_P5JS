// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// aliasing_vs_anti-aliasing.pde, chapter 3-04 Figure 3.5
// Description: Ch 3-04 Figure 3.5 compare aliasing versus anti-aliasing (default state)

function setup(){
	createCanvas(800, 400);
	background(255);
	noFill();
	strokeWeight(2);

	// default anti-aliasing 
	push();
		translate(width/4, height/2);
		scale(16);
		triangle(-10, -10, 10, -10, 0, 10);
	pop();

	// aliasing
	noSmooth();
	push();
		translate(width-width/4, height/2);
		scale(16);
		triangle(-10, -10, 10, -10, 0, 10);
	pop();

}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch3-04-aliasing_vs_anti-aliasing.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// sketch_7_10.pde, chapter 7-10 Figure 7.7
// Description: Ch 7-10 Figure 7.7 Word tiles random placement

var inputTextFile = 'Obama.txt';
var stopWordsFile = 'stopwords.txt';
var stopWordsList = []
var fileContents = [];
var rawText,stopText;
var tokens = [];
var delimiters = " ,./?<>;:'\"[{]}\\|=+-_()*&^%$#@!~";
var table;
var N = 150;

function preload(){
	textdir = "data/";
	fileContents = loadStrings(textdir + inputTextFile);
	stopWordsFileContents = loadStrings(textdir + stopWordsFile);	
}

function setup(){
	createCanvas(800,800);
	
	//build stopwords list
	stopText = join(stopWordsFileContents, "\n");
	stopWordsList = stopText.split("\n");
	
	// Input and parse text file
	rawText = join(fileContents, " ");
	rawText = rawText.toLowerCase();
	tokens = splitTokens(rawText, delimiters);
	console.log(tokens.length + " tokens found in file: " + inputTextFile);
	
	// Create the word frequency table
	table = new WordFreq(tokens);
	console.log("Max frequency: " + table.maxFreq());
	table.tabulate(N);
  	table.arrange(N); //create tiles for each word-frequency
} // setup()

function draw() {
  background(255);
  table.display(N);
} // draw()


class WordFreq {	
	// A Frequency table class for Words
	constructor(tokens){
		this.wordFrequency = [];
		this.nonStopWordCnt = 0;
		this.stopWordCnt = 0;
		this.wordTiles = [];
		
		for (var i = 0; i < tokens.length; i++){
			var tok = tokens[i];
			var stopResult = this.isStopWord(tok);
			if (!stopResult){index = this._search(tok, this.wordFrequency);}
			if (!this.isStopWord(tok)){
				var index = this._search(tok, this.wordFrequency);
				if (index == -1){
			    this.wordFrequency.push({word:tok, freq:1});
				}
				else {
					this.wordFrequency[index].freq++;	
				}
			} // if
		}// for
	} // constructor
	
	isStopWord(word){
		for(let i = 0; i < stopWordsList.length; i++){
			if (word == stopWordsList[i]){
				return true;
			}
		}
		return false;	
	} //isStopWord
	
	_search(token, wList){
		var srchTest = -1;
		for (var i = 0; i < wList.length; i ++){
			if (token == wList[i].word){
				srchTest = i;
			}
		}
		return srchTest
	} //_search
	
	tabulate(){
		console.log("There are " + this.N() + " non-stop words.");
		for (var i = 0; i < this.wordFrequency.length; i++){
			console.log(this.wordFrequency[i].word + ' ' + this.wordFrequency[i].freq);
		}
	}
	
	arrange(Num) {  // arrange or map the first N tiles in sketch
		for (var i=0; i < Num; i++) {
			var word = this.wordFrequency[i].word;
			var freq = this.wordFrequency[i].freq;
			this.wordTiles[i] = new WordTile(word, freq);
			this.wordTiles[i].setFontSize();
			this.wordTiles[i].setSize();
			this.wordTiles[i].setXY(random(width), random(height));
		}
	} // arrange()
  
	display(Num) {
	for (var i=0; i < Num; i++) {
		this.wordTiles[i].display();
		}
	}  // display()
	
	N(){
		return this.wordFrequency.length;
	} // N
	
	samples(){
		var k = [];
		for (i = 0; i < this.wordFrequency.length; i++){
			k[i] = this.wordFrequency[i].word;
		}
		return k;	
	} //samples
	
	counts(){
		var v = [];
		for (var i = 0; i < this.wordFrequency.length; i++){
			v[i] = this.wordFrequency[i].freq;
		}
		return v;
	}
	
	maxFreq(){
		var max = this.wordFrequency[0].freq;
		for (var i = 0; i < this.wordFrequency.length - 1; i++){
			for (var j = 1; j < this.wordFrequency.length; j++){
				if (this.wordFrequency[j].freq > max){max = this.wordFrequency[j].freq;}
			} //for
		} //for
		return max;
	} //max
	
	
} // wordFrequency

class WordTile{
  constructor(newWord,newFreq) { // Constructor
  	this.tileWord = newWord;
  	this.tileFreq = newFreq
    this.tileW;
    this.tileH;
    this.tileFS = 24;
    this.setSize();
    this.location = createVector(0, 0);
    this.tileColor = color(0);
  } // WordTile()
  
  setXY (x, y) {
    this.location.x = x;
    this.location.y = y;
  } // setXY()
  
  setFontSize() {
    this.tileFS = map(this.tileFreq, 1, 30, 10, 120);
    this.setSize();
  } // setFontSize()
  
  setSize() {
    textSize(this.tileFS);
    this.tileW = textWidth(this.tileWord);
    this.tileH = textAscent();
  } // setTileSize()
  
  display() {
    fill(this.tileColor);
    textSize(this.tileFS);
    text(this.tileWord, this.location.x, this.location.y);
  } // display()
} // class WordTile
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch7-10-word_tiles_random_placement.jpg')
}

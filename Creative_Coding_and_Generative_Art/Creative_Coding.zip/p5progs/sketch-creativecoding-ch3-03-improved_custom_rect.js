// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// Improved_custom_rect.pde, chapter 3 - Figure 3.3
// Description: Ch 3-03 Figure 3-3 Overloaded function example, using different function signatures.
// Unlike Processing, p5.js cannot override an existing function --
// usually not a good idea anyway

function setup() {
	createCanvas(600, 600);
	background(0);
	rectangle(175, 175, 350, 350, false);
	rectangle(300, 300, 300, 300, true);
}

function rectangle(x, y, w, h, isRect){
	if (isRect){
		rect(x, y, w, h); // call Processing's rect()
	} 

	if (!isRect){
		ellipse(x, y, w, h); // call Processing's ellipse()
	}
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch3-03-improved_custom_rect.jpg')
}

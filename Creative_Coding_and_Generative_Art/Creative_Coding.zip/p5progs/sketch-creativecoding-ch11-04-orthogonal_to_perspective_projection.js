// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// orthogonal_to_perspective_projection.pde, chapter 11-04 Figure 11.6
// Description: Ch 11-04 No Figure 11.6 - Projection examples.

function setup(){
	createCanvas(600, 200, WEBGL);
	background(0);
	noFill();
	strokeWeight(2);
	stroke(255);
	// WEBGL auto translates upper left (0,0) to canvas center
	// this translates it back to upper left
	translate(-width/2, -height/2, 0);

	push();
		translate(width/6, height/2, 0);
		let fov = PI/3;
		let cameraZ = (height/2.0) / tan(fov/2.0);
		ortho(0, width, 0, height, -200, 200);
		box(75);
	pop();

	push();
		translate(width/2, height/2, -20);
		fov = PI/3;
		perspective(fov, float(width)/float(height), 
		            cameraZ/10.0, cameraZ*10.0);
		box(75);
	pop();

	push();
		translate(width-width/6, height/2, -20);
		fov = PI/3;
		perspective(fov, float(width)/float(height), 
		            cameraZ/10.0, cameraZ*10.0);
		box(75);
	pop();
}//setup
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch11-04-orthogonal_to_perspective_projection.jpg')
}

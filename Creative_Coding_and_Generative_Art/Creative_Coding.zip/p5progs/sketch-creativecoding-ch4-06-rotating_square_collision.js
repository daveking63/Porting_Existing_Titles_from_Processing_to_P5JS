// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// rotating_square_collision.pde, chapter 4-06 Figure 4.5
// Description: Ch 4-04 Figure 4.4 Combining animation, transformations and collision detection.

// declare global variables
// for moving square
var x, y, w;
var spdX, spdY, theta, rotSpd;

function setup() {
	createCanvas(600, 600);
	// initialize global variables
	x = float(width/2.0);
	y = float(height/2.0);
	w = 150.0;
	spdX = 2.1;
	spdY = 1.5;
	theta = 0.0;
	rotSpd = PI/180.0;
	fill(0, 175, 175);
	noStroke();
}

function draw() {
	background(255, 127, 0);

	push();
		translate(x, y);
		rotate(theta);
		rect(-w/2, -w/2, w, w);
	pop();

	x += spdX;
	y += spdY;
	theta += rotSpd;

	// check for wall collisions
	collide();
}

function collide() {
	if (x > width-w/2) {
		spdX *= -1;
		rotSpd *= -1;
	} 
	else if (x < w/2) {
		spdX *= -1;
		rotSpd *= -1;
	}
	if (y > height-w/2) {
		spdY *= -1;
		rotSpd *= -1;
	} 
	else if (y < w/2) {
		spdY *= -1;
		rotSpd *= -1;
	}
} // end collide
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch4-06-rotating_square_collision.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// algorithmic_face.pde, chapter 2-06
// Description: Ch 2-06 Figure 2.18-19 Complex Complex algorithmic approach to drawing a face using functions and curves.
// few adjustments to ensure symmetry of lips

// BEGIN DECLARE/INITIALIZE HEAD VARIABLES
var headHeight = 600;
var headWidth = headHeight*5/7;
var head_x = (600-headWidth)/2;
var head_y = (800-headHeight)/2;

function setup() {
  createCanvas(600,800);
  background(0);
  stroke(255);
  noFill();
  ellipseMode(CORNER); 
  //translate(width/2, height/2);
  // Draw head
  head(head_x, head_y, headWidth, headHeight);  
}

function head(x, y, w, h) {

	// EYES
	var eyeWidth = w/5;
	var eyeHeight = eyeWidth/2;
	var irisDiam = eyeHeight;
	var pupilDiam = irisDiam/3;
	var eye_y = y+h/2-eyeHeight/2;
	// left
	var leftEye_x = x+eyeWidth;
	var leftIris_x = leftEye_x + eyeWidth/2-irisDiam/2;
	var leftPupil_x = leftEye_x + eyeWidth/2-pupilDiam/2;
	// right
	var rightEye_x = x+eyeWidth*3;
	var rightIris_x = rightEye_x + eyeWidth/2-irisDiam/2;
	var rightPupil_x = rightEye_x + eyeWidth/2-pupilDiam/2;

	//EYEBROWS
	var eyeBrowWidth = eyeWidth*1.25;
	var eyeBrowHeight = eyeHeight/4;
	var eyeBrow_y = eye_y - eyeHeight - eyeBrowHeight/2;
	// left
	var leftEyeBrow_x = leftEye_x - (eyeBrowWidth-eyeWidth);
	// right
	var rightEyeBrow_x = rightEye_x;

	// NOSE
	var nose_x = x + eyeWidth*2;
	var nose_y = y + h - h/3.0;

	// MOUTH
	var mouthWidth = eyeWidth*2;
	var mouthHeight = h/10;
	var mouth_x = leftIris_x-20 + irisDiam/2 + eyeWidth/4;
	var mouth_y = nose_y + mouthHeight*1.25;

	// EARS
	var earWidth = eyeHeight*1.5;
	var earHeight = h/4;
	var earTop_y = eyeBrow_y;
	var earBottom_y = 0.0;
	// left
	var leftEarTop_x = x-earWidth/2;
	var leftEarBottom_x = 0.0;
	var leftEarRidgeTop_x = 0.0;
	var leftEarRidgeTop_y = 0.0;
	// right
	var rightEarTop_x = x+w-earWidth/2;
	var rightEarBottom_x = 0.0;
	var rightEarRidgeTop_x = 0.0;
	var rightEarRidgeTop_y = 0.0;

	curveTightness(random(-0.1, 0.1));
	curveTightness(0);
	push();
		scale(1+jtr(0.2), 1+jtr(0.2));
		// start top middle of head
		beginShape();
		curveVertex(x, y);
		curveVertex(x+w/2, y);
		curveVertex(x+w*0.81, y+h/18);
		curveVertex(x+w*0.96, y+h/3.9);
		curveVertex(x+w*0.971, y+h/2.4);

		rightEarTop_x = x+w*0.971;
		earTop_y = y+h/2.4;
		curveVertex(x+w*0.979, y+h/2); // Right Inner Ridge Top

		rightEarRidgeTop_x = x+w*0.979;
		rightEarRidgeTop_y = y+h/2;
		curveVertex(x+w*0.98, y+h/1.8);
		curveVertex(x+w*0.947, y+h/1.52);

		rightEarBottom_x = x+w*0.947;
		earBottom_y = y+h/1.52;
		curveVertex(x+w*0.89, y+h/1.25);
		curveVertex(x+w*0.75, y+h/1.1);  // 1 
		curveVertex(x+w/2, y+h);
		curveVertex(x+w*0.25, y+h/1.1);  // -1
		curveVertex(x+w*0.11, y+h/1.25); // -2 
		curveVertex(x+w*0.053, y+h/1.52); // -3 // Left EAR Bottom

		leftEarBottom_x = x+w*0.053;
		curveVertex(x+w*0.02, y+h/1.8); // -4
		curveVertex(x+w*0.021, y+h/2); // Left Inner Ridge Top

		leftEarRidgeTop_x = x+w*0.021;
		leftEarRidgeTop_y = y+h/2;
		curveVertex(x+w*0.029, y+h/2.4); // Left EAR TOP

		leftEarTop_x = x+w*0.029;
		earTop_y = y+h/2.4;
		curveVertex(x+w*0.04, y+h/3.9);
		curveVertex(x+w*0.19, y+h/18);
		curveVertex(x+w/2, y);
		curveVertex(x+w*0.81, y+h/18);
		endShape();

		nose(nose_x, nose_y, eyeWidth, headHeight/8);
		mouth(mouth_x, mouth_y, mouthWidth, mouthHeight);

		// left eye
		eye(leftEye_x, eye_y, eyeWidth, eyeHeight*0.85, 0);
		eye(rightEye_x, eye_y, eyeWidth, eyeHeight*0.85, 1);

		// Draw eyebrows (these should really be replaced with curves)
		rect(leftEyeBrow_x, eyeBrow_y, eyeBrowWidth, eyeBrowHeight);
		rect(rightEyeBrow_x, eyeBrow_y, eyeBrowWidth, eyeBrowHeight);

		ear(leftEarTop_x, earTop_y, leftEarBottom_x, earBottom_y, leftEarRidgeTop_x, leftEarRidgeTop_y, earWidth, earHeight, 0); // left 
		ear(rightEarTop_x, earTop_y, rightEarBottom_x, earBottom_y, rightEarRidgeTop_x, rightEarRidgeTop_y, earWidth, earHeight, 1); // right
	pop();
}

function nose(x, y, w, h) {
  curveTightness(random(-0.4, 0.4));
  push();
	 // scale(1+jtr(0.2), 1);
	scale(1,1);
	  beginShape();
		  curveVertex(x+w/2, y-h/2);
		  curveVertex(x+w/16, y-h/2);
		  curveVertex(x-w/16, y-h/4.5);
		  curveVertex(x, y); // left bottom corner
		  curveVertex(x+w/4, y);
		  curveVertex(x+w/2, y+h/6); // filtrum
		  curveVertex(x+w/2+w/4, y);
		  curveVertex(x+w, y); // right bottom corner
		  curveVertex(x+w+w/16, y-h/4.5);
		  curveVertex(x+w-w/16, y-h/2);
		  curveVertex(x+w-w/2, y-h/2);
	  endShape();
  pop();
}

function mouth(x, y, w, h) {
	curveTightness(random(-0.4, 0.4));
	push();
		//scale(1+jtr(0.2), 1+jtr(0.05));
	  	scale(1,1);
	
		// top lip
		beginShape();
		curveVertex(x+w, y);
		curveVertex(x, y);
		//curveVertex(x+w/3.2, y-h/(2.5+jtr(0.4)));
		curveVertex(x+w/3.2, y - h/2.5);
		curveVertex(x+w/2, y-h/3.1)
		//curveVertex(x+w/1.4, y-h/(2.5+jtr(0.4)));
		curveVertex(x+w/1.4, y-h/2.5);
		curveVertex(x+w, y);
		curveVertex(x, y);
		endShape();
		// bottom lip
		push();
		//scale(0.98, 1.0);
	    scale(1,1);
		beginShape();
			curveVertex(x + w/2, y);
			curveVertex(x, y);
			//curveVertex(x+w/3.2, y+h/(2.1+jtr(0.2)));
			curveVertex(x+w/3.2, y+h/2.1);
			//curveVertex(x+w/1.4, y+h/(2.2+jtr(0.2)));
			curveVertex(x+w/1.4, y+h/2.2);
			curveVertex(x+w, y);
			curveVertex(x+w/2, y);
			endShape();
			
			// lip crease
			beginShape();
			curveVertex(x+w, y);
			curveVertex(x, y);
			//curveVertex(x+w/3.2, y-h/(15.4+jtr(0.2)));
			curveVertex(x+w/3.2, y-h/15.4);
			curveVertex(x+w/2, y*1.005);
			//curveVertex(x+w/1.4, y-h/(15.7+jtr(0.2)));
			curveVertex(x+w/1.4, y-h/15.7);
			curveVertex(x+w, y);
			curveVertex(x, y);
			endShape();
		pop();
	pop();
}

function eye( x, y, w, h, which) {
  var pupilDiam = h*0.25;
  ellipseMode(CENTER);
  curveTightness(-0.5);
  push();
	  if (which == 0) { // left
	    // top
	    beginShape();
		    curveVertex(x+w, y);
		    curveVertex(x, y+h/2);
		    curveVertex(x+w/2, y);
		    curveVertex(x+w, y+h/1.25);
		    curveVertex(x+w, y+h/1.25);
	    endShape();

	    // bottom
	    beginShape();
		    curveVertex(x+w, y+h/1.25);
		    curveVertex(x+w, y+h/1.25);
		    curveVertex(x+w/2, y+h);
		    curveVertex(x, y+h/2);
		    curveVertex(x, y+h/2);
		    //ellipse(x, y, 2, 2);
	    endShape();

	    // iris
	    ellipse((x+w/2), (y+h/2), h, h);
	    // pupil
	    ellipse((x+w/2), (y+h/2), pupilDiam, pupilDiam);
	  } 
	  else { // right
	    // top
		    beginShape();
		    curveVertex(x, y);
		    curveVertex(x+w, y+h/2);
		    curveVertex(x+w/2, y);
		    curveVertex(x, y+h/1.25);
		    curveVertex(x, y+h/1.25);
	    endShape();

	    // bottom
	    beginShape();
		    curveVertex(x+w, y+h/2);
		    curveVertex(x+w, y+h/2);
		    curveVertex(x+w/2, y+h);
		    curveVertex(x, y+h/1.25);
		    curveVertex(x, y+h/1.25);
	    endShape();

	    // iris
	    ellipse((x+w/2), (y+h/2), h, h);
	    // pupil
	    ellipse((x+w/2), (y+h/2), pupilDiam, pupilDiam);
	  }
	pop();
	ellipseMode(CORNER);
}

function ear(xTop, yTop, xBot, yBot, xRidge, yRidge, w, h, whichEar) {
  curveTightness(-1);
  push();
 
  if (whichEar == 0) { // left
    // outer ear
    beginShape();
	    curveVertex(xTop+10, yTop+85);
	    curveVertex(xTop, yTop);
	    curveVertex(xTop-w/2.3, yTop+35);
	    curveVertex(xBot, yBot);
	    curveVertex(xBot+w, yBot-30);
    endShape();

    // innner ridge:
    beginShape();
	    curveVertex(xRidge, yRidge+80);
	    curveVertex(xRidge, yRidge);
	    curveVertex(xTop-w/2.3, yTop+35);
	    curveVertex(xTop-w/2.5, yTop+175);
    endShape();
  } 
  else { // right
    // outer ear
    beginShape();
	    curveVertex(xTop+10, yTop+85);
	    curveVertex(xTop, yTop);
	    curveVertex(xTop+w/2.3, yTop+35);
	    curveVertex(xBot, yBot);
	    curveVertex(xBot-w, yBot-30);
    endShape();

    // innner ridge:
    beginShape();
	    curveVertex(xRidge, yRidge+80);
	    curveVertex(xRidge, yRidge);
	    curveVertex(xTop+w/2.3, yTop+35);
	    curveVertex(xTop+w/2.5, yTop+175);
    endShape();
  }
  pop();
}

function jtr(val){
  return random(-val, val);
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch2-06-complex_algorithmic_face.jpg')
}

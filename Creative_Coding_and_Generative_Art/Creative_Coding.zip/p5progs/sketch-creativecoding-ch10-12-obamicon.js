// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// obamicon.pde, chapter 10-12 Figures 10.17
// Description: Ch 10-12 Figures 10.17 -  Convert an image to an Obamicon

function preload(){
	img = loadImage("data/lenna.png");    // transparent logo
}

function setup() {
	let cDarkBlue = color(0, 51, 76);
	let cRed = color(217, 26, 33);
	let cLightBlue = color(112, 150, 158);
	let cYellow = color(252, 227, 166);

	createCanvas(512, 512);
	image(img, 0, 0);
	img.loadPixels();
	for (let x=0; x<img.width; x++) {
		for (let y=0; y<img.height; y++) {
			let c = color(img.get(x,y));
			let gray = float(red(c)*0.3+green(c)*0.59+blue(c)*0.11);
			if (gray < 60) {
				img.set(x,y,cDarkBlue);
			}
			else if (gray < 122) {
				img.set(x,y,cRed);
			}
			else if (gray < 185) {
				img.set(x,y,cLightBlue);
			}
			else {
				img.set(x,y,cYellow);
			}
		} //for
	} //for
	img.updatePixels();
	image(img, 0, 0);
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch10-12-obamicon.jpg')
}

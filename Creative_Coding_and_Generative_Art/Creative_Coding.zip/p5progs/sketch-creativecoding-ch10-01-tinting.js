// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// tinting.pde, chapter 10-02 Figure 10.1
// Description: Ch 10-02 Figure 10.1 - Using the tint() function to create a Warhol collage

function preload(){
	img = loadImage("data/Lenna.jpg");
}
function setup() {
	createCanvas(1024, 512);    // 2 times as wide as and 2 times as high as the original image 
	tint(200, 100, 0);                  // orange
	image(img, 0, 0);
	tint(0, 100, 200);                  // blue
	image(img, img.width, 0);           // display at x offset img.width
	tint(100, 100, 200);                // purple
	image(img, 0, img.height);
	tint(200, 200, 100);                // yellow
	image(img, img.width, img.height);
} // end setup()


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch10-01-tinting.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// for_loops_prefix_versus_postfix.pde, chapter 3-12 No figure
// Description: Ch 3-12 No figure - for loops with prefix and postfix

function setup(){
	// not part of original code - simply for displaying reminder
	createCanvas(400, 300);
	background(225); 
	textSize(15); 
	text("Ch3-12 for_loops: See Console for Output", 30, 150);
	//
	
	for (var a=0; a<3; a++) {
		console.log("a = " + a);
	}

	for (var b=0; b<3; ++b) {
		console.log("b = " + b);
	}
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch3-12-for_loops_prefix_versus_postfix.jpg')
}

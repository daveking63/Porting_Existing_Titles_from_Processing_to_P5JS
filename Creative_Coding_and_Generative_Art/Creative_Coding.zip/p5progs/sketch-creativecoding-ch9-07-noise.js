// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// noise.pde, chapter 9-07 - Figure 9.15-18 
// Description: Ch 9-07 Figure 9.15-18 - Visualization of 2D perlin noise in a variety of shapes


let data = []; // 2d array of float[500][500];
let dataLen = 500;
let shapeFunction = 0; // 0 - asSquareColor; 1 - asPoint; 2 - asSquare3D; 3 - asRotation; 

function setup() {
	createCanvas(500, 500);
	smooth();
	genNoise(data);
	if (shapeFunction == 0){asSquareColor(data);}
	else if (shapeFunction == 1){asPoint(data);}
	else if (shapeFunction == 2){asSquare3D(data);}
	else if (shapeFunction == 3){asRotation(data);}
} // end setup()

function genNoise() {
	let noiseScale=0.015;
	noiseDetail(2, 0.5);
	for (let i=0; i < dataLen; i++) {
		data[i] = [];
		for (let j=0; j< dataLen; j++) {
			data[i][j] = float(noise(j*noiseScale, i*noiseScale));
		}//for
	}//for
} // end genNoise()

function asSquareColor(data) {
	let s = 10;
	background(0);
	for (let i = 0; i < data.length; i+=s) {
		for (let j = 0; j < data[i].length; j+=s) {
			stroke(255, data[i][j]*255, 0); //orange
			//stroke(data[i][j]*255, 200, 25); //green variaion
			//stroke(0, data[i][j]*255, 255); //blue variation
			strokeWeight(2);
			noFill();
			push();
				translate(j, i);
				rect(0, 0, data[i][j]*s*2, data[i][j]*s*2);
			pop();
		}
	}
} // end asSquareColor()

function asPoint(data) {
	background(0);
	for (let i = 0; i < data.length; i++) {
		for (let j = 0; j < data[i].length; j++) {
			//stroke(data[i][j]*255); // grayscale colors
			stroke(0, 255*data[i][j], 255-255*data[i][j]); //blue to green colors
			ellipse(j, i, 1, 1);
		}//for
	}//for
} // end asPoint()

function asSquare3D(data) {
  	let s = 10;
	background(0);
	for (let i = 0; i < data.length; i+=s) {
		for (let j = 0; j < data[i].length; j+=s) {
			strokeWeight(2);
			stroke(data[i][j]*255);
			noFill();
			push();
				translate(j, i, data[i][j]*s*2);
				// the larger data[i][j] is, the closer the square is drawn to screen
				rect(0, 0, data[i][j]*s, data[i][j]*s);
			pop();
	}//for
  }//for
} // end asSquare3D()

function asRotation(data) {
	let s = 5;
	background(0);
	for (let i = 0; i < data.length; i+=s) {
		for (let j = 0; j < data[i].length; j+=s) {
			stroke(255, 50);
			strokeWeight(2);
			push();
				translate(j, i);
				// the larger data[i][j] is, the closer to 2PI we rotate
				rotate(data[i][j]*PI*2);
				line(0, 0, s*4, 0);
			push();
		}//for
	}//for
} // end asRotation()
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-07-noise.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// blackWhite2.pde, chapter 9-12 Figure 9-24
// Description: Ch 9-12 Figure 9-24 - Converts an image to grayscale, via sketch window pixel buffer

var img;

function preload(){
	img = loadImage("data/lenna.jpg")
}

function setup() {
	createCanvas(512,512);
	image(img, 0, 0);
	img.loadPixels();
	for (let x=0; x<img.width; x++) {
		for (let y=0; y<img.height; y++) {
    		let c = color(img.get(x,y));
      		let gScale = round(red(c) * 0.299 + green(c) * 0.587 + blue(c) * 0.071);  		
    		img.set(x,y,gScale);
     	} //for
 	} //for
	img.updatePixels();
	image(img, 0, 0);
} // end setup()
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-12-blackWhite2.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// sketch_6_6.pde, chapter 6-06 Figure 6.18
// Description: Ch 6-06 Figure 6.18 Widgets, discs and hexagons

var d; // disc
var h; // hexagon

function setup() {
	createCanvas(500, 500);
	smooth();
  
	var dLocation = createVector(random(width),random(height));
	var dSize = 30;
	var dColor = 0;
	d = new disc(dLocation, dSize, dColor);

	var hLocation = createVector(random(width),random(height));
	var hSize = 30;
	var hColor = 0;
	h = new hexagon(hLocation, hSize, hColor);
  
} // setup()

function draw() {
	background(255);
	d.move();
	d.display();
	h.move();
	h.display();
} // draw()

class widget {
	constructor(loc, s, c){
		this.location = loc; // p5.Vector
		this.sz = s; // size
		this.col = c; // color
	}
} // class widget

class disc extends widget {
	constructor(loc, s, c){
		super(loc, s, c);
		this.r = s/2.0;
		this.speed = createVector(random(1, 3), random(1, 3));
	}
	display() {
		noStroke();
		fill(this.col);
		ellipse(this.location.x, this.location.y, this.sz, this.sz);
	} // display()
	
	setSpeed(s) {
		this.speed = s;
	} // setSpeed() 
	 
	move() {
		this.location.add(this.speed);
		this.bounce();
	} // move()
	
	bounce() {
		if (this.location.x > (width-this.r)) { // bounce against the right edge
			this.location.x = width-this.r;
			this.speed.x = -this.speed.x;
		}
		if (this.location.x < this.r) { // bounce against the left edge
			this.location.x = this.r;
			this.speed.x = -this.speed.x;
		}
		if (this.location.y > (height-this.r)) { // bounce against the bottm edge
			this.location.y = height-this.r;
			this.speed.y = -this.speed.y;
		}
		if (this.location.y < this.r) { // bounce against the top edge
			this.location.y = this.r;
			this.speed.y = -this.speed.y;
		}
	} // bounce() 
} // class disc

class hexagon extends widget {
	constructor(loc, s, c){
		super(loc, s, c);
		this.nSides = 6;
		this.theta = 0.0;
		this.r = this.sz/2.0;
		this.rot = 0.0;
		this.speed = createVector(random(-2,2), random(-2,2));
	}
	display() {
		noStroke();
		fill(this.col);
		beginShape();
			for (var i = 0; i <this.nSides; i++){
				var x1 = this.location.x + this.r*cos(this.theta);
				var y1 = this.location.y + this.r*sin(this.theta);
				vertex(x1, y1);
				this.theta += PI/3.0;
			}
		endShape();
	} // display()
	
	setSpeed(s) {
		s.mult(-2);
		this.speed = s;
	} // setSpeed() 
	 
	move() {
		this.rot += 0.01;
		this.location.add(this.speed);
		this.bounce();
	} // move()
	
	bounce() {
		if (this.location.x > (width-this.r)) { // bounce against the right edge
			this.location.x = width-this.r;
			this.speed.x = -this.speed.x;
		}
		if (this.location.x < this.r) { // bounce against the left edge
			this.location.x = this.r;
			this.speed.x = -this.speed.x;
		}
		if (this.location.y > (height-this.r)) { // bounce against the bottm edge
			this.location.y = height-this.r;
			this.speed.y = -this.speed.y;
		}
		if (this.location.y < this.r) { // bounce against the top edge
			this.location.y = this.r;
			this.speed.y = -this.speed.y;
		}
	} // bounce() 
} // class disc
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch6-06-widget_disc_hexagon.jpg')
}

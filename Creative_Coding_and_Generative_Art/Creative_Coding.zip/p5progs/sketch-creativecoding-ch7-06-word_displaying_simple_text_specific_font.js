// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// sketch_7_6.pde, chapter 7-06 Figure 7.3
// Description: Ch 7-06 Figure 7.3 Displaying simple text with specific font.

var sentence = "A man, a plan, a canal, Panama.";
var tnr;

function preload(){
	tnr = loadFont("data/Times-New-Roman.ttf");
}

function setup() {
  createCanvas(400, 100);
  smooth();
} // setup()

function draw() {
  background(200);
  fill(0);
  textSize(24);
  text(sentence, 10, height/2);
} // draw()
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch7-06-word_displaying_simple_text_specific_font.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013
// sketch_factorial.pde, chapter 8-01 No Figure
// Description: Ch 8-01 No Figure Compute factorial of a non-negative integer using recursion

function setup() {
	var n = 5;
	var f = factorial(n);
	fill(0);
	textSize(20);
	text(n+"! = "+ f, 20, height/2);
}

function factorial(n) {
	if (n == 0) {
		return 1;
	} 
	else {
		return n*factorial(n-1);
	}
} 
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch8-01-factorial.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// algorithmic_face.pde, chapter 2-04 Figure 2.13
// Description: Ch 2-04 Figure 2.13 Simple Face - Algorithmic approach to drawing a face.

function setup(){
	createCanvas(600, 800);
	background(0);
	stroke(255);
	noFill();
	// draw ellipses from top left corner
	ellipseMode(CORNER); 

	// BEGIN DECLARE/INITIALIZE VARIABLES
	// HEAD 
	var headHeight = 600;
	var headWidth = headHeight*5/7;
	var head_x = (width-headWidth)/2;
	var head_y = (height-headHeight)/2;

	// EYES
	var eyeWidth = headWidth/5;
	var eyeHeight = eyeWidth/2;
	var irisDiam = eyeHeight;
	var pupilDiam = irisDiam/3;
	var eye_y = head_y+headHeight/2-eyeHeight/2;
	// left
	var leftEye_x = head_x+eyeWidth;
	var leftIris_x = leftEye_x + eyeWidth/2-irisDiam/2;
	var leftPupil_x = leftEye_x + eyeWidth/2-pupilDiam/2;
	// right
	var rightEye_x = head_x+eyeWidth*3;
	var rightIris_x = rightEye_x + eyeWidth/2-irisDiam/2;
	var rightPupil_x = rightEye_x + eyeWidth/2-pupilDiam/2;

	//EYEBROWS
	var eyeBrowWidth = eyeWidth*1.25;
	var eyeBrowHeight = eyeHeight/4;
	var eyeBrow_y = eye_y - eyeHeight - eyeBrowHeight/2;
	// left
	var leftEyeBrow_x = leftEye_x - (eyeBrowWidth-eyeWidth);
	// right
	var rightEyeBrow_x = rightEye_x;

	// NOSE
	var nose_x = head_x+eyeWidth*2;
	var nose_y = head_y + headHeight - headHeight/4;

	// MOUTH
	var mouthWidth = eyeWidth*1.5;
	var mouthHeight = headHeight/12;
	var mouth_x = leftIris_x+irisDiam/2+eyeWidth/4;
	var mouth_y = nose_y + mouthHeight;

	// EARS
	var earWidth = eyeHeight*1.5;
	var earHeight = headHeight/4;
	var ear_y = eyeBrow_y;
	// left
	var leftEar_x = head_x-earWidth/2;
	// right
	var rightEar_x = head_x+headWidth-earWidth/2;

	// BEGIN DRAWING
	// Draw head
	ellipse(head_x, head_y, headWidth, headHeight); 
	// left eye
	ellipse(leftEye_x, eye_y, eyeWidth, eyeHeight);
	// Draw left iris
	ellipse(leftIris_x, eye_y, irisDiam, irisDiam);
	// Draw left pupil
	ellipse(leftPupil_x, eye_y+eyeHeight/2-pupilDiam/2, pupilDiam, pupilDiam);
	// Draw right eye
	ellipse(rightEye_x, eye_y, eyeWidth, eyeHeight); 
	// Draw right iris
	ellipse(rightIris_x, eye_y, irisDiam, irisDiam);
	// Draw right pupil
	ellipse(rightPupil_x, eye_y+eyeHeight/2-pupilDiam/2, pupilDiam, pupilDiam);
	// Draw left eyebrow
	rect(leftEyeBrow_x, eyeBrow_y, eyeBrowWidth, eyeBrowHeight);
	// Draw right eyebrow
	rect(rightEyeBrow_x, eyeBrow_y, eyeBrowWidth, eyeBrowHeight);
	// Draw nose
	triangle(nose_x, nose_y, nose_x+eyeWidth, nose_y, nose_x + eyeWidth/2, nose_y-eyeWidth);
	// Draw Mouth - top lip
	arc(mouth_x, mouth_y-mouthHeight/2, mouthWidth, mouthHeight, PI, TWO_PI);
	// Draw Mouth - bottom lip
	arc(mouth_x, mouth_y-mouthHeight/2, mouthWidth, mouthHeight, 0, PI);
	// Draw Mouth – crease
	line(mouth_x, mouth_y, mouth_x+mouthWidth, mouth_y);
	// Draw left ear
	arc(leftEar_x, ear_y, earWidth, earHeight, PI/2.3, PI*1.55);
	// Draw right ear
	arc(rightEar_x, ear_y, earWidth, earHeight, -PI/1.8, PI/1.8);
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch2-04-algorithmic_face.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// curveEllipse.pde, chapter 4-16 Figure 4.16
// Description: Ch 4-16 Figure 4.16 Closed curve ellipse. Utlilizes cubic curve implementation of Catmull-Rom spline.

function setup() {
	createCanvas(600, 600);
	background(255);
	translate(width/2, height/2);
	curveEllipse(4, 250, 4, -.675);
}

function curveEllipse(pts, radius, handleRadius, tightness) {
	var theta = 0;
	var cx = 0, cy = 0;
	var ax = 0, ay = 0;
	var rot = TWO_PI/pts;

	curveTightness(tightness);
	beginShape();
		for (var i=0; i<pts; i++) {
			// need control before vertex 1 along the ellipse
			if (i==0) {
				cx = cos(theta - rot)*radius;
				cy = sin(theta - rot)*radius;
				ax = cos(theta)*radius;
				ay = sin(theta)*radius;
				curveVertex(cx, cy);
				curveVertex(ax, ay);
			} 
			else {
				ax = cos(theta)*radius;
				ay = sin(theta)*radius;
				curveVertex(ax, ay);
			}
			// close ellipse
			if (i==pts-1) {
				cx = cos(theta + rot)*radius;
				cy = sin(theta + rot)*radius;
				ax = cos(theta + rot*2)*radius;
				ay = sin(theta + rot*2)*radius;
				curveVertex(cx, cy);
				curveVertex(ax, ay);
			}

			// draw anchor points/control points
			fill(255, 127, 0);
			ellipse(cos(theta)*radius, sin(theta)*radius, handleRadius*2, handleRadius*2);

			theta += rot;
		}
		fill(0, 127);
		noStroke();
	endShape();
} // end curveEllipse
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch4-16-curveEllipse.jpg')
}

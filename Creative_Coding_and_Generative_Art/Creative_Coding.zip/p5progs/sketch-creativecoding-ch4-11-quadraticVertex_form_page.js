// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// quadraticVertex_form_page.pde, chapter 4-11 Figure 4.11
// Description: Ch 4-11 Figure 4.11 Examples of randomized, closed quadratic curves.

function setup() {
	createCanvas(800, 800);
	background(0);
	var cols = 5;
	var rows = 5;
	var formWidth = width/cols;
	var formRadius = formWidth/2;
	var formRadiusMin = 25;
	fill(255);
	for (var i=0; i<rows; i++) {
		for (var j=0; j<cols; j++) {
			push();
				translate(formRadius+formWidth*j, formRadius+formWidth*i);
				quadForm(int(random(3, 25)), random(formRadiusMin, formRadius), random(formRadiusMin, formRadius));
			pop();
		}
	}
}

function quadForm(limbs, controlRadius, limbRadius) {
	var theta = 0;
	beginShape();
	var cx = 0;
	var cy = 0;
	var ax = 0;
	var ay = 0;
	var rot = TWO_PI/(limbs*2);
	for (var i=0; i<limbs; i++) {
		cx = cos(theta)*controlRadius;
		cy = sin(theta)*controlRadius;
		theta += rot;
		ax = cos(theta)*limbRadius;
		ay = sin(theta)*limbRadius;
		if (i==0) {
			// initial vertex required for quadraticVertex()
			vertex(ax, ay);
		} 
		else {
			quadraticVertex(cx, cy, ax, ay);
		}
		theta += rot;

		// close form
		if (i == limbs-1) {
			cx = cos(0)*controlRadius;
			cy = sin(0)*controlRadius;
			ax = cos(rot)*limbRadius;
			ay = sin(rot)*limbRadius;
			quadraticVertex(cx, cy, ax, ay);
		}
	}
  endShape();
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch4-11-quadraticVertex_form_page.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// bezierEllipse_page.pde, chapter 4-14 Figure 4.14
// Description: Ch 4-14 Figure 4.13 Examples of randomized, closed Bezier curves.

function setup() {
	createCanvas(800, 800);
	background(0);
	var cols = 10;
	var rows = 10;
	var formWidth = width/cols;
	var formRadius = formWidth/2;
	fill(255);
	for (var i=0; i<rows; i++) {
		for (var j=0; j<cols; j++) {
			push();
				translate(formRadius+formWidth*j, formRadius+formWidth*i);
				bezierEllipse(int(random(3, 25)), random(-formWidth/2, formRadius), random(-formWidth/2, formRadius));
			pop();
		}
	}
}

function bezierEllipse(pts, radius, controlRadius) {
	//var theta = 0;
	beginShape();
	var cx1 = 0;
	var cy1 = 0;
	var cx2 = 0;
	var cy2 = 0;
	var ax = 0;
	var ay = 0;
	var rot = TWO_PI/pts;
	var theta = 0;
	var controlTheta1 = rot/3.0;
	var controlTheta2 = controlTheta1*2.0;
	// var controlRadius = radius/cos(controlTheta1); randomized now


	for (var i=0; i<pts; i++) {
		cx1 = cos(theta + controlTheta1)*controlRadius;
		cy1 = sin(theta + controlTheta1)*controlRadius;
		cx2 = cos(theta + controlTheta2)*controlRadius;
		cy2 = sin(theta + controlTheta2)*controlRadius;
		ax = cos(theta+rot)*radius;
		ay = sin(theta+rot)*radius;

		if (i==0) {
			// initial vertex required for bezierVertex()
			vertex(cos(0)*radius, sin(0)*radius);
		} 
		// close ellipse
		if (i==pts-1) {
			bezierVertex(cx1, cy1, cx2, cy2, cos(0)*radius, 
			sin(0)*radius);
		}
		// ellipse body
		else {
			bezierVertex(cx1, cy1, cx2, cy2, ax, ay);
		}

		theta += rot;
	}
	stroke(255);
	noFill();
	endShape();
} // end bezierEllipse
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch4-14-bezierEllipse_page.jpg')
}

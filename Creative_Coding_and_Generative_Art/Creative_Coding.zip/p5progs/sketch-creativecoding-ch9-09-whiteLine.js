// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// whiteline.pde, chapter 9-09 - Figure 9.21 
// Description: Ch 9-09 Figure 9.21 - Draws a white line at the middle of the screen (height) of a single pixel width.
// 
function setup() {
	createCanvas(500, 500);
	background(0);
	
	let img = createImage(500,500)
	loadPixels();

	for (let x = 0; x < width; x++) {
		img.set(x,height/2,color(255));
	}
	
	img.updatePixels();
	image(img, 0, 0);
} // end setup() 
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-09-whiteLine.jpg')
}

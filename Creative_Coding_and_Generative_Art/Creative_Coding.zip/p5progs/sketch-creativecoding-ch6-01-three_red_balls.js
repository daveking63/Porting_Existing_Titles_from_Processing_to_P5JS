// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// sketch_6_1.pde, chapter 6-01 Figure 6.2
// Description: Ch 6-01 Figure 6.2 Display 3 red ball objects.

var b1, b2, b3;

function setup() {
  createCanvas(400, 400);
  smooth();  
  // create the balls
  b1 = new ball();
  b2 = new ball();
  b3 = new ball();
} // setup()

function draw() {
  background(255);
  b1.display();
  b2.display();
  b3.display(); 
} // draw()

class ball {// Define the ball class
  constructor(){
  	  this.x = random(width);
  	  this.y = random(height);
  	  this.radius = 25;
      this.ballColor = color(255, 0, 0);
 	}
  display(){
  	noStroke();
    fill(this.ballColor);
    ellipse(this.x, this.y, 2*this.radius, 2*this.radius);
  } 
} // class ball

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch6-01-three_red_balls.jpg')
}

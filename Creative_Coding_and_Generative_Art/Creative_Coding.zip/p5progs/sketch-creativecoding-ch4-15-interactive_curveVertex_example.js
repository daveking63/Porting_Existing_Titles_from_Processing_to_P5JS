// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// interactive_curveVertex_example.pde, chapter 4-15 Figure 4.15
// Description: Ch 4-15 Figure 4.15 Interactively manipulate spline curve including changing curve tension.

var ax0, ay0, ax1, ay1, ax2, ay2, ax3, ay3, ax4, ay4;
var isOnAnchor0, isOnAnchor1, isOnAnchor2, isOnAnchor3, isOnAnchor4;
var radius = 5;
var curvature = 0;

function setup() {
	createCanvas(500,500);
	background(255);

	ax0 = random(100, width-100);
	ax1 = random(100, width-100);
	ax2 = random(100, width-100);
	ax3 = random(100, width-100);
	ax4 = random(100, width-100);

	ay0 = random(100, height-100);
	ay1 = random(100, height-100);
	ay2 = random(100, height-100);
	ay3 = random(100, height-100);
	ay4 = random(100, height-100);
	
	// slider bar for intractive curvature
	slider = createSlider(0, width/2, 0, 0)
	slider.position(40, 40);
	slider.style('width', '80px');

}

function draw() {
	background(255);
	noFill();
	strokeWeight(4);
	stroke(0);

	curveTightness(curvature);
	// draw curve
	beginShape();
	curveVertex(ax0, ay0); // double inital point
	curveVertex(ax0, ay0);
	curveVertex(ax1, ay1);
	curveVertex(ax2, ay2);
	curveVertex(ax3, ay3);
	curveVertex(ax4, ay4);
	curveVertex(ax4, ay4); // double final point
	endShape();

	// draw control/anchor points
	strokeWeight(1);
	fill(255, 127, 0);
	ellipse(ax0, ay0, radius*2, radius*2);
	ellipse(ax1, ay1, radius*2, radius*2);
	ellipse(ax2, ay2, radius*2, radius*2);
	ellipse(ax3, ay3, radius*2, radius*2);
	ellipse(ax4, ay4, radius*2, radius*2);

	sVal = slider.value();
	curvature = map(sVal, 0, width/3, -3, 3);

} // END draw()

function mouseDragged() {
	// move points
	//detect if mouse is on control/anchor point
	if (dist(mouseX, mouseY, ax0, ay0) < radius) {
		isOnAnchor0 = true;
	} 
	else if (dist(mouseX, mouseY, ax1, ay1) < radius) {
		isOnAnchor1 = true;
	} 
	else if (dist(mouseX, mouseY, ax2, ay2) < radius) {
		isOnAnchor2 = true;
	} 
	else if (dist(mouseX, mouseY, ax3, ay3) < radius) {
		isOnAnchor3 = true;
	} 
	else if (dist(mouseX, mouseY, ax4, ay4) < radius) {
		isOnAnchor4 = true;
	}

	if (isOnAnchor0) {
		ax0 = mouseX;
		ay0 = mouseY;
	} 
	else if (isOnAnchor1) {
		ax1 = mouseX;
		ay1 = mouseY;
	} 
	else if (isOnAnchor2) {
		ax2 = mouseX;
		ay2 = mouseY;
	} 
	else if (isOnAnchor3) {
		ax3 = mouseX;
		ay3 = mouseY;
	} 
	else if (isOnAnchor4) {
		ax4 = mouseX;
		ay4 = mouseY;
	}

} // END mouseDragged()

// ensure boolean flags set back to false when mouse released
function mouseReleased(){
	isOnAnchor0 = isOnAnchor1 = isOnAnchor2 = isOnAnchor3 = isOnAnchor4 = isOnSliderHandle = false;
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch4-15-interactive_curveVertex_example.jpg')
}

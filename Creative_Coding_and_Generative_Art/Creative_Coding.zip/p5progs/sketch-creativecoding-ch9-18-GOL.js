// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// GOL.pde, chapter 9-18 Figure 9.35-38
// Description: Ch 9-18 Figure 9.35-38 - Conway's Game of Life implemented on a 50x50 grid

// Flags and game parameters
let N = 50;               // Grid Dimension
let cellSize = 10;        // Size of cell
let cur = 0;              // Current grid index
let nxt = 1;              // next grid index

// CA consists of two grids for current and next step
let CA = []; //new boolean[N][N][2];

function setup() {
	createCanvas(500, 500);
	randomizeGrid(cur);
} // end setup()

function draw() {
	background(255);
	drawCells();
	advanceGame();
} // end draw()

function advanceGame() {
	for (let i=0; i<N; i++) {
		for (let j=0; j<N; j++) {
			// Count location neighbors
			let neighbors = countNeighbors(i, j);

			// If the cell is alive ...
			if (CA[i][j][cur] == true) {
				if (neighbors < 2 || neighbors > 3) {
					CA[i][j][nxt] = false;
				} //if
				else {
					CA[i][j][nxt] = true;
				} //else
			} //if
			else {
				if (neighbors == 3) {
					CA[i][j][nxt] = true;
				} //if
				else {
					CA[i][j][nxt] = false;
				}//else
			}//else
		}//for
	}//for

	// Swap grid indices
	let tmp = cur;
	cur = nxt;
	nxt = tmp;
} // end advanceGame()

// Count the number of live neighbors of current cell
function countNeighbors(i, j) {
	let count = 0;
	for (let ii=i-1; ii<=i+1; ii++) {
		for (let jj=j-1; jj<=j+1; jj++) {
		// Wrap edges of board
			let iii = (ii + N) % N;
			let jjj = (jj + N) % N;

			// Skip center location
			if (iii!=i || jjj!=j){
				if ( CA[iii][jjj][cur] == true ){
					count++;
				}//if
			}//if
		}//for
	}//for
	return count;
} // end countNeighbors()

function drawCells() {
	for (let i=0; i<N; i++) {
		for (let j=0; j<N; j++) {
			if (CA[i][j][cur] == true) {
				fill(0);
				noStroke();
			}//if
			else {
				fill(255);
				stroke(240);
			}//else
			rect(i*cellSize, j*cellSize, cellSize, cellSize);
		}//for
	}//for
} // end drawCells()

// Randomly set 20% of cells alive
function randomizeGrid(c) {
	for (let i=0; i<N; i++) {
		CA[i] = [];
		for (let j=0; j<N; j++) {
			CA[i][j] = [];
			// set 20% of cells alive
			if (random(0, 1) < .2) {
				CA[i][j][c] = true;
			}//if
		}//for
	}//for
} // end randomizeGrid()
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-18-GOL.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// arcs_example.pde, chapter 2-05 Figure 2.17
// Description: Ch 2-05 Figure 2.17 Creates a page of randomized arcs.

var cols;
var rows;
var cellW;
var cellH;

function setup(){
  createCanvas(1000, 1000);
  background(255);
  fill(0);
  textFont("Arial");
  textSize(18);
  cols = 4; 
  rows = 4;

  cellW = width/cols;
  cellH = height/rows;

  for (var i=0; i<rows; i++){
    for (var j=0; j<cols; j++){
      makeArc(cellW/2+cellW*j, cellH/2+cellH*i, cellW*.5, cellH*.5, random(PI), random(PI, TWO_PI));
    }
  }
}

function makeArc(x, y, w, h, t1, t2){
  arc(x, y, w, h, t1, t2);
  text("start = " + round(degrees(t1)) + " degs", x-w/2, y+h*.75);
  text("end = " + round(degrees(t2)) + " degs", x-w/2, y+h*.925);
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch2-05-arcs_examples.jpg')
}

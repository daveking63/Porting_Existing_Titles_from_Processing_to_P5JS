// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// grayScaleTrigAnimation.pde, chapter 9-06 - Figure 9.15
// Description: Ch 9-06 Figure 9.15 - 2D array with periodic gradient shading visualized with continuous animation

let rows = 100;
let cols = 100;
let grays = [] //2D of [rows][cols];
let incs = [] //2D of [rows][cols];
let cellSize = 5;
let cMode = 0; // 0 - grayscale; 1 - HSB color mode

function setup() {
	createCanvas(500, 500);
	noStroke();

	if (cMode == 1){colorMode(HSB);}

	for (let i = 0; i < rows; i++) {
		grays[i] = [];
		incs[i] = [];
		for (let j = 0; j < cols; j++) {
			let x = map(i, 0, rows-1, 0, 2*PI);
			let y = map(j, 0, cols-1, 0, 2*PI);
			let z = sin(x)*cos(y);
			grays[i][j] = map(z, -1.0, 1.0, 0.0, 255.0);
			incs[i][j] = 1;
		}//for
	}//for
}//setup

function draw() {
	background(255);
	for (let i = 0; i < rows; i++) {
		for (let j = 0; j < cols; j++) {
			fill(grays[i][j]);
		if (cMode == 1){fill(grays[i][j], 255, 255);} // for colorMode HSB
			
			push();
				// j is the column index, which correspond to the x  screen coordinate
				translate(j*cellSize, i*cellSize); 
				rect(0, 0, cellSize, cellSize);
			pop();

		if (grays[i][j] > 255 || grays[i][j] < 0){incs[i][j] = -incs[i][j];}
		grays[i][j] += incs[i][j];
		}//for
	}//for
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch9-06-grayScaleTrigAnimation.jpg')
}

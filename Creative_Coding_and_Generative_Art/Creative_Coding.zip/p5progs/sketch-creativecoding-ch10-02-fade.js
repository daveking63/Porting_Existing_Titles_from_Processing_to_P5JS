// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// fade.pde, Chapter 10-02 No Figure
// Description: Ch 10-02 No Figure - Fading in and out an array of images

let img = []; //new PImage[5];
let imgLen = 5;
let alpha = 255;
let cur = 0, nxt = 1;

function preload(){
  for (let i=0; i<imgLen; i++) {
    img[i] = loadImage("data/bmc"+i+".jpg");
  }
}

// fade.pde, Chapter 10
// Fading in and out an array of images

function setup() {
	createCanvas(600, 450);     // use the largest dimension from all images
	imageMode(CENTER);
	// Load images, named bmc0.jpg, bmc1.jpg, ... etc
}// end setup()

function draw() {
	background(255);  
	// Fade out current image
	tint(255, alpha);
	image(img[cur], width/2, height/2);  
	// Fade in next image
	tint(255, 255-alpha);
	image(img[nxt], width/2, height/2);
	alpha--;

	// Swap images when fade complete
	if (alpha < 0) {
		cur = nxt;
		nxt = (cur+1)%img.length;
		alpha = 255;
	}
}// end draw()

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch10-02-fade.jpg')
}

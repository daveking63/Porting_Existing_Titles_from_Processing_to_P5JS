// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// ilterGrayInvert.pde, chapter 10-07 Figures 10.13
// Description: Ch 10-07 Figures 10.13 -  Demo of the GRAY and INVERT filters

let imgs = []; //PImage[] imgs = new PImage[3];
let imgLen = 3;
let imgWid = 434; //434 x 434 image - woods2.jpg
let imgHgt = 434;

function preload(){
	for (let i=0; i<imgLen; i++) {
		imgs[i] = loadImage("data/woods2.jpg"); 
	}
}

function setup() {
  let cWid = 434 * 3;
  createCanvas(cWid,imgHgt);  // 3 times as wide as the original image 
  imgs[1].filter(GRAY);  // grayscal
  imgs[2].filter(INVERT); // invert
  for (let i=0; i<imgs.length; i++) {
    image(imgs[i], imgs[0].width*i, 0);
  }  
} // end setup()

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch10-07-filterGrayInvert.jpg')
}

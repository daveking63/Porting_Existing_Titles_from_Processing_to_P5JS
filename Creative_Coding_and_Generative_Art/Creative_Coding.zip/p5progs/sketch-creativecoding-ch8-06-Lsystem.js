// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// Lsystem.pde, chapter 8-06 Figure 8.21-38
// Description: Ch 8-06 Figure 8.21-38 Lindenmayer Systems

// 0 - Koch Curve; 1 - Koch Snowflake; 2 - Dragon;
// 3 - Quadratic Flake; 4 - Twig; 5 - 

var lSysType = 3;

function setup(){
	createCanvas(800, 800);
	background(255);

	// each block is an individual L-system including 
	//initialization and rendering commands
	// try uncommenting and testing the blocks one by one

	if (lSysType == 0) {
		kochCurve = new Lsys();
		kochCurve.setAxiom("F");
		kochCurve.addRule("FF+F-F-F+F");
		kochCurve.genString(3);
		strokeWeight(2);
		translate(10, height/2);
		kochCurve.render(25, 90);
	}
	else if (lSysType == 1){
		kochSnowFlake = new Lsys();
		kochSnowFlake.setAxiom("F++F++F");
		kochSnowFlake.addRule("FF-F++F-F");
		kochSnowFlake.genString(3);
		strokeWeight(2);
		translate(width/8, height*3/4);
		kochSnowFlake.render(20, 60);
	}
	else if (lSysType == 2){
		dragon = new Lsys();
		dragon.setAxiom("FX");
		dragon.addRule("XX+YF+");
		dragon.addRule("Y-FX-Y");
		dragon.genString(14);
		strokeWeight(2);
		translate(width*3/4, height/2);
		rotate(radians(90));
		dragon.render(4, 90);
	}
	else if (lSysType == 3){
		quadricFlake = new Lsys();
		quadricFlake.setAxiom("F+F+F+F");
		quadricFlake.addRule("FF+F-F-FF+F+F-F");
		quadricFlake.genString(3);
		translate(width/4, height*3/4);
		quadricFlake.render(5, 90);
	}
	else if (lSysType == 4){
		twig = new Lsys();
		twig.setAxiom("F");
		twig.addRule("FF[-F]F[+F]F");
		twig.genString(3);
		translate(width/2, height);
		rotate(radians(-90));
		strokeWeight(2);
		twig.render(25, 27);
	}
	else if (lSysType = 5){
		plant = new Lsys();
		plant.setAxiom("X");
		plant.addRule("XF-[[X]+X]+F[+FX]-X");
		plant.addRule("FFF");
		plant.genString(6);
		var green = color(90, 127, 51);
		gradientBg(green);
		stroke(green);
		translate(100, height);
		rotate(radians(110));
		scale(-1, 1);
		plant.render(5, 22.5);
	}
} // end setup()

//draws a gradient background between a lighter version of the given color c 
// (+50 on each channel); this is so that c would stand out as stroke color 
// and off-white (225, 225, 225)

function gradientBg(c) {
	loadPixels();
	for (var x=0; x<width; x++) {
		for (var y=0; y<height; y++) {
			var r = map(height-y, height-1, 0, 225, red(c)+50);
			var g = map(height-y, height-1, 0, 225, green(c)+50);
			var b = map(height-y, height-1, 0, 225, blue(c)+50);
			pixels[y*width+x] = color(r, g, b);
		} //for
    } //for
	updatePixels();
} // end gradientBg()

class Lsys {
	constructor(){
		this.axiom = '';
		this.rules = [];
		this.out = '';
	}// end constructor

	setAxiom(s){
		this.axiom += s;
		this.out += this.axiom;
	}// end setAxiom()

	addRule(rule) {
		this.rules.push(rule);
	}// end addRule;

	// search for a specific rule that starts with character c
	// return the arrayList index if found, -1 if not
	searchRule(c) {
        var srchR = -1;
		for (var i = 0; i < this.rules.length; i++) {
			var r = this.rules[i];
			if (r.charAt(0) == c) {
				srchR = i;
			} //if
		} //for
		return srchR;
	}// end searchRule()

	// apply the rules n times and store the result in out
	genString(n) {
		if (n > 0) {
			var temp = "";
			for (var i = 0; i < this.out.length; i++) {
				var idx = this.searchRule(this.out[i]);
				if (idx == -1) {
				  temp += this.out.substring(i, i+1); //char -> substring of length 1
				} //if
				else {
					var r = this.rules[idx];
					temp += r.substring(1);//substring starting at the 2nd char
				} //else
			} //for
			this.out = temp;
			this.genString(n-1);
		} //if
	}// end genString()

	render(size, angle) {
		for (var i = 0; i < this.out.length; i++) {
			var outChar = this.out[i];
			if (outChar == 'F'){ // move forward, pen down
				line(0, 0, size, 0);
				translate(size, 0);
				//break;
			} //if
			else if (outChar == '+') {// turn left
				rotate(radians(-angle));
				//break;
			} //else if
			else if (outChar == '-') {  // turn right                    
				rotate(radians(angle));
				//break;
			} //else if
			else if (outChar == '[') { // save position and orientation
				push();
				//break;
			} //else if
			else if (outChar == ']') { // restore saved position and orientation
				pop();
				//break;
			} //else if
			else {
				//break;
			}
		} //for
	}// end render()
}// end class Lsys


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch8-06-Lsystem.jpg')
}

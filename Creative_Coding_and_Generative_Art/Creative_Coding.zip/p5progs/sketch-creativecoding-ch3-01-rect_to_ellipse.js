// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// rect_to_ellipse.pde, chapter 3 Figure 3.1
// Description: Ch 3-01 Figure 3-1 Override built-in rect angle function
// Function override works in Processing but not in P5.JS

function setup() {
	createCanvas(400, 400);
	background(100);
	rectangle(width/2, height/2, 300, 300);
}

// overrides Processing's rect function
function rectangle(x, y, w, h) {
	ellipse(x, y, w, h);
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch3-01-rect_to_ellipse.jpg')
}

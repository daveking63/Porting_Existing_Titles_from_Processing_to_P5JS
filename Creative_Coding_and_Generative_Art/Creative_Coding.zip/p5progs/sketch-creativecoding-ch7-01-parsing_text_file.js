// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// sketch_7_1.pde, chapter 7-01 No Figure
// Description: Ch 7-01 No Figure Parsing an input text file

var inputTextFile = 'Obama.txt';
var fileContents = [];
var rawText;
var tokens = [];
var delimiters = " ,./?<>;:'\"[{]}\\|=+-_()*&^%$#@!~";

function preload(){
	textdir = "data/";
	fileContents = loadStrings(textdir + inputTextFile);	
}

function setup(){
	
	// not part of original code - simply for displaying reminder
	createCanvas(400, 300);
	background(225); 
	textSize(15); 
	text("Ch7-01 parsing text: See Console for Output", 30, 150);
	//
	
// Input and parse text file
	rawText = join(fileContents, " ");
	rawText = rawText.toLowerCase();
	tokens = splitTokens(rawText, delimiters);
	// print out the first 50 elements list of tokens
	console.log(tokens.length+" tokens found in file: "+inputTextFile);
	for (var i=0; i < 50 ; i++) {
		console.log(tokens[i]);
}
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch7-01-parsing_text_file.jpg')
}

// Source: Processing: Creative Coding and Generative Art in Processing 2 Edition
// Artist: Ira Greenberg, Dianna Xu, and Deepak Kumar
// SourceType: Book
// Date: 2013

// simple_house2.pde, chapter 2 (Figure 2.11)
// Description: Ch 2-03 Figure 2.11 Simple house drawing simulating perspective.

function setup(){
	createCanvas(800, 600);
	// declare variables
	var houseW = 700;
	var frontHouseW = houseW*.75, houseH = houseW*.5;
	var sideHouseW = houseW-frontHouseW;
	var offset = houseH/7;
	var houseX = width-(frontHouseW+offset), houseY = height-(houseH+offset);
	var perspectiveShift = offset*2;
	var roofH = houseH/2.5;
	var doorW = frontHouseW/8;
	var doorH = doorW*2;
	var doorX = houseX+frontHouseW/2-doorW/2;
	var doorY = houseY + houseH-doorH;
	var windowW = frontHouseW/2-offset-doorW/2;
	var windowH = houseH-doorH-offset*2;
	var windowX = houseX + offset;
	var windowY = houseY + offset;
	var paneGap = 9;
	var paneW = windowW/2-paneGap;
	var paneH = windowH/2-paneGap;
	
	// DRAW HOUSE
	// house front
	rect(houseX, houseY, frontHouseW, houseH);
	// house side
	quad(houseX, houseY, houseX, houseY+houseH, houseX-sideHouseW, houseY+houseH-perspectiveShift, houseX-sideHouseW, houseY+perspectiveShift);
	// roof front
	quad(houseX, houseY, houseX+frontHouseW, houseY, houseX+frontHouseW-sideHouseW/2, houseY-roofH, houseX-sideHouseW/2, houseY-roofH);
	// roof side
	triangle(houseX, houseY, houseX-sideHouseW/2, houseY-roofH, houseX-sideHouseW, houseY+perspectiveShift);
	//door
	rect(doorX, doorY, doorW, doorH);
	//door knob
	ellipse(doorX+doorW*.2, doorY + doorH*.6, doorW*.1, doorW*.1);
	// window left
	rect(windowX, windowY, paneW, paneH);
	rect(windowX + paneW + paneGap, windowY, paneW, paneH);
	rect(windowX, windowY+paneH+paneGap, paneW, paneH);
	rect(windowX + paneW + paneGap, windowY+paneH+paneGap, paneW, paneH);
	// window right
	windowX += windowW+doorW;
	rect(windowX, windowY, paneW, paneH);
	rect(windowX + paneW + paneGap, windowY, paneW, paneH);
	rect(windowX, windowY+paneH+paneGap, paneW, paneH);
	rect(windowX + paneW + paneGap, windowY+paneH+paneGap, paneW, paneH);
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-creativecoding-sketch-ch2-03-simple_house2.jpg')
}

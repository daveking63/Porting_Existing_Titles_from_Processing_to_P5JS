// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: type02.pde in Ch20
// Chapter: Ch20-02 type Figure 20.2
// Description: displaying type backed by colored rectangle
//

let myFont;
function preload(){
	myFont = loadFont("data/AvenirNextLTPro-Demi.otf"); 
}

function setup() {
	createCanvas(600, 400);
	background(92, 39, 44);
	let  xText = 100;
	let  yText = 200;
	let  border = 25;

	textFont(myFont);    
	textSize(48);
	
	let message = "Blueberry Pie!";
	let textWid = textWidth(message);  // find the message width

	fill(60, 55, 196);   // blue color
	rect(xText-border, yText-100, textWid+2*border, 200);
	fill(232, 200, 72);     // draw type in yellow
	text(message, xText, yText);
	noLoop();
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch20-02-type_type02.jpg')
}


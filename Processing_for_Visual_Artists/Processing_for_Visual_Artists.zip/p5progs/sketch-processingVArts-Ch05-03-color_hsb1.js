// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: hsb1.pde in Ch05
// Chapter: Ch05-03 color No Figure
// Description: Setting colors in HSB mode
//
let Hueval = 0;
let Satval = 110;
let Brival = 110;
let MyColor;

function setup() {
   createCanvas(600, 400);
   colorMode(HSB);
   MyColor = color(Hueval, Satval, Brival);
   colorMode(RGB);
   background(MyColor);
}

function draw() {
   Hueval = Hueval+1;
   colorMode(HSB);
   MyColor = color(Hueval, Satval, Brival);
   colorMode(RGB);
   background(MyColor);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch05-03-color_hsb1.jpg')
}


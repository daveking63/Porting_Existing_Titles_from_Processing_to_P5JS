// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: pixels06.pde in Ch16
// Chapter: Ch16-13 images Figure 16.18
// Description: smoothly moving animated image contours from noise
//
let NumLayers = 10;   // smaller values = bigger blobs
let Speed = 20;       // smaller values = faster animation
let WindowSize = 400; // smaller values = smaller window = smoother animation
let pCount = 0;

function setup() {
	createCanvas(WindowSize, WindowSize);
	pixelDensity(1);
}

function draw() {
	background(0);
	loadPixels();
	let color0 = color(35, 160, 255);
	let color1 = color(255, 116, 0);
	let thisColor = color0;
	let  layerHeight = 1.0/NumLayers;
	for (let y=0; y<height; y++) {
		for (let x=0; x<width; x++) {
			let  noiseVal = noise(x*0.015, y*0.015);
			let  noiseBump = lerp(0, layerHeight, (frameCount % Speed)/(1.0*Speed));
			let whichColor = int((noiseVal+noiseBump)/layerHeight);
			let startingColor = (((frameCount/Speed) % 2) == 0) ? 0 : 1;
			if (((whichColor+startingColor) % 2) == 0) thisColor = color0;
			else thisColor = color1;
			if (pCount < 100)
				{print(thisColor);}
        	pCount++;
        	let indx = (x + y * width) * 4;
        	pixels[indx] = red(thisColor);
        	pixels[indx+1] = green(thisColor);
        	pixels[indx+2] = blue(thisColor);
        	pixels[indx+3] = alpha(thisColor);
			//pixels[(y*width)+x] = thisColor;
		}
	}
	updatePixels();
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch16-13-images_pixels06.jpg')
}


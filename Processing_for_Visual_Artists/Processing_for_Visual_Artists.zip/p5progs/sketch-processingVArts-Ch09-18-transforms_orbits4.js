// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: orbits4.pde in Ch09
// Chapter: Ch09-18 transforms Figure 9.20
// Description: animated solar system with two (rect) moons (one using a 'push/pop' pair) orbiting (rect) earth orbiting around (ellipse) sun
//
let SunDiam = 80;

let EarthDiam = 30;
let EarthOrbitRadius = 130;
let EarthAngle = 0;

let MoonDiam = 10;
let MoonOrbitRadius = 50;
let MoonAngle = 0;

let NemDiam = 20;
let NemOrbitRadius = 40;
let NemAngle = 0;

function setup() {
   createCanvas(600, 400);
}

function draw() {
   background(0, 0, 0);    // inky blackness of space
   translate(300, 200);    // move origin to center of screen

   noStroke();
   fill(255, 200, 64);        // yellow-orange
   ellipse(0, 0, SunDiam, SunDiam);  // the mighty Sun

   // rotate around the sun
   rotate(EarthAngle);

   // move out to Earth orbit
   translate(EarthOrbitRadius, 0);

   fill(64, 64, 255);                    // blue-ish
   rect(-EarthDiam/2, -EarthDiam/2, EarthDiam, EarthDiam); // the noble Earth

   // push this transform so we can return to it later
   push();

   // rotate around the Earth
   rotate(MoonAngle);

   // move out to Moon orbit
   translate(MoonOrbitRadius, 0);

   fill(192, 192, 180);                    // gray-ish
   rect(-MoonDiam/2, -MoonDiam/2, MoonDiam, MoonDiam); // the friendly Moon

   // pop the stack, recovering the old transformation
   push();

   // rotate around the Earth
   rotate(NemAngle);

   // move out to Nem orbit
   translate(NemOrbitRadius, 0);

   fill(220, 75, 75);                    // red-ish
   rect(-NemDiam/2, -NemDiam/2, NemDiam, NemDiam); // the evil Nem

   EarthAngle += 0.01;
   MoonAngle += 0.01;
   NemAngle += 0.015;
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch09-18-transforms_orbits4.jpg')
}


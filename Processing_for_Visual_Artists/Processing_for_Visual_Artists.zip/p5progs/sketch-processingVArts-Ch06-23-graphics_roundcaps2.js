// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: roundcaps2.pde in Ch06
// Chapter: Ch06-23 graphics Figure 6.30
// Description: differing end and stroke caps for series of lines
//
function setup() {
   createCanvas(600, 400);
   background(224);
   
   strokeCap(ROUND);
   doLine(100, 50, 300, 150, 500, 50);

   strokeCap(SQUARE);
   doLine(100, 150, 300, 250, 500, 150);
   
   strokeCap(PROJECT);
   doLine(100, 250, 300, 350, 500, 250);
}

function doLine(x0, y0, x1, y1, x2, y2) {
   stroke(0);
   strokeWeight(30);
   line(x0, y0, x1, y1);
   line(x1, y1, x2, y2);
   strokeWeight(2);
   stroke(222, 170, 146);  // red
   line(x0, y0, x1, y1);
   stroke(176, 217, 100);  // green
   line(x1, y1, x2, y2);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch06-23-graphics_roundcaps2.jpg')
}


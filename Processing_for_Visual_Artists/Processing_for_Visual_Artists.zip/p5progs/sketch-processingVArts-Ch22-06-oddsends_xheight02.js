// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: xheight02.pde in Ch22
// Chapter: Ch22-06 oddsends Figure 22.12
// Description: first attempt to draw strips to reflect the heights of various components of a font including base-textAscent-textDescent
//

function preload(){
	myFont = loadFont("data/PlayfairDisplay-Bold.ttf");
}

function setup() {
	createCanvas(600, 400);    
	background(240, 215, 175); 

	textFont(myFont);
	textSize(96);

	let message = "raspberry!";
	let  messageWidth = textWidth(message);
	let xheight = getXHeight();

	// top stripe
	fill(189, 176, 130);
	rect(75, 200-textAscent(), messageWidth, textAscent()-xheight); 

	// center stripe
	fill(126, 189, 152);
	rect(45, 200, messageWidth+60, -xheight);

	// bottom stripe
	fill(145, 185, 189);
	rect(15, 200, messageWidth+120, textDescent()); 


	fill(145, 44, 66);
	text(message, 75, 200);
}

function getXHeight() {
	return(25);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch22-06-oddsends_xheight02.jpg')
}


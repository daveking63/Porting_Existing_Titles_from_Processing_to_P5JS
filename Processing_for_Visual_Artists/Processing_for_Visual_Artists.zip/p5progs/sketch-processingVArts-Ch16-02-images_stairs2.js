// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: stairs2.pde in Ch16
// Chapter: Ch16-02 images Figure 16.3
// Description: stair step display of image with transformations
//

function preload(){
	pic = loadImage("data/myPhoto.jpg");
}

function setup() {
	createCanvas(600, 400);
	background(110, 120, 126);
	for (let i=0; i<5; i++) {
		image(pic, 0, 0, 200, 160);
		translate(100, 60);
	}
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch16-02-images_stairs2.jpg')
}


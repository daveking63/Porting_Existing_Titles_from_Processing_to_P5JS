// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: noise01.pde in Ch11
// Chapter: Ch11-13 random Figure 11.13
// Description: bouncing ball bounded by canvas sides
//
let  Cx, Cy;           // ball center
let  Vx, Vy;           // ball velocity
let  Radius;           // ball radius

function setup() {
   createCanvas(600, 400);
   Cx = 300;
   Cy = 200;
   Radius = 30;
   Vx = 2;
   Vy = 3;
}

function draw() {
   // update the ball
   Cx += Vx;
   Cy += Vy;
   if ((Cx-Radius < 0) || (Cx+Radius >= width)) {
      Vx = -Vx;
      Cx += 2 * Vx;
   }
   if ((Cy-Radius < 0) || (Cy+Radius >= height)) {
      Vy = -Vy;
      Cy += 2 * Vy;
   }

   // draw the ball
   background(128, 103, 103);
   noStroke();
   fill(224, 199, 37);
   ellipse(Cx, Cy, Radius*2, Radius*2);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch11-13-random_noise01.jpg')
}


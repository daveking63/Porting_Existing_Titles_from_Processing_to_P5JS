// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: mouseUpdates1.pde in Ch07
// Chapter: Ch07-12 human No Figure
// Description: printing location of previous pmouseX-pMouseY and current mouseX-mouseY
//
function setup() {
	createCanvas(600, 400);
	frameRate(1);

	background(200);
	textSize(15);
	text('See console for output',230,200);
}

function draw() {
  print("=======================");
  print("draw!  mouse = "+mouseX+" "+mouseY);
  print("      pmouse = "+pmouseX+" "+pmouseY);
}

function mouseMoved() {
  print("moved!  mouse = "+mouseX+" "+mouseY);
  print("       pmouse = "+pmouseX+" "+pmouseY);
}




//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch07-12-human_mouseUpdates1.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: contours01.pde in Ch23
// Chapter: Ch23-01 projects Figure 23.2
// Description: moving contour layers
//
let NumSlices = 12;
let Slices = [];
let SliceOrigins = [];
let noiseField = [];
let layer;

function setup() {
   createCanvas(600, 400, P2D);
   background(0, 0, 0);
   pixelDensity(1);
   buildSlices();
}

function draw() {
	background(0, 0, 0);
	for (let slice=NumSlices-1; slice>=0; slice--) {
		SliceOrigins[slice].x += 0.02;
		SliceOrigins[slice].y += 0.02;
		let offx = int(lerp(-5, 5, noise(SliceOrigins[slice].x)));
		let offy = int(lerp(-5, 5, noise(SliceOrigins[slice].y)));
        //blendModes that work - BLEND, DARKEST, LIGHTEST, DIFFERENCE, SCREEN, HARD_LIGHT, BURN, NORMAL
		blend(Slices[slice], 0, 0, width, height, offx, offy,width, height,NORMAL); 
	}
}

function buildSlices() {
	let sliceColor;
	let orangeColor = color(255, 127, 0, 255); // opaque orange
	let blueColor = color(40, 41, 128, 255);   // opaque blue
	let blackColor = color(0, 0, 0, 0);        // transparent black

	for (let y=0; y<height; y++) {
		noiseField[y] = [];
		for (let x=0; x<width; x++) {
			noiseField[y][x] = noise(x*0.015, y*0.015);
		}
	}
   
	layer = createGraphics(width, height, P2D);
	for (let slice=0; slice<NumSlices; slice++) {
		layer.background(blackColor);
        layer.loadPixels();
		let lerpVal = float(slice*1.0/(NumSlices-1));
		sliceColor = lerpColor(orangeColor, blueColor, lerpVal);
		let minVal = float(slice * 1.0 / NumSlices);
		let maxVal = float((slice+1) * 1.0 / NumSlices);

		for (let y=0; y<height; y++) {
			for (let x=0; x<width; x++) {
				let  noiseVal = noiseField[y][x];
				if ((noiseVal >= minVal) && (noiseVal <= maxVal)) {
                    let layIndx = (x + y * width) * 4;
					layer.pixels[layIndx] = red(sliceColor);
					layer.pixels[layIndx+1] = green(sliceColor);
					layer.pixels[layIndx+2] = blue(sliceColor);
					layer.pixels[layIndx+3] = alpha(sliceColor);
				}
			}
		}
		layer.updatePixels();
		Slices[slice] = layer.get(0, 0, width, height);
		SliceOrigins[slice] = createVector(random(slice*100),random((slice+1)*100));
	}

}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch23-01-projects_contours01.jpg')
}


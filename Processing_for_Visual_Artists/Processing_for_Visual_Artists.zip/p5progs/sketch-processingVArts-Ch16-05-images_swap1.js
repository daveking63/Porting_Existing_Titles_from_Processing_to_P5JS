// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: swap1.pde in Ch16
// Chapter: Ch16-05 images Figure 16.6
// Description: dripping effect by randomly copying pixels above
//

function preload(){
	img = loadImage("data/myPhoto.jpg")
}

function setup() {
	createCanvas(600, 400);
	image(img, 0, 0, 600, 400);
}

function draw() {
	for (let y=1; y<height; y++) {
		for (let x=0; x<width; x++) {
			if (random(1000) > 950) {
				img.set(x, y, img.get(x, y-1));
			}
		}
	}
	img.updatePixels();
	image(img,0,0);
}

//
function keyTyped(){
	if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch16-05-images_swap1.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: balls04.pde in Ch22
// Chapter: Ch22-04 oddsends Figure 22.7
// Description: balls moving in a wraparound window

let Flies = [];
let numFlies = 4;

function  setup() {
	createCanvas(600, 400);
	for (let i = 0; i < numFlies; i++){
		Flies[i] = new Ball();
	}
}

function  draw() {
   background(128, 103, 103);
   for (let i=0; i<Flies.length; i++) {
      Flies[i].render();
      Flies[i].move();
   }
}

class Ball {
	constructor() {
		this.cx = float(random(50, width-50));  
		this.cy = float(random(50, height-50));
		this.vx = float(random(3, -3));  
		this.vy = float(random(3, -3));
		this.radius = float(random(10, 30));
		this.cr = float(random(100, 255)); 
		this.cg = float(random(100, 255)); 
		this.cb = float(random(100, 255)); 
		this.ca = float(random(100, 255));
	}

	render() {
		fill(this.cr, this.cg, this.cb, this.ca);
		ellipse(this.cx, this.cy, 2*this.radius, 2*this.radius);
	}

	move() {
		let noiseScale = 0.02;
		this.radius += lerp(-1, 1, noise(this.cx*noiseScale));
		this.radius = constrain(this.radius, 10, 100);
		this.vx += lerp(-0.25, 0.25, noise(noiseScale*this.cx, noiseScale*this.cy));
		this.vy += lerp(-0.25, 0.25, noise(noiseScale*this.cy, noiseScale*this.cx));
		this.vx = constrain(this.vx, -4, 4);
		this.vy = constrain(this.vy, -4, 4);
		this.cx += this.vx;
		this.cy += this.vy;
		if (this.cx >= width) this.cx -= width;
		if (this.cx < 0) this.cx += width;
		if (this.cy >= height) this.cy = height;
		if (this.cy < 0) this.cy += height;
	}
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch22-04-oddsends_balls04.jpg')
}


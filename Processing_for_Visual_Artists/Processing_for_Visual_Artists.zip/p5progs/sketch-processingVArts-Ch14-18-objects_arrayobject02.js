// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: arrayobject02.pde in Ch14
// Chapter: Ch14-18 objects No Figure
// Description: Object program demonstrating the use of arraylists with objects - no display
//

let peachList = [];
let pWeight;

class Peach {
	constructor(pWeight){
		this.Weight = pWeight;
	}
}
  
function setup() {
	createCanvas(600,400);
    background(200);
	let msg = "See console for results";
	textSize(30);
	text(msg,150,200);

	print('len ' + peachList.length);
	// adding to the end of an array object list by incrementing the list one object at a time
	for (let i = 0; i < 50; i++) {
		pWeight = int(random(2,6)); //hypothetical weights for peach
		peachList[i] = new Peach(pWeight);
  	}
  	print('len ' + peachList.length);
  	
  	// 'push'ing a series of objects on the end of an array object list
  	for (i = 0; i < 5; i++){ 
  	    pWeight = int(random(2,6));	
		peachList.push(new Peach(pWeight));
	}
	print('len ' + peachList.length);
	
	// 'push'ing an object on the end of an array object list
	pWeight = int(random(2,6));
	peachList.push(new Peach(pWeight));
	print('len ' + peachList.length); 	
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch14-18-objects_arrayobject02.jpg')
}


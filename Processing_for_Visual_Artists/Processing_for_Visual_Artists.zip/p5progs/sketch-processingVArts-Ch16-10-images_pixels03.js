// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: pixels03.pde in Ch16
// Chapter: Ch16-10 images Figure 16.15
// Description: making image contours from noise
//
let NumLayers = 10;   
let WindowSize = 400; 

function setup() {
   createCanvas(WindowSize, WindowSize);
}

function draw() {
	background(0);
	loadPixels();
	let color0 = color(35, 160, 255);
	let color1 = color(255, 116, 0);
	let  layerHeight = 1.0/NumLayers;
	for (let y=0; y<height; y++) {
		for (let x=0; x<width; x++) {
			let  noiseVal = noise(x*0.015, y*0.015);

			let thisColor = color0;
			let whichColor = int(noiseVal/layerHeight);
			if (((whichColor) % 2) == 0) thisColor = color0;
			else thisColor = color1;
			set(x, y, thisColor);
		}
	}
	updatePixels();
}

//
function keyTyped(){
	if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch16-10-images_pixels03.jpg')
}


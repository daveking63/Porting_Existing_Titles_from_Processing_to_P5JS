// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: tint1.pde in Ch16
// Chapter: Ch16-14 images Figure 16.19
// Description: tinting an image
//

function preload(){
	myPhoto = loadImage("data/myPhoto.jpg");
}


function setup() {
  createCanvas(600, 450); 
  tint(255, 255, 0);
  image(myPhoto, 0, 0);
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch16-14-images_tint1.jpg')
}


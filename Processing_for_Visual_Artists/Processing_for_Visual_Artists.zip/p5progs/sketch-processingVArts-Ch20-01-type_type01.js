// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: type01.pde in Ch20
// Chapter: Ch20-01 type Figure 20.1
// Description: displaying type
//
let myFont;
function preload(){
	myFont = loadFont("data/AvenirNextLTPro-Demi.otf"); 
}

function setup() {
	createCanvas(600, 400);
	background(92, 39, 44);
	fill(232, 200, 72);  
	textFont(myFont); 
	textSize(48); 
	text("Blueberry Pie!", 50, 100);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch20-01-type_type01.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: curveTangent03.pde in Ch12
// Chapter: Ch12-23 cmcurves Figure 12.29
// Description: Using normal (perpendicular) lines to create additional curves offset from original curve
//
let Xp = [40,  50, 540, 300];
let Yp = [940, 160, 200, 900];

function setup() {
  createCanvas(600, 400);
  background(237, 180, 198);
  noFill();
  curve(Xp[0], Yp[0], Xp[1], Yp[1], Xp[2], Yp[2], Xp[3], Yp[3]);
  
  let  oldx0 = 0;
  let  oldy0 = 0;
  let  oldx1 = 0;
  let  oldy1 = 0;
  let  newx0 = 0;
  let  newy0 = 0;
  let  newx1 = 0;
  let  newy1 = 0;
  let numSteps = 20;
  strokeWeight(2);
  for (let i=0; i<numSteps; i++) {
    let  t = map(i, 0, numSteps-1, 0, 1);
    let  xPos = curvePoint(Xp[0], Xp[1], Xp[2], Xp[3], t);
    let  yPos = curvePoint(Yp[0], Yp[1], Yp[2], Yp[3], t);
    let  xTan = curveTangent(Xp[0], Xp[1], Xp[2], Xp[3], t);
    let  yTan = curveTangent(Yp[0], Yp[1], Yp[2], Yp[3], t);
    let  tanlen = mag(xTan, yTan);
    xTan *= 20/tanlen;
    yTan *= 20/tanlen;
    newx0 = xPos-yTan;
    newy0 = yPos+xTan;
    newx1 = xPos+yTan;
    newy1 = yPos-xTan;
    if (i > 0) {
      line(oldx0, oldy0, newx0, newy0);
      line(oldx1, oldy1, newx1, newy1);
    }
    oldx0 = newx0;
    oldy0 = newy0;
    oldx1 = newx1;
    oldy1 = newy1;
  }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch12-23-cmcurves_curveTangent03.jpg')
}


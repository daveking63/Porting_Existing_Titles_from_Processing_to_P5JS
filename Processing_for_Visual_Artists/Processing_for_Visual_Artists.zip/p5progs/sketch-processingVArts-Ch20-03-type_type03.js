// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: type03.pde in Ch20
// Chapter: Ch20-03 type Figure 20.5
// Description: displaying type backed by nicely arranged colored rectangle
//

let myFont;
function preload(){
	myFont = loadFont("data/AvenirNextLTPro-Demi.otf"); 
}

function setup() {
   createCanvas(600, 400);
   background(92, 39, 44);
   let  xText = 100;
   let  yText = 200;
   let  border = 25;

   textFont(myFont);      // make myFont the active font
   textSize(48);

   let message = "Blueberry Pie!";
   let textWid = textWidth(message);
   let textUpper = textAscent();
   let textLower = textDescent();
   let textHeight = textLower + textUpper;

   xText = (width/2.0) - (textWid/2.0);
   yText = (height/2.0) + (textHeight/2.0);

   noStroke();
   fill(60, 55, 196);      // the blue box
   let  rectTop = yText - textUpper - border;
   let  rectHgt = textHeight + 2*border;
   rect(xText-border, rectTop, textWid+2*border, rectHgt);
   fill(232, 200, 72);     // draw in yellow
   text(message, xText, yText);
   noLoop();
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch20-03-type_type03.jpg')
}


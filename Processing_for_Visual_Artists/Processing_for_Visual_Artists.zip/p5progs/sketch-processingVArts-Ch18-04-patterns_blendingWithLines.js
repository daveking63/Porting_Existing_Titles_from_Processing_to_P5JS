// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: blendingWithLines.pde in Ch18
// Chapter: Ch18-04 patterns Figure 18.33
// Description: Graph of speed of cars using linear blending
//
function setup() {
	createCanvas(600, 400);
	background(210);
	noFill();
	stroke(0);
	strokeWeight(2);
	smooth();
	let  v1 = 0;
	let  v2 = 0.5;
	let  v3 = 1;
	drawSet(v1, v2, v3, false, 50, 50);
	drawSet(v1, v2, v3, true, 50, 250);
}

function drawSet(v1, v2, v3, useCosine, xLeft, yTop) {
	drawBlend(v1, v1, xLeft,     100, yTop, 100, useCosine);
	drawBlend(v1, v2, xLeft+100, 100, yTop, 100, useCosine);
	drawBlend(v2, v2, xLeft+200, 100, yTop, 100, useCosine);
	drawBlend(v2, v3, xLeft+300, 100, yTop, 100, useCosine);
	drawBlend(v3, v3, xLeft+400, 100, yTop, 100, useCosine);
}

function drawBlend(v1, v2, xLeft, wid, yTop, hgt, useCosine) {
	let xRight = xLeft + wid;
	let  oldx = xLeft;
	let  oldy = yTop + (hgt*v1);
	for (let x=xLeft; x<xRight; x++) {
		let  a = map(x, xLeft, xRight-1, 0, 1);
		if (useCosine) a = map(cos(a*radians(180)), 1, -1, 0, 1);
		let  y = yTop + (hgt*lerp(v1, v2, a));
		line(oldx, oldy, x, y);
		oldx = x;
		oldy = y;
	}
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch18-04-patterns_blendingWithLines.jpg')
}


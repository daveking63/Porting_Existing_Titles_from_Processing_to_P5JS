// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: stairs1.pde in Ch16
// Chapter: Ch16-01 images Figure 16.2
// Description: stair step display of image
//

function preload(){
	pic = loadImage("data/myPhoto.jpg");
}

function setup() {
	createCanvas(600, 400);
	background(110, 120, 126);
	for (let i=0; i<5; i++) {
		image(pic, i*100, i*60, 200, 160);
	}
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch16-01-images_stairs1.jpg')
}


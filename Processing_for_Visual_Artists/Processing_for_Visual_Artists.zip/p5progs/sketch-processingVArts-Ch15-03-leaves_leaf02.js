// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: leaf02.pde in Ch15
// Chapter: Ch15-03 leaves No Figure
// Description: skeleton for leaf drawing program
//
// Fall leaves project
// version 0.1, Andrew, 16 April 2009
//

// dimensions of the square drawing area
let Window = 400;

function setup() {
   createCanvas(Window, Window);
   background(200, 190, 143);
   noFill();
}

function draw() {
   drawOneLeaf();
}

function drawOneLeaf() {
   // draw a random leaf
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch15-03-leaves_leaf02.jpg')
}


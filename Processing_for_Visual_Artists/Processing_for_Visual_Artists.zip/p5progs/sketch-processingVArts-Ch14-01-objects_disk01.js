// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: disk01.pde in Ch14
// Chapter: Ch14-01 objects No Figure
// Description: Skeleton structure for object program for 'ghost disks' - aka animated ellipses
//
let Ghost1;

function setup() {
   createCanvas(600, 400);
   background(164, 164, 164);
   // Added only to clarify output
   textSize(30);
   text('Intentionally left blank',175,200);
}

function draw() {
   // draw something
}

class Disk {
	constructor(){
		this.xPos;   // 1. Current location (X and Y)
		this.yPos;
		this.xDir;   // 2. Current motion (X and Y)
		this.yDir;
		this.radius; // 3. Radius
		this.clr;    // 4. Color
	}
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch14-01-objects_disk01.jpg')
}


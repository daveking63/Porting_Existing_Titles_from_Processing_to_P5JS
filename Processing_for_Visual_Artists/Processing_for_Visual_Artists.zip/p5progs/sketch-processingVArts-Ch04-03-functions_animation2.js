// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: animation2.pde in Ch04
// Chapter: Ch04-03 functions No Figure
// Description: Display background with draw()
//
function setup() {
   createCanvas(600, 400);
   let redval = 192;
   let grnval = 64;
   let bluval = 0;
   background(redval, grnval, bluval);
}

function draw() {
   background(redval, grnval, bluval);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch04-03-functions_animation2.jpg')
}


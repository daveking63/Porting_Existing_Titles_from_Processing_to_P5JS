// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: keyboard1.pde in Ch07
// Chapter: Ch07-14 human No Figure
// Description: using KeyPressed
//
function setup() {
	createCanvas(600,400);
	background(200);
}

function draw() {
   textSize(15);
   text('Press "A or a" Key',250,200);
   text('see Console', 250,220);
}

function keyPressed() {
   if ((key == 'a') || (key == 'A')) {
      print("You pressed the A key!");
   }
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch07-14-human_keyboard1.jpg')
}


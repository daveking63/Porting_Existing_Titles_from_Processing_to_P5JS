// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: digitize03.pde in Ch17
// Chapter: Ch17-03 files No Figure
// Description: Display of scanned silhouette of primitive 'oddman' with mouseX and mouseY written to file - file closed with keyIsPressed
//
let Picture;
let OutputFile;

function preload(){
	Picture = loadImage("data/oddman.png");
}

function setup() {
   createCanvas(800, 303);
   image(Picture, 0, 0);
   OutputFile = createWriter("DrawingPoints3.txt");
   textSize(10);
   msg1 = "Click mouse to digitize point &"
   msg2 = "and write to file DrawingPoints3.txt";
   msg3 = "Type letter 'q' to quit and close file";
   text(msg1,600,20);
   text(msg2,600,35);
   text(msg3,600,50);
}

function mouseClicked() {
   OutputFile.print(mouseX + "\t" + mouseY);
}

function keyPressed() {
   if ((key == 'q') || (key == 'Q')) {
      print("File is close");
      OutputFile.close();
      OutputFile.clear();
   }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch17-03-files_digitize03.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: animation3.pde in Ch04
// Chapter: Ch04-04 functions No Figure
// Description: Preset colors Display background
//
let Redval = 192;
let Grnval = 64;
let Bluval = 0;

function setup() {
   createCanvas(600, 400);
   background(Redval, Grnval, Bluval);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch04-04-functions_animation3.jpg')
}


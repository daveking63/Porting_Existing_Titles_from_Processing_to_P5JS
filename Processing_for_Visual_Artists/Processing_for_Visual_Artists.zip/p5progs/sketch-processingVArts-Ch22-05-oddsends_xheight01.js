// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: xheight01.pde in Ch22
// Chapter: Ch22-05 oddsends Figure 22.11
// Description: drawing some text with a specified font
//

function preload(){
	myFont = loadFont("data/PlayfairDisplay-Bold.ttf");
}

function setup() {
   createCanvas(600, 400);    
   textFont(myFont);
   textSize(96);
   
   background(240, 215, 175); 
   let message = "raspberry!";
   
   fill(145, 44, 66);
   text(message,50,200);
   
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch22-05-oddsends_xheight01.jpg')
}


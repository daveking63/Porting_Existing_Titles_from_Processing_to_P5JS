// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: balls02.pde in Ch22
// Chapter: Ch22-02 oddsends Figure 22.2
// Description: initial program for balls whose motion wraps around the window or canvas

let Flies = [];

function  setup() {
   createCanvas(600, 400);

   Flies[0] = new Ball(300, 200,  2,  3, 30, 138,  59,  59, 255);
   Flies[1] = new Ball(400, 100, -2, -1, 50, 151, 166,  95, 255);
   Flies[2] = new Ball(100, 200,  3, -3, 20,  78, 120, 145, 255);
}

function  draw() {
   background(128, 103, 103);
   for (let i=0; i<Flies.length; i++) {
      Flies[i].render();
      Flies[i].move();
   }
}

class Ball {
	constructor(acx, acy, avx, avy, aradius, ar, ag, ab, aa) {
		this.cx = float(acx);  this.cy = float(acy);
		this.vx = float(avx);  this.vy = float(avy);
		this.radius = float(aradius);
		this.cr = float(ar); this.cg = float(ag); this.cb = float(ab); this.ca = float(aa);
	}

	render() {
		fill(this.cr, this.cg, this.cb, this.ca);
		ellipse(this.cx, this.cy, 2*this.radius, 2*this.radius);
	}

	move() {
		let noiseScale = 0.02;
		this.radius += lerp(-1, 1, noise(this.cx*noiseScale));
		this.radius = constrain(this.radius, 10, 100);
		this.vx += lerp(-0.25, 0.25, noise(noiseScale*this.cx, noiseScale*this.cy));
		this.vy += lerp(-0.25, 0.25, noise(noiseScale*this.cy, noiseScale*this.cx));
		this.cx += this.vx;
		this.cy += this.vy;
		if ((this.cx-this.radius < 0) || (this.cx+this.radius >= width)) {
			this.vx = -this.vx;
			this.cx += 2*this.vx;
		}
		if ((this.cy-this.radius < 0) || (this.cy+this.radius >= height)) {
			this.vy = -this.vy;
			this.cy += 2*this.vy;
		}
	}
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch22-02-oddsends_balls02.jpg')
}


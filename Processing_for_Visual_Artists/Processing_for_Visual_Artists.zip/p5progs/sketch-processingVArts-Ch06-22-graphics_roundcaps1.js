// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: roundcaps1.pde in Ch06
// Chapter: Ch06-22 graphics Figure 6.29
// Description: rounded end caps for series of lines
//
function setup() {
   createCanvas(600, 400);
   background(224);
   strokeCap(ROUND);
   stroke(0);
   strokeWeight(30);
   line(100, 100, 300, 200);
   line(300, 200, 500, 100);

   stroke(196, 32, 83);  // red
   line(100, 200, 300, 300);
   stroke(28, 115, 45);  // green
   line(300, 300, 500, 200);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch06-22-graphics_roundcaps1.jpg')
}


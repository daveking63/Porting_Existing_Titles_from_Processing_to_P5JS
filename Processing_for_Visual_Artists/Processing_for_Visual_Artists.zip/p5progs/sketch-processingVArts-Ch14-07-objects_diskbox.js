// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: diskbox.pde in Ch14
// Chapter: Ch14-07 objects Figure 14.5
// Description: Object program with an array of 'ghost boxes' with multiple attributes displayed on screen with render method
//
let Ghosts = [];
let numGhosts = 10;

function setup() {
   createCanvas(600, 400);
   background(132, 144, 163);
   buildGhosts(numGhosts);
}

function draw() {
   for (let i=0; i<Ghosts.length; i++) {
      Ghosts[i].render();
   }
}

function buildGhosts(numGhosts) {
   let border = 50;
   for (let i=0; i<numGhosts; i++) {
      let  xPos = random(border, width-border);
      let  yPos = random(border, height-border);
      let  xDir = 10;
      let  yDir = 10;
      let  radius = random(10, 30);
      let clr = color(random(20, 255), random(20, 255), random(20, 255), 128);
      Ghosts[i] = new Disk(xPos, yPos, xDir, yDir, radius, clr);
   }
}

class Disk {
	constructor (axPos, ayPos, astrokeSize,  aangle, asideLength, aclr) {
		this.xPos = axPos;
		this.yPos = ayPos;
		this.strokeSize = astrokeSize;
		this.angle = aangle;
		this.sideLength = asideLength * 2;
		this.clr = aclr;
		
	}

	render() {
		fill(this.clr);
		strokeWeight(this.strokeSize/2.0);
		push();
			translate(this.xPos, this.yPos);
			rotate(radians(this.angle));
			rect(-this.sideLength/2.0, -this.sideLength/2.0, this.sideLength, this.sideLength);
		pop();
	}
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch14-07-objects_diskbox.jpg')
}


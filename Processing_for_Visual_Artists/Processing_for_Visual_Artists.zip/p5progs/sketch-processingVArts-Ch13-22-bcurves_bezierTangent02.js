// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: bezierTangent02.pde in Ch13
// Chapter: Ch13-22 bcurves Figure 13.23
// Description: Drawing offsets to Bezier curve
//
let  Xp = [80,  160, 580, 380];
let  Yp = [300,   0,   80, 300];

function setup() {
  createCanvas(600, 400);
  background(237, 180, 198);
  noFill();
  bezier(Xp[0], Yp[0], Xp[1], Yp[1], Xp[2], Yp[2], Xp[3], Yp[3]);
  
  let  oldx0 = 0;
  let  oldy0 = 0;
  let  oldx1 = 0;
  let  oldy1 = 0;
  let numSteps = 40;
  strokeWeight(2);
  for (let i=0; i<numSteps; i++) {
    let  t = map(i, 0, numSteps-1, 0, 1);
    let  xPos = bezierPoint(Xp[0], Xp[1], Xp[2], Xp[3], t);
    let  yPos = bezierPoint(Yp[0], Yp[1], Yp[2], Yp[3], t);
    let  xTan = bezierTangent(Xp[0], Xp[1], Xp[2], Xp[3], t);
    let  yTan = bezierTangent(Yp[0], Yp[1], Yp[2], Yp[3], t);
    let  tanlen = mag(xTan, yTan);
    xTan *= 20/tanlen;
    yTan *= 20/tanlen;
    if (i > 0) {
      line(oldx0, oldy0, xPos-yTan, yPos+xTan);
      line(oldx1, oldy1, xPos+yTan, yPos-xTan);
    }
    oldx0 = xPos-yTan;
    oldy0 = yPos+xTan;
    oldx1 = xPos+yTan;
    oldy1 = yPos-xTan;
  }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch13-22-bcurves_bezierTangent02.jpg')
}


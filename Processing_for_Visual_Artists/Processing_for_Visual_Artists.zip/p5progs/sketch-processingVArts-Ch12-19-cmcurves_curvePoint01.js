// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: curvePoint01.pde in Ch12
// Chapter: Ch12-19 cmcurves Figure 12.24
// Description: Drawing a curve using arrays of x's and y's and the curve function
//
let Xp = [40,  50, 540, 300];
let Yp = [940, 160, 200, 900];

function setup() {
  createCanvas(600, 400);
  background(237, 180, 198);
  noFill();
  curve(Xp[0], Yp[0], Xp[1], Yp[1], Xp[2], Yp[2], Xp[3], Yp[3]);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch12-19-cmcurves_curvePoint01.jpg')
}


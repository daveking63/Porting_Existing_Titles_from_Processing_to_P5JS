// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: bounce01.pde in Ch18
// Chapter: Ch18-01 patterns Figure 18.1
// Description: Bouncing ball moving horizontally
//
function setup() {
	createCanvas(600, 400);
	noStroke();
}

function draw() {
	background(145, 236, 152);
	fill(6, 119, 120);
	let  time = frameCount;
	let ballCenter = getBallCenter(time);
	ellipse(ballCenter.x, ballCenter.y, 40, 40);
}

function getBallCenter(time)
{
   let center = createVector(time, 200);
   return(center);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch18-01-patterns_bounce01.jpg')
}


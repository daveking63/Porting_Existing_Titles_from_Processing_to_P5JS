// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: cleanup07.pde in Ch17
// Chapter: Ch17-16 files Figure 17.16
// Description: Final corrected display of scanned silhouette of primitive 'oddman' created from digitized points read from text file with different chunks displayed in different colors along with points to represent each point in file
//

let words = [];
let lines1,lines2,lines3,lines4,lines5,lines6 = [];

function preload(){
  lines1 = loadStrings("data/Body-ManPoints2.txt");
  lines2 = loadStrings("data/BellyHole-ManPoints2.txt");
  lines3 = loadStrings("data/EyeHole-ManPoints2.txt"); 
  lines4 = loadStrings("data/FootHole-ManPoints2.txt");
  lines5 = loadStrings("data/UpCircleHole-ManPoints2.txt"); 
  lines6 = loadStrings("data/UpperHole-ManPoints2.txt");
}

function setup() {
  createCanvas(1600,630);
  background(255);
  stroke(0);
  strokeWeight(2);
  showCurve();
}

function showCurve() {
  let ox, oy, x, y;
  ox = oy = x = y = 0;
  for (let i=0; i<=lines.length; i++) {
    words = split(lines[i%lines.length], '\t');
    print(words);
    x = int(words[0]);
    y = int(words[1]);
    if (i>0) {
      line(ox, oy, x, y);
      let  radius = 3;
      if (i%10 == 0) radius = 6;
      ellipse(x, y, radius, radius);
    }
    if (i%10 == 0) {
      stroke(color(random(50, 200), random(50, 200), random(50, 200)));
    }
    ox = x;
    oy = y;
  }
}

function setup() {
	createCanvas(1600,630);
	background(255);
	stroke(0);
	strokeWeight(2);
	showCurve(lines1);
	showCurve(lines2);
	showCurve(lines3);
	showCurve(lines4);
	showCurve(lines5);
	showCurve(lines6);
}

function showCurve(dlines) {
  let ox, oy, x, y;
  ox = oy = x = y = 0;
  for (let i=0; i<=dlines.length; i++) {
    words = split(dlines[i%dlines.length], '\t');
    x = int(words[0]);
    y = int(words[1]);
    if (i>0) {
      line(ox, oy, x, y);
      let  radius = 3;
      if (i%10 == 0) radius = 6;
      ellipse(x, y, radius, radius);
    }
    if (i%10 == 0) {
      stroke(color(random(50, 200), random(50, 200), random(50, 200)));
    }
    ox = x;
    oy = y;
  }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch17-16-files_cleanup07.jpg')
}


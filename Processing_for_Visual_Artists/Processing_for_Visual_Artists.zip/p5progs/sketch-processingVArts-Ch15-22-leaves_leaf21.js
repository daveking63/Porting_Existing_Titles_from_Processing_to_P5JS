// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: leaf21.pde in Ch15
// Chapter: Ch15-22 leaves Figure 15.23
// Description: stacking leaves
//
// Fall leaves project
// version 0.1, Andrew, 16 April 2009
//

// dimensions of the square drawing area
let Window = 400;

function setup() {
   createCanvas(Window, Window);
   background(200, 190, 143);
   noStroke();
   //frameRate(1);
}

function draw() {
   //background(200, 190, 143);
   drawOneLeaf();
}

function drawOneLeaf() {
   let pA = createVector(-0.5, 0.0);  // left end
   let pB = createVector( 0.5, 0.0);  // right end

   let pG1 = makeControlPoint(-0.25, -0.15,  0.15, -0.05, -0.15, 0.0);
   let pG2 = makeControlPoint( 0.25, -0.15,  0.15, -0.05, -0.15, 0.0);
   let pH1 = makeControlPoint(-0.25, -0.15,  0.15,  0.05,  0.0, 0.15);
   let pH2 = makeControlPoint( 0.25, -0.15,  0.15,  0.05,  0.0, 0.15);
   
   let  yMove = random(0, 0.35);
   pG2.y += yMove;
   pH2.y += yMove;
  
   let sA = pointToWindow(pA);
   let sB = pointToWindow(pB);
   let sG1 = pointToWindow(pG1);
   let sG2 = pointToWindow(pG2);
   let sH1 = pointToWindow(pH1);
   let sH2 = pointToWindow(pH2);

   let myRed = int(random(50, 255));
   let myGrn = int(random(50, 255));
   let myBlu = int(random(50, 255));
   fill(color(myRed, myGrn, myBlu, 128));

   beginShape();
   vertex(sA.x, sA.y);
   bezierVertex(sG1.x, sG1.y, sG2.x, sG2.y, sB.x, sB.y);
   bezierVertex(sH2.x, sH2.y, sH1.x, sH1.y, sA.x, sA.y);
   endShape();
}

function pointToWindow(p) {
   let t = p.copy();
   t.x = map(t.x, -1, 1, 0, Window-1);
   t.y = map(t.y, -1, 1, 0, Window-1);
   return(t);
}

function makeControlPoint(x, dxlo, dxhi, y, dylo, dyhi)  {
   let  px = x + random(dxlo, dxhi);
   let  py = y + random(dylo, dyhi);
   let t = createVector(px, py);
   return(t);
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch15-22-leaves_leaf21.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: spinners2.pde in Ch10
// Chapter: Ch10-02 recursion Figure 10.4
// Description: recursively drawn concentric circles all the same color
//
let  MaxDepth = 4;

function setup() {
   createCanvas(500, 500);
   noStroke();
}

function draw() {
   background(119, 112, 127);
   translate(250, 250);
   scale(240.0);
   drawCircles(1);
}

function drawCircles(depth) {
   if (depth > MaxDepth) return;
   fill(89, 9, 21);
   ellipse(0, 0, 2, 2);
   scale(0.75);
   drawCircles(depth+1);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch10-02-recursion_spinners2.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: findPoint05.pde in Ch12
// Chapter: Ch12-28 cmcurves Figure 12.34
// Description: Finding the intersection points of a curve on a vertical y axis
//
let Xp = [40,  50, 540, 300];
let Yp = [940, 160, 200, 900];
let TimeAxisY = 300;


function setup() {
   createCanvas(600, 400);
   background(210, 215, 140);
   noFill();
   curve(Xp[0], Yp[0], Xp[1], Yp[1], Xp[2], Yp[2], Xp[3], Yp[3]);

   line(50, TimeAxisY, 540, TimeAxisY);    // the time axis
   let  targetX = 180;
   let  threshold = 0.0001;
   let  answerT = findTfromX(threshold, targetX);
   
   line(targetX, 0, targetX, TimeAxisY);
   let  px = curvePoint(Xp[0], Xp[1], Xp[2], Xp[3], answerT);
   let  py = curvePoint(Yp[0], Yp[1], Yp[2], Yp[3], answerT);
   ellipse(px, py, 20, 20);
}

function findTfromX(threshold, targetX) {
  let  tlo = 0;
  let  thi = 1;
  let  xLeft = curvePoint(Xp[0], Xp[1], Xp[2], Xp[3], tlo);
  let  xRight = curvePoint(Xp[0], Xp[1], Xp[2], Xp[3], thi);
  let numSteps = 500;
  while (numSteps-- > 0) {
     let  tmid = (tlo + thi)/2.0;
     if ((thi - tlo) < threshold) {
        return(tmid);
     }
     let  xval = curvePoint(Xp[0], Xp[1], Xp[2], Xp[3], tmid);
     if (targetX < xval) thi = tmid;
                    else tlo = tmid;
   }
   return((tlo+thi)/2.0);  // we couldn't find the point
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch12-28-cmcurves_findPoint05.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: scale1.pde in Ch09
// Chapter: Ch09-11 transforms Figure 9.12
// Description: translating and rotating and scaling by 2 the axes and origin of coordinate system before drawing circles and boxes
//
function setup() {
   createCanvas(600, 400);
}

function draw() {
   background(210, 177, 68);
   stroke(0);
   noFill();
   
   // move the origin to the center of the screen
   translate(300, 200);
   scale(2.0);
   
   strokeWeight(2);
   drawCircleTo( 125,  75);
   drawCircleTo( 125, -75);
   drawCircleTo(-125,  75);
   drawCircleTo(-125, -75);
   strokeWeight(1);
   
   fill(149, 93, 13, 128);
   rect(-125, -75, 250, 150);    
   fill(139, 49, 30, 128);
   
   rotate(radians(20));
   
   rect(-125, -75, 250, 150);
}

function drawCircleTo(x, y) {
   let r = dist(0, 0, x, y);
   ellipse(0, 0, 2*r, 2*r);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch09-11-transforms_scale1.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: rectfill1.pde in Ch06
// Chapter: Ch06-17 graphics Figure 6.24
// Description: changing rectangle fill color for 4 rectangles
//
function setup() { 
   createCanvas(600, 400);
   background(106, 158, 155);
   strokeWeight(10);
}  

function draw() {
   fill(198, 209, 173);
   rect(40, 140, 80, 50);
   rect(150, 140, 80, 50);
   rect(260, 140, 80, 50);
   rect(370, 140, 80, 50);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch06-17-graphics_rectfill1.jpg')
}


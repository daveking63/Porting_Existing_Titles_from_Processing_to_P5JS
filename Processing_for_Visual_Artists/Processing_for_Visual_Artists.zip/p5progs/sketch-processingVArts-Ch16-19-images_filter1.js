// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: filter1.pde in Ch16
// Chapter: Ch16-19 images Figure 16.24
// Description: applying individual filters to an image
//
let Hike;
let Results = [];

function preload(){
	Hike = loadImage("data/myPhoto.jpg");
}

function setup() {
	createCanvas(1350, 1050); 
	for (let i=0; i<16; i++) {Results[i] = createImage(300, 225);}
	for (let i=0; i<16; i++) {runFilter(i);}

	background(128);

	for (let y=0; y<4; y++) {
		for (let x=0; x<4; x++) {
			copy(Results[(y*4)+x], 0, 0, 300, 225, x*350, y*275, 300, 225);
		}
	}
}

function runFilter(i) {
	image(Hike, 0, 0, 300, 225);
	switch (i) {
		case  0: filter(THRESHOLD, 0.25); break;
		case  1: filter(THRESHOLD, 0.75); break;
		case  2: filter(GRAY); break;
		case  3: filter(INVERT); break;

		case  4: filter(POSTERIZE, 2); break;
		case  5: filter(POSTERIZE, 3); break;
		case  6: filter(POSTERIZE, 4); break;
		case  7: filter(POSTERIZE, 8); break;

		case  8: filter(BLUR, 1); break;
		case  9: filter(BLUR, 4); break;
		case 10: filter(BLUR, 15); break;
		case 11: filter(OPAQUE); break;

		case 12: filter(ERODE); break;
		case 13: filter(ERODE); filter(ERODE); filter(ERODE); break;
		case 14: filter(DILATE); break;
		case 15: filter(DILATE); filter(DILATE);  filter(DILATE);  break;
	default: break;
	}
	Results[i] = get(0, 0, 300, 225);
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch16-19-images_filter1.jpg')
}


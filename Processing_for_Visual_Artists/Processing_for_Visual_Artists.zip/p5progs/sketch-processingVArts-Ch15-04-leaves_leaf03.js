// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: leaf03.pde in Ch15
// Chapter: Ch15-04 leaves Figure 15.5
// Description: first try drawing a leaf
//
// Fall leaves project
// version 0.1, Andrew, 16 April 2009
//

// dimensions of the square drawing area
let Window = 400;

function setup() {
   createCanvas(Window, Window);
   background(200, 190, 143);
   noFill();
}

function draw() {
   drawOneLeaf();
}

function drawOneLeaf() {
   let pA = createVector(-0.5, 0.0);  // left end
   let pB = createVector(-0.5, 0.0);  // right end
  
   let pG1 = createVector(-.25, -.25);
   let pG2 = createVector( .25, - 25);
   let pH1 = createVector(-.25, - 25);
   let pH2 = createVector( .25, - 25);
  
   let sA = pointToWindow(pA);
   let sB = pointToWindow(pB);
   let sG1 = pointToWindow(pG1);
   let sG2 = pointToWindow(pG2);
   let sH1 = pointToWindow(pH1);
   let sH2 = pointToWindow(pH2);
  
   stroke(196, 66, 63);  // red
   bezier(sA.x, sA.y, sG1.x, sG1.y, sG2.x, sG2.y, sB.x, sB.y);
   stroke(64, 135, 36);  // green
   bezier(sA.x, sA.y, sH1.x, sH1.y, sH2.x, sH2.y, sB.x, sB.y);
}

function pointToWindow(p) {
   let t = p.copy();
   t.x = map(t.x, -1, 1, 0, Window-1);
   t.y = map(t.y, -1, 1, 0, Window-1);
   return(t);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch15-04-leaves_leaf03.jpg')
}


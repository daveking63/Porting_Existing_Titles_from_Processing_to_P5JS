// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: animation4.pde in Ch04
// Chapter: Ch04-05 functions Figure 4.3
// Description: Draw changing background
let Redval = 12;
let Grnval = 64;
let Bluval = 0;

function setup() {
   createCanvas(600, 400);
   background(Redval, Grnval, Bluval);
}

function draw() {
   Redval = Redval + 1;
   background(Redval, Grnval, Bluval);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch04-05-functions_animation4.jpg')
}


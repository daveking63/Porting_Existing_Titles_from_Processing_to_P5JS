// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: box1.pde in Ch09
// Chapter: Ch09-01 transforms Figure 9.1
// Description: drawing simple reddish rectangle (box) on yellow background
//
function setup() {
   createCanvas(600, 400);
}

function draw() {
   background(210, 177, 68);
   fill(139, 49, 30);
   rect(150, 100, 250, 150);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch09-01-transforms_box1.jpg')
}


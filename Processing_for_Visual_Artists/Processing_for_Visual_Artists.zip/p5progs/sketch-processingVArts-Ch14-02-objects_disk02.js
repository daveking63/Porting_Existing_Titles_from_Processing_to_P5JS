// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: disk02.pde in Ch14
// Chapter: Ch14-02 objects No Figure
// Description: Initialization of object program with single 'ghost disk' with one attribute
//
let Ghost;

function setup() {
   createCanvas(600, 400);
   background(164, 164, 164);
   Ghost = new Disk(5);
   print("Ghost radius = " + Ghost.radius);
   msg = "Ghost radius = " + str(Ghost.radius)
   textSize(30);
   text(msg,175,200);
}

function draw() {
   // draw something
}

class Disk {
	constructor(aRadius){
		this.xPos;   // 1. Current location (X and Y)
		this.yPos;
		this.xDir;   // 2. Current motion (X and Y)
		this.yDir;
		this.radius = aRadius; // 3. Radius
		this.clr;    // 4. Color
	}// constructor
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch14-02-objects_disk02.jpg')
}


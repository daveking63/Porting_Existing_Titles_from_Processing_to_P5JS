// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: findPoint01.pde in Ch12
// Chapter: Ch12-24 cmcurves Figure 12.30
// Description: Finding particular percentage points along a curve
//
let Xp = [50,  50, 540, 200];
let Yp = [-650, 150, 110, -290];

function setup() {
   createCanvas(600, 400);
   background(210, 215, 140);
   noFill();
   curve(Xp[0], Yp[0], Xp[1], Yp[1], Xp[2], Yp[2], Xp[3], Yp[3]);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch12-24-cmcurves_findPoint01.jpg')
}


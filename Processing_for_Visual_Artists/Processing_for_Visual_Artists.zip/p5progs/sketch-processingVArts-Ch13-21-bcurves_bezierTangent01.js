// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: bezierTangent01.pde in Ch13
// Chapter: Ch13-21 bcurves Figure 13.22
// Description: Normals and tangents to Bezier curve
//
let  Xp = [80,  160, 580, 380];
let  Yp = [300,   0,   80, 300];

function setup() {
  createCanvas(600, 400);
  background(237, 180, 198);
  noFill();
  bezier(Xp[0], Yp[0], Xp[1], Yp[1], Xp[2], Yp[2], Xp[3], Yp[3]);
  
  let numSteps = 8;
  for (let i=0; i<numSteps; i++) {
    let  t = map(i, 0, numSteps-1, 0, 1);
    let  xPos = bezierPoint(Xp[0], Xp[1], Xp[2], Xp[3], t);
    let  yPos = bezierPoint(Yp[0], Yp[1], Yp[2], Yp[3], t);
    fill(255);
    strokeWeight(1);
    stroke(0, 0, 0);
    ellipse(xPos, yPos, 20, 20);
    
    let  xTan = bezierTangent(Xp[0], Xp[1], Xp[2], Xp[3], t)/20;
    let  yTan = bezierTangent(Yp[0], Yp[1], Yp[2], Yp[3], t)/20;
    strokeWeight(2);
    stroke(78, 98, 229);
    line(xPos-xTan, yPos-yTan, xPos+xTan, yPos+yTan);
    
    stroke(0);
    line(xPos-yTan, yPos+xTan, xPos+yTan, yPos-xTan);
  }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch13-21-bcurves_bezierTangent01.jpg')
}


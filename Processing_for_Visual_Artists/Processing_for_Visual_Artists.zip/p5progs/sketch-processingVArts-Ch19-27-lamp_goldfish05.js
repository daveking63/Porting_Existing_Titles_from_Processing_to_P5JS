// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: goldfish05.pde in Ch19
// Chapter: Ch19-27 lamp Figure 19.42
// Description: two goldfish-two spotfish-one sharkfish
//
let Fish;
let Spot;
let Shark;

function setup() {
	createCanvas(600, 400);
	background(83, 181, 169);

	// create fish
	Fish = new Goldfish(color(255, 184, 51));
	Spot = new Spotfish(color(219, 101, 73), color(173, 171, 26));
	Shark = new Sharkfish(color(158, 61, 88)); 

	// show each fish, with and without a periscope
	Fish.render(100, 100, .5);
	Fish.render(100, 300, .5); 
	Fish.drawPeriscope(100, 300, .5);

	Spot.render(275, 100, .5);
	Spot.render(275, 300, .5); 
	Spot.drawPeriscope(275, 300, .5);

	Shark.render(450, 100, .5);
}


class Goldfish { 
	// Goldfish constructor
	constructor(afishColor) {    
		this.fishColor = afishColor;
		// Goldfish outline
		this.fx = [150, 130,  110, 90,  70,  50,   0, -40, -50, -80, -100, -80];
		this.fy = [0, -20,  -30, -40, -50, -50, -30, -10, -10, -40, -30, 0];
		//periscope outline
		this.px = [90,  90,   95,  100,   130,  130,  150, 150, 130,  130,  120, 115, 110, 110];
		this.py = [-40, -110, -117, -120, -120, -125, -125, -95, -95, -100, -100, -97, -90, -30];
	}

	// draw a Goldfish using this fish's color
	render(cx, cy, scl) {
    	this.drawOutline(cx, cy, scl, this.fx, this.fy);
	}
  
	drawOutline(cx, cy, scl, x, y) {
		fill(this.fishColor);
		beginShape();
			for (let i=0; i<x.length; i++) vertex(cx+(scl*x[i]), cy+(scl*y[i]));
			for (let i=x.length-1; i>=0; i--) vertex(cx+(scl*x[i]), cy+(scl*-y[i]));
		endShape();
	}
  
	// draw a periscope using this fish's color
	drawPeriscope(cx, cy, scl) {
		fill(this.fishColor);
		beginShape();
			for (let i=0; i<this.px.length; i++) vertex(cx+(scl*this.px[i]), cy+(scl*this.py[i]));
		endShape();
	}
}

class Spotfish extends Goldfish { 
	constructor(afishColor, aspotColor) {
		super(afishColor);     
		this.spotColor = aspotColor;
	}
  
	render(cx, cy, scl) {
	    super.render(cx, cy, scl); 
	    // and now draw our own spot
	    fill(this.spotColor);          
	    ellipse(cx+(scl*75), cy+(scl* 10), 20, 20);
  }
}

class Sharkfish extends Goldfish {
	constructor(afishColor) {
		super(afishColor);
		// Sharkfish outline
		this.sfx = [150, 130,  110,  90,  70,  50,  40, 20,  -10,   5,  10,   0, -40, -50, -80, -100, -80];
		this.sfy = [0, -20,  -30, -40, -50, -50, -70, -80, -85, -70, -50, -30, -10, -10, -40, -30, 0];
	  	}    
  
	render(cx, cy, scl) {
		this.drawOutline(cx, cy, scl, this.sfx, this.sfy);
	}
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch19-27-lamp_goldfish05.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: break1.pde in Ch08
// Chapter: Ch08-05 loops Figure 8.7
// Description: drawing a row of yellow ellipses on blue rectangle using 'for' loop with a 'break'
//
function setup() {
   createCanvas(600, 250);
}

function draw() {
   background(200);
   fill(47, 64, 84);
   rect(25, 50, 550, 140);
   
   fill(249, 246, 155);
   for (let xval=80; xval<550; xval+=110) {
      if (xval == 300) break;
      ellipse(xval, 120, 80, 80);
   }
   // after loop
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch08-05-loops_break1.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: moire1.pde in Ch07
// Chapter: Ch07-01 human Figure 7.1
// Description: animate moivre effect
//
function setup() {
  createCanvas(600, 400);
  smooth();
  noStroke();
}

function draw() {
  background(255);
  push();
  translate(width/2, height/2);  // mouse input will go here
  fill(0, 0, 0);
  drawStar();
  push();
  
  push();
  translate(width/2, height/2);
  rotate(TWO_PI * frameCount/800);
  translate(0, 70);
  fill(0, 0, 0);
  drawStar();
  push();
}

function drawStar() {
  let  numSpokes = 100;
  for (let i=0; i<numSpokes; i++) {
     let t0 = map(i, 0, numSpokes-1, 0, TWO_PI);
     let t1 = t0 + (TWO_PI/(2*numSpokes));
     arc(0, 0, 1000, 1000, t0, t1);
  }
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch07-01-human_moire1.jpg')
}


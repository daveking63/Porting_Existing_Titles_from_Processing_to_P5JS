// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: spintext01.pde in Ch20
// Chapter: Ch20-13 type Figure 20.16
// Description: display of short message
//

let myFont;
function preload(){
	myFont = loadFont("data/AvenirNextLTPro-Demi.otf"); 
}

function setup() 
{
	createCanvas(600, 400);
	textFont(myFont);
	textSize(36);
}

function draw() {
	fill(199, 172, 115);
	background(89, 9, 21);
	let message = "Pomegranate and lime juice ";
	text(message, 10, 200);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch20-13-type_spintext01.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: animation5.pde in Ch04
// Chapter: Ch04-06 functions Figure 4.4
// Description: Background presented changed and controlled by draw()
//
let Redval = 192;
let Grnval = 64;
let Bluval = 0;

function setup() {
   createCanvas(600, 400);
   background(Redval, Grnval, Bluval);
}

function draw() {
   Redval = Redval+1;
   if (Redval > 255) Redval=0;
   background(Redval, Grnval, Bluval);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch04-06-functions_animation5.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011

// PDE Source: helloworld.pde in Ch02
// Chapter: Ch02-01 settingup Figure 2.2
// Description: Printing 'Hello World'

function setup(){
	createCanvas(200,200);
	background(200);
	textSize(20)
	text('Hello World',40,40);
	
	//originally only print to console
	print('Hello World');
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch02-01-settingup_HelloWorld.jpg')
}


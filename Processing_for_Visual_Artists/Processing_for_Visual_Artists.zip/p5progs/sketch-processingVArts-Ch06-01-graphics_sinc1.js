// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: sinc1.pde in Ch06
// Chapter: Ch06-01 graphics Figure 6.1
// Description: 3D pulsing (wave) sinc made of a single quadstrip spiral
//
//import processing.opengl.*;

function setup() {
  createCanvas(600, 400, WEBGL);
}

// a pulsing sinc made of a single quadstrip spiral

function draw() {
  background(108, 131, 166);
  //lights();
  //translate(width/2, 3*height/8);
  rotateX(radians(55));
  scale(height/2, height/2);
  
  fill(225, 215, 170);
  
  let  ringWidth = 0.04;
  let ringSteps = 8;
  let maxi = 240;
  
  
  beginShape(); //beginShape(QUAD_STRIP) - not implemented -- produces unusual results
  for (let i=-ringSteps; i<maxi; i++) {
    let  r0 = ringWidth * float(i*1.0/ringSteps);
    let  r1 = r0 + ringWidth;
    if (r0 < 0) r0 = 0;
    let  theta = (float(i) * float((TWO_PI / ringSteps)));
    makeVertex(r0, theta);
    makeVertex(r1, theta);
  }
  endShape(CLOSE);
}  

function makeVertex(r, theta) {
   let  x = r*cos(theta);
   let  y = r*sin(theta);
   let  z = 100 * exp(-3*r*r) * cos((r * 2 * TWO_PI) - (frameCount/50.0));
   vertex(x, y, z);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch06-01-graphics_sinc1.jpg')
}


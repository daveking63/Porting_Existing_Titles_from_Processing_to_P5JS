// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: bigcurve6.pde in Ch12
// Chapter: Ch12-14 cmcurves Figure 12.18
// Description: Smooth curve that doesn't close
//
let NumPoints = 8;
let Xp = [];
let Yp = [];

function setup() {
   createCanvas(600, 400);
   background(194, 216, 242);
   noFill();
   
   for (let i=0; i<NumPoints; i++) {
      Xp[i] = random(100, 500);
      Yp[i] = random(100, 300);
   }
}

function draw() {
   for (let i=0; i<NumPoints; i++) {
      ellipse(Xp[i], Yp[i], 10, 10);
   }
   beginShape();
   for (let i=0; i<NumPoints; i++) {
      curveVertex(Xp[i], Yp[i]);
   }
   endShape();
}




//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch12-14-cmcurves_bigcurve6.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: bbigcurve7.pde in Ch13
// Chapter: Ch13-18 bcurves Figure 13.19
// Description: Smooth and closed big Bezier curve
//
let NumPoints = 24;
let Xp = [];
let Yp = [];

function setup() {
   createCanvas(600, 400);
   background(206, 214, 242);
   noFill();
   for (let i=0; i<NumPoints; i++) {
      Xp[i] = random(100, 500);
      Yp[i] = random(100, 300);
   }
}

function draw() {
   // move first point
   for (let i=4; i<NumPoints; i+=4) {
      Xp[i] = Xp[i-1];
      Yp[i] = Yp[i-1];
   }
   Xp[0] = Xp[NumPoints-1];
   Yp[0] = Yp[NumPoints-1];
   
   // move second point
   for (let i=5; i<NumPoints; i+=4) {
      Xp[i] = Xp[i-1] + (Xp[i-2] - Xp[i-3]);
      Yp[i] = Yp[i-1] + (Yp[i-2] - Yp[i-3]);
   }
   Xp[1] = Xp[0] + (Xp[NumPoints-1] - Xp[NumPoints-2]);
   Yp[1] = Yp[0] + (Yp[NumPoints-1] - Yp[NumPoints-2]);
   
   for (let i=0; i<NumPoints; i+=4) {
      ellipse(Xp[i], Yp[i], 10, 10);
   }
   for (let i=0; i<NumPoints; i+=4) {
      bezier(Xp[i],   Yp[i],   Xp[i+1], Yp[i+1],
      Xp[i+2], Yp[i+2], Xp[i+3], Yp[i+3]);
   }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch13-15-bcurves_bigcurve7.jpg')
}


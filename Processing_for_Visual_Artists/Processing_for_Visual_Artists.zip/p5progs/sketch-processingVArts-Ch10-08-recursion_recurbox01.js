// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: recurbox01.pde in Ch10
// Chapter: Ch10-08 recursion Figure 10.10
// Description: setup for recursively drawn rectangles
//
function setup() {
   createCanvas(600, 400);
   noStroke();
   handleBox(0, 0, 600, 400, 128);
}

function handleBox(ulx, uly, wid, hgt, gray) {
   fill(gray);
   rect(ulx, uly, wid, hgt);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch10-08-recursion_recurbox01.jpg')
}


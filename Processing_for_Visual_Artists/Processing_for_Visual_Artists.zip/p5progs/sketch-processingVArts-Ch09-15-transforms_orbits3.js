// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: orbits3.pde in Ch09
// Chapter: Ch09-15 transforms Figure 9.17
// Description: animated solar system with moon (rect) orbiting earth (rect) in turn orbiting sun (ellipse) at center
//
let SunDiam = 80;

let EarthDiam = 30;
let EarthOrbitRadius = 130;
let EarthAngle = 0;

let MoonDiam = 10;
let MoonOrbitRadius = 50;
let MoonAngle = 0;

function setup() {
   createCanvas(600, 400);
}

function draw() {
   background(0, 0, 0);    // inky blackness of space
   translate(300, 200);    // move origin to center of screen

   noStroke();
   fill(255, 200, 64);        // yellow-orange
   ellipse(0, 0, SunDiam, SunDiam);  // the mighty Sun

   // rotate around the sun
   rotate(EarthAngle);

   // move out to Earth orbit
   translate(EarthOrbitRadius, 0);

   fill(64, 64, 255);                    // blue-ish
   rect(-EarthDiam/2, -EarthDiam/2, EarthDiam, EarthDiam); // the noble Earth

   // rotate around the Earth
   rotate(MoonAngle);

   // move out to Moon orbit
   translate(MoonOrbitRadius, 0);

   fill(192, 192, 180);                    // gray-ish
   rect(-MoonDiam/2, -MoonDiam/2, MoonDiam, MoonDiam); // the friendly Moon

   EarthAngle += 0.01;
   MoonAngle += 0.01;
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch09-15-transforms_orbits3.jpg')
}


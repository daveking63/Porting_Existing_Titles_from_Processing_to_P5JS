// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: spin2.pde in Ch16
// Chapter: Ch16-04 images Figure 16.5
// Description: stair step display of image rotated and spinning up
//

function preload(){
	pic = loadImage("data/myPhoto.jpg");
}

function setup() {
   createCanvas(600, 400);
   background(110, 120, 126);
   for (let i=0; i<5; i++) {
      //push();
         rotate(radians(i * -20));
         image(pic, 0, 0, 200, 160);
      //push();
      translate(100, 80);
   }
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch16-04-images_spin2.jpg')
}


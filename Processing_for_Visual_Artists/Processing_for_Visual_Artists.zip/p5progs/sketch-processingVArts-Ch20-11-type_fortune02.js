// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: fortune02.pde in Ch20
// Chapter: Ch20-11 type Figure 20.12
// Description: program to generate fortune cookie text
//
// Fortune cookie program
// version 1.0 - AG 24 April 2009
// 1. <Number> <Animal>s are out to get <Person>.
// 2. <When>'s lucky sandwich is <Food> on <Bread>.


let myFont;
function preload(){
	myFont = loadFont("data/AvenirNextLTPro-Demi.otf"); 
}

let F1_1 = "1. ";
let F1_2 = " ";
let F1_3 = "s are out to get ";
let F1_4 = ".";
let F2_1 = "2. ";
let F2_2 = "'s lucky sandwich is ";
let F2_3 = " on ";
let F2_4 = ".";

let Num, Animal, Person, When, Food, Bread;

function setup() {
	createCanvas(600, 400);
	smooth();
	Numb = split("Three,Seventeen,Some,A few,Lots of,Most,No", ',');
	Animal = split("lion,giraffe,elephantalope,worm", ',');
	Person = split("you,your neighbor,Uncle Bob,Crazy Harry", ',');
	When = split("Today,This week,Yesterday,March,2003", ',');
	Food = split("macaroni,roasted apple,peanut brittle,frog", ',');
	Bread = split("rye,wheat,multi-grain,pita,a hot-dog bun", ',');

	textFont(myFont);
	textAlign(LEFT);
	textSize(36);
	frameRate(1/3.0);
}

function draw() {
	background(240);
	textSize(36);
	fill(84, 65, 19);  // brown
	let message1 = F1_1 + Numb[int(random(0, Number.length))] +
	               F1_2 + Animal[int(random(0, Animal.length))] +
	               F1_3 + Person[int(random(0, Person.length))] + F1_4;
	text(message1, 50, 50, 500, 175);

	fill(39, 68, 92);  // dark blue
	let message2 = F2_1 + When[int(random(0, When.length))] +
	               F2_2 + Food[int(random(0, Food.length))] +
	               F2_3 + Bread[int(random(0, Bread.length))] + F2_4;
	text(message2, 50, 200, 500, 175);

}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch20-11-type_fortune02.jpg')
}


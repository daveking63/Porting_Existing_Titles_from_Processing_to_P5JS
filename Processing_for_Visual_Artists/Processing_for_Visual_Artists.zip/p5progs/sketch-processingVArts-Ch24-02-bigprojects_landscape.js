// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: landscape.pde in Ch24
// Chapter: Ch24-02 bigprojects Figure 24.25
// Description: sky-trees-snowbanks on a foggy winter night
//

function setup() {
	createCanvas(600, 400);
	smooth();
	pixelDensity(1);
	drawPostcard();
}

function drawPostcard() {
	// the sun and sky
	let sunColor = color(255, 255, 255);     // sun color
	let hazeColor = color(180, 180, 192);    // sun halo and sky
	let skyColor = color(30, 40, 70);        // dark part of the sky
	let sunX = float(random(width*0.1, width*0.9));   // sun x location
	let sunY = float(random(height*0.1, height*0.9)); // sun y location
	let sunR = float(wiggle(25, 3));                // sun radius
	let hazeR = float(wiggle(30, 5));               // sun halo size
	let cloudIntensity = float(wiggle(40, 5));      // brightness of clouds

	// snowbank colors
	let snowTopColor = color(145, 150, 160, 255); // top of snowbank
	let snowBodyColor = color(50, 60, 70, 255);   // body of snowbank
	let shadowNoiseStrength = float(wiggle(20, 2));      // strength of snow shadows

	// Number of snowbanks, and number of trees per bank
	let treesPerLayer = 4;
	let numLayers=3;

	// create the sun and sky, then draw them
	let sky = new Sky(sunColor, sunX, sunY, sunR, 
			hazeColor, hazeR, skyColor, cloudIntensity);
	sky.render();

	// draw each layer: build the trees and render them, then the snowbank
	for (let layerNum=0; layerNum<numLayers; layerNum++) {
		let a = float(norm(layerNum, 0, numLayers-1));
		let layerHeight = float(lerp(300, 390, a)); // vertical location
		let hillWiggle  = float(lerp( 10,  20, a)); // wiggle vertical extent
		let glowHeight  = float(lerp( 15,  25, a)); // height of glow transition zone
		let layerDepth  = float(lerp( 70,   0, a)); // distance of layer from us

		// create the parameters for a tree and draw it
		for (let i=0; i<treesPerLayer; i++) {
		let treex = float(random(width*0.1, width*0.9));   // x base of tree
		let treey = float(layerHeight + (2*hillWiggle)); // y base of tree
		let treeh = float(lerp(40, 180, a));             // height by layer
		treeh +=  float(wiggle(0, treeh/4.0));             // wiggle it a bit
		let treed = float(layerDepth);                   // depth
		let puffRadius = float(lerp(5, 40, a));          // puff size
		puffRadius = float(random(puffRadius, puffRadius+30));  // let puff grow a lot!
		let trunkWidth = float(lerp(1, 4, a));           // trunk thickness
		let puffDensity = 3.0;                    // higher numbers = more dots

		// pick basic puff color in red-to-yellow range
		let puffHue = float(random(0, 130.0));    
		let puffSat = 25.0;                 
		let puffBrt = 50.0;                 

		// pick related but brighter highlight color
		let highHue = float(puffHue + wiggle(0, 50));
		while (highHue >= 360) highHue -= 360;  // make sure 0<= hue <=360
		while (highHue < 0) highHue += 360;   
		let highSat = 36.0;                         
		let highBrt = 74.0;                         

		// make trunk color in blue-ish range
		let trunkHue = float(wiggle(225, 20));  
		let trunkSat = 50.0;               
		let trunkBrt = 46.0;               

		colorMode(HSB); ////// ****** SWITCHING TO COLOR HSB MODE ******
		let puffColor      = color( puffHue*0.71,  puffSat*2.55,  puffBrt*2.55); 
		let highlightColor = color( highHue*0.71,  highSat*2.55,  highBrt*2.55); 
		let trunkColor     = color(trunkHue*0.71, trunkSat*2.55, trunkBrt*2.55); 
		colorMode(RGB); ////// ****** RETURNING TO COLOR RGB MODE ******

		let tree = new Tree(sunX, sunY, hazeColor, treex, treey, treed, treeh, 
			trunkWidth, trunkColor, puffRadius, puffDensity, puffColor, highlightColor);
		tree.render();
	}

		 //draw the snowbank
		let snow = new Snow(snowTopColor, snowBodyColor, shadowNoiseStrength, glowHeight,
		hazeColor, layerHeight, hillWiggle, layerDepth);
		snow.render();
	}   
}

// random number from (center-distance) to (center+distance)
//
function wiggle(center, distance) {
   let offset = float(random(-distance, distance));
   return(center+offset);
}
    
// Fake distance perspective.  The object color is lerped into the
// background color by an amount given by depth.  When depth=0,
// the object is touching our nose and the color is unaffected.
// When depth=100, the object blends completely into the background.
// In between the blend is exponential, meant to sorta fake reality.
//
function distanceContrast(objectColor, bgColor, depth) {
	let expAt1 = 2.71828;   // Euler's constant, exp(1)
	let a = float(map(exp(depth/100.0), 1, expAt1, 0, 1));
	a = constrain(a, 0, 1);
	let newclr = lerpColor(objectColor, bgColor, a);
	return(newclr);
	}
	
class Sky {
	constructor(asunColor, asunX, asunY, asunR, ahazeColor, ahazeR, askyColor, acloudIntensity) { 
		this.sunColor = asunColor;
		this.sunX =  float(asunX);
		this.sunY =  float(asunY);
		this.sunR =  float(asunR);
		this.hazeColor =  ahazeColor; 
		this.hazeR = float(ahazeR);
		this.skyColor = askyColor;
		this.cloudIntensity = float(acloudIntensity);  
	}

	render() {
		loadPixels();
		// cdist is the distance from sun's center to the farthest screen corner
		let cdist = float(dist(this.sunX, this.sunY, 0, 0));  
		cdist = max(cdist, dist(this.sunX, this.sunY, width, 0));
		cdist = max(cdist, dist(this.sunX, this.sunY, 0, height));
		cdist = max(cdist, dist(this.sunX, this.sunY, width, height));
		print(cdist);

		for (let y=0; y<height; y++) {
			for (let x=0; x<width; x++) {
				let r = float(dist(x, y, this.sunX, this.sunY));
				if (r < this.sunR) {                                  
					set(x, y, this.sunColor);  // when in the sun, we're sun color
				} else if (r < this.sunR+this.hazeR) { 
					let a = float(map(r, this.sunR, this.sunR+this.hazeR, 0, 180));   // distance into degrees 
					let v = float(map(cos(radians(a)), -1, 1, 1, 0));  // cosine over transition
					let hc = lerpColor(this.sunColor, this.hazeColor, v); // blend colors
					set(x, y, hc);                                
				} else {                                        
					let dist = float(map(r, this.sunR+this.hazeR, cdist, 0, 1)); // distance into (0,1)
					let cloudClr = float(noise(0.01*x, 0.03*y));       // cloud strength
					cloudClr -= 0.5;                              // center cloud color at 0
					let cloudStrength = float(sqrt(dist));             // cloud strength
					cloudClr = lerp(0, cloudClr, cloudStrength);  // scale cloud
					let cgray = float(cloudClr * this.cloudIntensity);      // cloud grayness 
					let sc = lerpColor(this.hazeColor, this.skyColor, dist); // blend haze to sky
					sc = color(red(sc)+cgray, green(sc)+cgray, blue(sc)+cgray);
					set(x, y, sc);                                
				}
			}
		}
		updatePixels();
	}//render
}

class Snow {
	constructor(atopColor, abaseColor, ashadowNoiseStrength, aglowHeight, ahazeColor, ayValue, ahillSize, adepth) {
		this.topColor = atopColor; 
		this.baseColor = abaseColor; 
		this.shadowNoiseStrength = float(ashadowNoiseStrength); 
		this.glowHeight = float(aglowHeight);
		this.hazeColor = ahazeColor; 
		this.yValue = float(ayValue); 
		this.hillSize = float(ahillSize); 
		this.depth = float(adepth);
		this.pts = []; // = new PVector[7];
	}

	render() {
	// create two Bezier curves across the screen to create a rolling snowbank
		for (let i=0; i<7; i++) {
			this.pts[i] = createVector(0, 0);
			this.pts[i].x = map(i, 0, 6, 0, width);
			this.pts[i].y = this.yValue + wiggle(0, this.hillSize);
			if ((i>0) && (i<6)) this.pts[i].x += wiggle(0, width/15.0);
		}
		this.pts[4].x = this.pts[3].x + (this.pts[3].x - this.pts[2].x); // make the curves join smooothly  
		this.pts[4].y = this.pts[3].y + (this.pts[3].y - this.pts[2].y); // by setting pts(4-3) = pts(3-2)
 
		// create a big filled region the top color of this snowbank
		noStroke();
		let topColorInDistance = distanceContrast(this.topColor, this.hazeColor, this.depth);
		fill(topColorInDistance);
		beginShape();
			vertex(0, height);
			vertex(this.pts[0].x, this.pts[0].y);
			bezierVertex(this.pts[1].x, this.pts[1].y, this.pts[2].x, this.pts[2].y, this.pts[3].x, this.pts[3].y);
			bezierVertex(this.pts[4].x, this.pts[4].y, this.pts[5].x, this.pts[5].y, this.pts[6].x, this.pts[6].y);
			vertex(width, height);
		endShape(CLOSE);
       
		// For each column of pixels, leave a few topColor pixels at the top,
		// then blend downward over the distance glowHeight to a combination 
		// of baseColor and shadow noise.

		for (let x=0; x<width; x++) {
		let gh = float(this.getHillHeightAtX(x)+3);  // get curve y, add 3 to skip smoothing
			for (let y=int(gh); y<height; y++) {
				let a = float(constrain((y-gh)/this.glowHeight, 0, 1)); // amount in transition
				a = sin(radians(90.0 * a));                   // shape transition with sine

				let shadowNoise = noise((0.02*x)+width, (0.02*y)+height+this.yValue);  
				shadowNoise = this.shadowNoiseStrength * map(shadowNoise, 0.0, 1.0, -1.0, 1.0);       
				// blend top color to (bottom and shadow)
				let rval = float(lerp(red(this.topColor), red(this.baseColor)+shadowNoise, a));
				let gval = float(lerp(green(this.topColor), green(this.baseColor)+shadowNoise, a));
				let bval = float(lerp(blue(this.topColor), blue(this.baseColor)+shadowNoise, a));

				let clr = color(rval, gval, bval);          
				clr = distanceContrast(clr, this.hazeColor, this.depth);
				pixels[(y*width)+x] = clr;              
			}
		}
	}//render

	// Find the height of a snowbank at a given x.  First find which of the two
	// Bezier curves we want, then use those points for the actual work.
	// Test to see if we're left or right of the rightmost point of the left curve.
	//
	getHillHeightAtX(x) {
		let bpts = [];
		let inputOffset = 0;
		if (x > this.pts[3].x) inputOffset = 3;  
		for (let i=0; i<4; i++) {
			bpts[i] = createVector(this.pts[i+inputOffset].x, this.pts[i+inputOffset].y);
		}
		return(this.getBezYforX(x, bpts));
	}
     
	// Assuming a Bezier curve that has just a single y value for each x, find the 
	// value of t that lands us at that x, and return the y value for that t.
	// Simply put, return the y value for the given x.
	//
	getBezYforX(x, bpts) {
		let tLo = 0.0;
		let tHi = 1.0;
		let threshold = 0.0001; // if we get back a t within 1/10,000, good enough
		let numIterations = 500;  // we'll only try this many times
		while (numIterations-- > 0) {
			let tMid = float((tLo+tHi)/2.0);
			let bx = float(bezierPoint(bpts[0].x, bpts[1].x, bpts[2].x, bpts[3].x, tMid));
			if (abs(bx-x) < threshold) {
				let by = float(bezierPoint(bpts[0].y, bpts[1].y, bpts[2].y, bpts[3].y, tMid));
			return(by);
			}
			if (bx > x) tHi = tMid;
			    else tLo = tMid;
		}
		return((tLo+tHi)/2.0);
	}
}

class Tree {
 constructor(asunX, asunY, ahazeColor,
      abaseX, abaseY, adepth, atreeHeight,
      atrunkWidth, atrunkColor,
      apuffRadius, apuffDensity, apuffColor, ahighlightColor) {
      	  
      this.sunX = float(asunX);
      this.sunY = float(asunY); 
      this.hazeColor = ahazeColor;
      this.baseX = float(abaseX); 
      this.baseY = float(abaseY); 
      this.depth = float(adepth); 
      this.treeHeight = float(atreeHeight);  
      this.trunkWidth = float(atrunkWidth); 
      this.trunkColor = atrunkColor;
      this.puffRadius = float(apuffRadius); 
      this.puffDensity = float(apuffDensity); 
      this.puffColor = apuffColor; 
      this.highlightColor = ahighlightColor;
   }

	render() {
		//loadPixels();
		// find the top of the tree, allowing it to tilt a little
		let topX = float(this.baseX);
		let topY = float(this.baseY - this.treeHeight);
		this.baseX += wiggle(0, this.treeHeight/10.0); 

		// make a Bezier curve for the trunk
		let p0 = createVector(this.baseX, this.baseY);
		let p1 = createVector(lerp(this.baseX, topX, 0.3), lerp(this.baseY, topY, 0.3));
		let p2 = createVector(lerp(this.baseX, topX, 0.6), lerp(this.baseY, topY, 0.6));
		let p3 = createVector(topX, topY);
		// wiggle the control points left and right so the trunk is curvy
		p1.x += 0.2 * this.treeHeight * wiggle(0, 1);
		p2.x += 0.2 * this.treeHeight * wiggle(0, 1);

		// draw the trunk with the given width, and color adjusted for distance
		this.trunkColor = distanceContrast(this.trunkColor, this.hazeColor, this.depth);
		noFill();
		stroke(this.trunkColor);
		strokeWeight(this.trunkWidth);
		bezier(p0.x, p0.y, p1.x, p1.y, p2.x, p2.y, p3.x, p3.y);
		strokeWeight(1);

		// number of dots is puffball area (pi*radius*radius) times the density
		let numDots = int(this.puffRadius * this.puffRadius * PI * this.puffDensity);

		// find the point on the outer edge of the puff that's nearest the sun
		let spark = createVector(this.sunX-topX, this.sunY-topY);
		spark.normalize();
		spark.mult(this.puffRadius);
		spark.add(createVector(topX, topY));

		for (let p=0; p<numDots; p++) {
			// get a distance and angle for this dot, then find its (x,y)
			let thisR = float(this.getPuffR(this.puffRadius));
			let thisT = float(random(0.0, 360.0));
			let px = float(topX + (thisR * cos(thisT)));
			let py = float(topY + (thisR * sin(thisT)));

			// get distance to puff's spark (the source of highlight)
			let d2 = float(dist(px, py, spark.x, spark.y));

			// find highlight strength based on distance from spark
			let hlPower = float(constrain(map(d2, 0, this.puffRadius*1.25, 0, 1), 0, 1));

			// find the color, and add some noisy variation for effect
			let clrWiggle = 40.0;
			let rval = float(lerp(red(this.highlightColor), red(this.puffColor), hlPower) 
			           + wiggle(0, clrWiggle));
			let gval = float(lerp(green(this.highlightColor), green(this.puffColor), hlPower) 
			           + wiggle(0, clrWiggle));
			let bval = float(lerp(blue(this.highlightColor), blue(this.puffColor), hlPower) 
			           + wiggle(0, clrWiggle));

			// puffball fades out in the outermost 20 percent
			let aval = 255.0;
			let dimRadius = float(this.puffRadius * 0.8);
			if (thisR > dimRadius) {
				aval = map(thisR, this.puffRadius*0.8, this.puffRadius, 255, 0);  
			}

			// build the color, adjust it for distance, and draw the dot
			let clr = color(rval, gval, bval, aval);
			clr = distanceContrast(clr, this.hazeColor, this.depth);
			stroke(clr);
			point(px, py);
		}//for
	//updatePixels();
	}//render

	// A little hack to make a puffball shape that I find pleasing.  Then 
	// frequency of dots is given by the square root of the first 90 degrees
	// of the cosine curve.  There's no theory here; I just fooled around
	// with different patterns and liked this one the best.
	//
	getPuffR(puffRadius) {
		let x = 0;
		let y = 0;
		let thresh = 0;
		while (true) {
			x = random(0, 1);
			y = random(0, 1);
			thresh = cos(radians(x*90));
			thresh = sqrt(thresh);
			if (y < thresh) return(x*puffRadius);
		} 
	}//getPuffR
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch24-02-bigprojects_landscape.jpg')
}


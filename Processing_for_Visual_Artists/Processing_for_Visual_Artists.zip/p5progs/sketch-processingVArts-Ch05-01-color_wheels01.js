// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: wheels01.pde in Ch05
// Chapter: Ch05-01 color Figure 5.1
// Description: Color wheel in motion
//
let  StartAngle = 0;
let  AngleBump = 0;
let Color1, Color2;

function setup() {
   createCanvas(400, 400);
   smooth();
   Color1 = color(180, 95, 10);
   Color2 = color(0, 80, 110);
}

function draw() {
   background(Color2);
   noStroke();
   let  radius = 400;
   let circleCount = 0;
   let  angle = StartAngle;
   while (radius > 0) {
      fill(Color1);
      ellipse(200, 200, radius, radius);
      fill(Color2);
      arc(200, 200, radius, radius, angle, angle+PI);
      radius -= 30;
      angle += AngleBump;
   }
   StartAngle += .01;
   AngleBump += .005;
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch05-01-color_wheels01.jpg')
}


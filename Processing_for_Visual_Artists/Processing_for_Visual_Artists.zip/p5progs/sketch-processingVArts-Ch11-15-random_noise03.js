// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: noise03.pde in Ch11
// Chapter: Ch11-15 random Figure 11.15
// Description: bouncing ball whose diameter controlled by noise function leaving a trail
//
let  Cx, Cy;
let  Vx, Vy;
let  Radius;

function setup() {
   createCanvas(600, 400);
   Cx = 300;
   Cy = 200;
   Radius = 30;
   Vx = 2;
   Vy = 3;
}

function draw() {
   let  noiseScale = 0.02;
   Radius += lerp(-1, 1, noise(frameCount*noiseScale));
   Radius = constrain(Radius, 10, 50);

   Cx += Vx;
   Cy += Vy;
   if ((Cx-Radius < 0) || (Cx+Radius >= width)) {
      Vx = -Vx;
      Cx += 2 * Vx;
   }
   if ((Cy-Radius < 0) || (Cy+Radius >= height)) {
      Vy = -Vy;
      Cy += 2 * Vy;
   }

   //background(128, 103, 103);
   //noStroke();
   stroke(0);
   fill(224, 199, 37);
   ellipse(Cx, Cy, Radius*2, Radius*2);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch11-15-random_noise03.jpg')
}


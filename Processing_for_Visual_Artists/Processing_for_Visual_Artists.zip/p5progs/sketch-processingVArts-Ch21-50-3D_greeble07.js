// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: greeble07.pde in Ch21
// Chapter: Ch21-50 3D Figure 21.59
// Description: colored 3D greebles with moving lights
//

let Window = 600;
let GridX = 13;
let GridZ = 10;
let Ggrid = [];

class Greeble {
	constructor(x, z) {
		this.tx = x-(GridX/2.0);
		this.tz = z-(GridZ/2.0);    
		this.i4 = int(random(0, 1000))%4;
		this.angleY = radians(this.i4*90);
		this.angleZ = radians(3.0*(x-(GridX/2.0)));
		this.tileType = int(random(0, 1000))%4;
		this.clr = color(random(200, 255), random(200, 255), random(200, 255));
	}

	render(){
		fill(this.clr);
		push();
			translate(this.tx, 0, this.tz);
			translate(.5, 0, .5);
			rotateZ(this.angleZ);
			rotateY(this.angleY);
			translate(-.5, 0, -.5);

			switch (this.tileType) {
				case 0: this.drawGreeble00(); break;
				case 1: this.drawGreeble01(); break;
				case 2: this.drawGreeble02(); break;
				case 3: this.drawGreeble03(); break;
				default: this.drawGreeble03(); break;
			}
	pop();
	}
	drawGreeble00() {
		drawBox(.5, -.1, .5, 1, .1, 1);
		drawSphere(.4, 0, .35, .2);
		drawBox(.3, 0, .05, .2, .1, .1);
		drawBox(.25, 0, .75, .2, .05, .15);
		drawBox(.75, 0, .25, .1, .1, .1);
		drawBox(.75, 0, .4, .1, .1, .1);
		drawBox(.75, 0, .55, .1, .1, .1);
		drawBox(.9,  0, .8,  .2, .15, .25);
		drawBox(.55, 0, .8,  .08, .2, .22);
	}		

	drawGreeble01() {
		drawBox(.5, -.1, .5, 1, .1, 1);
		drawCone(.625, 0, .32, .23, .14, .35, 20, true);
		drawBox(.85, 0, .3, .3, .1, .2);
		drawBox(.25, 0, .2, .15, .2, .4);
		drawBox(.25, 0, .7, .3, .15, .2);
		drawBox(.325, 0, .9, .15, .15, .1);
		drawBox(.725, 0, .8, .025, .1, .22);
		drawBox(.775, 0, .8, .025, .1, .22);
		drawBox(.825, 0, .8, .025, .1, .22);
	}
   
	drawGreeble02() {
		drawBox(.5, -.1, .5, 1, .1, 1);
		drawCone(.12, 0, .37, .11, 0, .25, 10, false);
		drawCone(.2, 0, .6, .11, 0, .25, 10, false);
		drawCone(.4, 0, .71, .11, 0, .25, 10, false);
		drawCone(.62, 0, .65, .11, 0, .25, 10, false);
		drawSphere(.45, 0, .35, .2);
		drawBox(.4, 0, .3, .1, .05, .4);
		drawBox(.55, 0, .15, .3, .05, .1);
		drawBox(.85, 0, .35, .1, .25, .2);
		drawBox(.35, 0, .925, .5, .1, .15);
		drawBox(.8, 0, .825, .2, .075, .05);
		drawBox(.925, 0, .925, .05, .075, .15);
	}
   
	drawGreeble03() {
		drawBox(.5, -.1, .5, 1, .1, 1);
		drawBox(.425, 0, .6, .4, .1, .4);
		drawBox(.425, 0, .6, .3, .2, .3);
		drawBox(.425, 0, .6, .2, .3, .2);
		drawBox(.425, 0, .6, .1, .4, .1);
		drawBox(.35, 0, .9, .1, .05, .2);
		drawCone(.175, 0, .9, .05, 0, .15, 15, false);
		drawCone(.475, 0, .9, .05, 0, .15, 15, false);
		drawBox(.8, 0, .625, .2, .03, .03);
		drawBox(.8, 0, .675, .2, .03, .03);
		drawBox(.8, 0, .725, .2, .03, .03);
		drawBox(.8, 0, .775, .2, .03, .03);
		drawBox(.8, 0, .825, .2, .03, .03);
		drawSphere(.8, 0, .275, .05);
		drawSphere(.8, 0, .425, .05);
		drawBox(.9, 0, .075, .1, .1, .15);
		drawBox(.3, 0, .2, .4, .1, .2);
		drawBox(.075, 0, .175, .05, .05, .05);
		drawBox(.025, 0, .35, .05, .1, .5);
	}
}

function setup(){
	createCanvas(600, 600, WEBGL);
	smooth();
	for (let z=0; z<GridZ; z++) {
		Ggrid[z] = [];
		for (let x=0; x<GridX; x++) {
			Ggrid[z][x] = new Greeble(x, z);
		}
	}
}

function draw() {
	background(25, 42, 51);
	//translate(Window/2.0, Window/2.0, -400.0);
	translate(-50, -50, -400.0);
	scale(Window, -Window, Window);
	//lights();
	
	let lightDirX = float(lerp(-1, 1, noise((frameCount+151)*.02)));
	let lightDirY = float(lerp(-1, 1, noise((frameCount+307)*.02)));
	directionalLight(128, 128, 100, lightDirX, lightDirY, -.2);

	let lightDirX2 = float(lerp(-1, 1, noise((frameCount+500)*.02)));
	let lightDirY2 = float(lerp(-1, 1, noise((frameCount+800)*.02)));
	directionalLight(64, 128, 128, lightDirX2, lightDirY2, -.2);

	noStroke();
	fill(255, 255, 200);
	rotateX(radians(35));
	let gScale = 0.2;
	scale(gScale);

	for (let iz=0; iz<GridZ; iz++) {
		//Ggrid[iz] = [];
		for (let ix=0; ix<GridX; ix++) {
			Ggrid[iz][ix].render(); 
		}
	}
}

function drawSphere( cx,  cy,  cz,  r)
{
   push();
   translate(cx, cy, cz);
   sphere(r);
   pop();
}

function drawBox( cx,  cy,  cz,  dx,  dy,  dz)
{
   push();
   translate(cx, cy+(dy/2.0), cz);
   box(dx, dy, dz);
   pop();
}

function drawCone(cx, cy, cz, rLo, rHi, yTop, res, cap)
//cone([radius], [height], [detailX], [detailY], [cap])
//cylinder([radius], [height], [detailX], [detailY], [bottomCap], [topCap])
{
	push();
		translate(cx, cy, cz);
		if (rHi == 0){
			cone(rLo, yTop, res, res, cap);
		}
		else{
			cylinder(rLo, yTop, res, res, cap, cap);
		}
	pop();
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch21-50-3D_greeble07.jpg')
}


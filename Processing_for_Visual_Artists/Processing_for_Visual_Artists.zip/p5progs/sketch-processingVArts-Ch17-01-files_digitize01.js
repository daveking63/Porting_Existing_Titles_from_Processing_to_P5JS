// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: digitize01.pde in Ch17
// Chapter: Ch17-01 files Figure 17.2
// Description: Display of scanned silhouette of primitive 'oddman' 
//
let Picture;

function preload(){
	Picture = loadImage("data/oddman.png");
}

function setup() {
   createCanvas(800, 303);
   image(Picture, 0, 0);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch17-01-files_digitize01.jpg')
}


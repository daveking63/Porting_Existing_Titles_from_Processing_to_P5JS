// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: skyline01.pde in Ch23
// Chapter: Ch23-03 projects Figure 23.8
// Description: image of an urban skyline with sky and illuminate buildings and a water front with reflected lights
//
let NumLayers;
let Waterline;
let MaxHeight;
let WindowColor;

let pCount = 0;

function setup() {
	createCanvas(600, 400);
	smooth();
	noStroke();
	loadPixels();
	pixelDensity(1);
	WindowColor = color(220, 220, 20);
	Waterline = int(height * 0.8);
	MaxHeight = random(0.2 * height, 0.6*height);
	NumLayers = int(random(6, 10));
	drawSkyline();
}

function drawSkyline() {
	drawBackground();
	for (let layer=0; layer<NumLayers; layer++) {
	   drawLayer(layer);
	}
    drawLights();
}

function drawLayer(layer) {
   let  a = norm(layer, 0, NumLayers-1);
   let  avgWidth = lerp(width/50.0, width/20.0, a);
   let  avgHeight = lerp(MaxHeight, height/20.0, a);
   let  layerDensity = lerp(.1, 1, a);
   let  left = -avgWidth;

   while (left < width) {
      let  buildingWidth = vary(avgWidth, 0.1);
      let  buildingHeight = vary(avgHeight, 0.2);
      let drawMe = random(0, 1) < layerDensity;
      if (drawMe) {
         drawBuilding(left, Waterline, buildingWidth, buildingHeight);
      }
      left += buildingWidth;
   }
}


function drawBuilding(bLeft, bBottom, bWid, bHgt) {
   let  buildingGrayColor = random(30, 90);
   fill(buildingGrayColor);
   rect(bLeft, bBottom, bWid, -bHgt);
  
   let r = vary(red(WindowColor), 0.1);
   let g = vary(green(WindowColor), 0.1);
   let b = vary(blue(WindowColor), 0.1);
   windowColor = color(r, g, b);
   fill(windowColor);

   // figure out how many windows to draw, then draw each one
   let numAcross = int(random(10.0, 20.0));
   let numHigh = int(random(10.0, 20));
   let  wWid = bWid / (numAcross*2.0);
   let  wHgt = bHgt / (numHigh*2.0);

   let  windowDensity = random(0.1, 0.7);
   for (let wx=0; wx<numAcross; wx++) {
      for (let wy=0; wy<numHigh; wy++) {
         let  wLeft = (1.0/(numAcross*2.0)) + (wx*2*wWid);
         let  wBottom = (1.0/(numHigh*2.0)) + (wy*2*wHgt);
         if (random(0, 1) < windowDensity) {
            rect(bLeft+wLeft, bBottom-wBottom, wWid, -wHgt);
         }
      }
   }  
}

function drawBackground() {
	// draw the sky: a radial blend from (cx, cy)
	let cx = width * random(0.6, 0.8);
	let cy = vary(Waterline, 0.1);
	let distToUL = dist(cx, cy, 0, 0);
	let lighter = color(5, 60, 130);
	let darker = color(0, 15, 45);

	for (let y=0; y<height; y++) {
		for (let x=0; x<width; x++) {
			let  a = dist(x, y, cx, cy)/distToUL;
			a = constrain(a, 0, 1);
			let clr = lerpColor(lighter, darker, a);
			let ya = 1 - norm(y, 0, Waterline);
			let threshold = 0.001 * ya;
			if (random(0, 1) < threshold) {
				a = sqrt(a);
				clr = lerpColor(clr, color(255), a);
			}
			set(x, y, clr);
		}
     }

   //draw the (fake) building reflections
   let waterColor = color(10,10,30);
   for (let y=Waterline; y<height; y++) {
      for (let x=0; x<width; x++) {
         // ya is distance from Waterline
         let  ya = 1-norm(y, Waterline, height-1);
         // ya2 creates a short fade right at the Waterline
         let  ya2 = constrain((y-Waterline)/3.0, 0, 1);
         let  wnoise = noise(x*0.04, y*0.01);
         wnoise = ya2 * ya * sq(wnoise);
         let clr = lerpColor(waterColor, WindowColor, wnoise);
         set(x, y, clr);
      }
   }
   updatePixels();
}

function drawLights() {
	let numLights = 20;
	noStroke();
	let lradius = 8;
	for (let l=0; l<numLights; l++) {
		let lx = int(random(0, width));
		let ly = int(Waterline - lradius+ vary(lradius, 0.1));
		let lightColor = color(random(210, 255),random(210, 255),random(210, 255));

		// draw the light as two circles to fake a glow
		fill(red(lightColor), green(lightColor), blue(lightColor), 128);
		ellipse(lx, ly, lradius, lradius);
		fill(red(lightColor), green(lightColor), blue(lightColor), 255);
		ellipse(lx, ly, lradius/2, lradius/2);

		// draw fake reflections and add to water color
		for (let y = Waterline; y < height; y++) {
			for (let x = lx-2; x < lx+2; x++) {
				let  ya = float(1 - norm(y, Waterline, height-1));  
				let  wnoise = float(noise(x*0.04, y*0.01));
				wnoise = sq(ya) * sq(wnoise);  // fade out noise 
				let oldclr = color(get(x, y));
				let clr = lerpColor(oldclr, lightColor, wnoise);
				set(x, y, clr);
			}
		}
	}
}

function  vary(value, percent) {
	  let  range = value * percent;
	  value += random(-range, range);
	  return(value);
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch23-03-projects_skyline01.jpg')
}


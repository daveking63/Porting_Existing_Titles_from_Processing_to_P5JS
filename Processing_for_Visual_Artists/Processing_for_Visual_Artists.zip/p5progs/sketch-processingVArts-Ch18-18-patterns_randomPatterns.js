// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: randomPatterns.pde in Ch18
// Chapter: Ch18-18 patterns Figure 18.52
// Description: Using two random patterns to generate point values
//
function setup() {
	createCanvas(750, 550);
	smooth();
	background(173, 180, 125);
	let hPattern = 0;
	let vPattern = 0;
	drawPatterns(hPattern, vPattern);
	drawDots(hPattern, vPattern);
}

function getRandom(patternChoice) {
	let  x, y, threshold;
	do {
		x = random(0, 1);
		y = random(0, 1);
		threshold = getThreshold(x, patternChoice);
	} while (y>threshold);
	return(x);
}

function drawPatterns(hPattern, vPattern) {
	fill(240, 218, 180);
	stroke(0);
	rect(125, 25, 600, 100);  // horizontal plot area
	rect(25, 125, 100, 400);  // vertical plot area

	fill(240, 275, 180);
	rect(125, 125, 600, 400);  // the main dots area

	noFill();
	stroke(3, 125, 135);
	let  oldpx = 0;
	let  oldpy = 0;

	// draw the horizontal pattern
	for (let x=0; x<600; x++) {
		let  ax = x/599.0;
		let  y = getThreshold(ax, hPattern);
		let  px = 125+x;
		let  py = 125 - (100*y);
		if (x>0) line(oldpx, oldpy, px, py);
		oldpx = px;
		oldpy = py;
	}

	// draw the vertical pattern
	for (let y=0; y<400; y++) {
		let  ay = y/399.0;
		let  x = getThreshold(ay, vPattern);
		let  px = 125 - (100*x);
		let  py = 125+y;
		if (y>0) line(oldpx, oldpy, px, py);
		oldpx = px;
		oldpy = py;
	}
}

function drawDots(hPattern, vPattern) {
	noStroke();
	fill(205, 125, 28);
	let numEllipses = 1800;
	for (let i=0; i<numEllipses; i++) {
		let  px = 600 * getRandom(hPattern);
		let  py = 400 * getRandom(vPattern);
		ellipse(125+px, 125+py, 8, 8);
   }
}

function getThreshold(x, patternChoice) {
	let  loAngle, hiAngle;
	switch (patternChoice) {
		case 0:  // uniform
			loAngle = hiAngle = 0;
			break;
		case 1:  // one hump
			loAngle = PI;
			hiAngle = 3*PI;
			break;
		case 2:  // two humps
			loAngle = PI;
			hiAngle = 5*PI;
			break;
		case 3:  // one dip
			loAngle = 0;
			hiAngle = 2*PI;
			break;
		case 4:  // two dips
			loAngle = 0;
			hiAngle = 4*PI;
			break;
		case 5:  // S 
			loAngle = PI;
			hiAngle = 2*PI;
			break;
		case 6:  // backwards S
			loAngle = 0;
			hiAngle = PI;
			break;
		default:
			println("I don't know pattern choice "+patternChoice);
			loAngle = hiAngle = 0;
			break;
	}
	let  angle = lerp(loAngle, hiAngle, x);
	let  threshold = map(cos(angle), -1, 1, 0, 1);
	return(threshold);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch18-18-patterns_randomPatterns.jpg')
}


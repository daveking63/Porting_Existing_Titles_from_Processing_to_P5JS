// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: stackpop01.pde in Ch09
// Chapter: Ch09-16 transforms Figure 9.18
// Description: setup with simple background and rectangle
//
function setup() {
   createCanvas(600, 400);
}

function draw() {
   background(128);
   fill(128, 202, 83);
   rect(100, 100, 250, 200);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch09-16-transforms_stackpop01.jpg')
}


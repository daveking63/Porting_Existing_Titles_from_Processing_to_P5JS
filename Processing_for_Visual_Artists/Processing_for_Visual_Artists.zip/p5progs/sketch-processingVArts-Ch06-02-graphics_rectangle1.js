// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: rectangle1.pde in Ch06
// Chapter: Ch06-02 graphics Figure 6.4
// Description: Display rectangle
//
function setup() { 
   createCanvas(600, 400);
   background(163, 143, 109);
}  

function draw() {
   rect(40, 80, 450, 200);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch06-02-graphics_rectangle1.jpg')
}


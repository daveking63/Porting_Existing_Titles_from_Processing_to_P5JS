// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: box4.pde in Ch09
// Chapter: Ch09-04 transforms Figure 9.4
// Description: drawing two rectangles (boxes) representing before and after rotation with a circle touching upper left corners of boxes
//
function setup() {
   createCanvas(600, 400);
}

function draw() {
   background(210, 177, 68);
   stroke(0);
   noFill();
   strokeWeight(2);
   let radiusUL = dist(0, 0, 150, 100);
   ellipse(0, 0, radiusUL*2, radiusUL*2);
   strokeWeight(1);

   fill(149, 93, 13, 128);
   rect(150, 100, 250, 150);
   fill(139, 49, 30, 128);
   rotate(radians(20));
   rect(150, 100, 250, 150);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch09-04-transforms_box4.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: noise04a.pde in Ch11
// Chapter: Ch11-17 random Figure 11.17
// Description: Noise with larger scale factor
//
function setup() {
   createCanvas(600, 400);
   let  noiseScale = 0.05;
   for (let y=0; y<height; y++) {
      for (let x=0; x<width; x++) {
         let  noiseVal = noise(x*noiseScale,y*noiseScale);
         noiseVal *= 255;  // scale up from [0, 1] to [0, 255]
         stroke(noiseVal);
         point(x, y);
      }
   }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch11-17-random_noise04a.jpg')
}


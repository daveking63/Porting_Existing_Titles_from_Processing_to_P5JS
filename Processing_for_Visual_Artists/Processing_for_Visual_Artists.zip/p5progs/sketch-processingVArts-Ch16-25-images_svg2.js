// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: svg2.pde in Ch16
// Chapter: Ch16-25 images Figure 16.32
// Description: zooming in on an SVG file
//

let s;

function preload(){
	s = loadImage("data/lamp.svg");
}

function setup() {
  createCanvas(350, 500);
  smooth();
  image(s, -150, -600, 400, 1000);
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch16-25-images_svg2.jpg')
}


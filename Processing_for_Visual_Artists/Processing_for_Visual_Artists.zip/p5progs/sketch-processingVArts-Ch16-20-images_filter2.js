// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: filter2.pde in Ch16
// Chapter: Ch16-20 images Figure 16.26
// Description: applying combined filters to an image
//
let Hike;
let Results = [];

function preload(){
	Hike = loadImage("data/myPhoto.jpg");
}

function setup() {
	createCanvas(1350, 1050); 

	for (let i=0; i<16; i++) {Results[i] = createImage(300, 225);}
	for (let i=0; i<16; i++) {runFilter(i);}

	background(128);

	for (let y=0; y<4; y++) {
		for (let x=0; x<4; x++) {
			copy(Results[(y*4)+x], 0, 0, 300, 225, x*350, y*275, 300, 225);
		}
	}
}

function runFilter(i) {
	image(Hike, 0, 0, 300, 225);
	print(i);
	switch (i) {
	case  0: filter(THRESHOLD, 0.5); break;
	case  1: filter(BLUR, 1);  filter(THRESHOLD, 0.5); break;
	case  2: filter(BLUR, 5);  filter(THRESHOLD, 0.5); break;
	case  3: filter(BLUR, 15); filter(THRESHOLD, 0.5); break;

	case  4: filter(POSTERIZE, 4); break;
	case  5: filter(BLUR, 1);  filter(POSTERIZE, 4); break;
	case  6: filter(BLUR, 5);  filter(POSTERIZE, 4); break;
	case  7: filter(BLUR, 15); filter(POSTERIZE, 4); break;
	case  8: multiErode(3);   filter(POSTERIZE, 4); break;
	case  9: multiDilate(3);  filter(POSTERIZE, 4); break;
	case 10: multiErode(3);   multiDilate(3);   break;
	case 11: multiDilate(3);  multiErode(3);  break;

	case 12: filter(BLUR, 3);  multiErode(3); break;
	case 13: filter(BLUR, 3);  multiDilate(3); break;
	case 14: filter(BLUR, 3);  multiErode(8); break;
	case 15: filter(BLUR, 3);  multiDilate(8); break;
	default: break;
	}
	Results[i] = get(0, 0, 300, 225);
}

function multiDilate(repeats){
	for (i=0; i < repeats; i++){
		filter(DILATE); 
	}
}

function multiErode(repeats) { 
	for (i=0; i<repeats; i++){
		filter(ERODE); 
	}
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch16-20-images_filter2.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: cleanup01.pde in Ch17
// Chapter: Ch17-10 files Figure 17.8
// Description: Display of scanned silhouette of primitive 'oddman' created from digitized points read from text file - slight errors
//

let words = [];
let lines = [];

function preload(){
  lines = loadStrings("data/Body-ManPoints.txt");
}

function setup() {
  createCanvas(1600,630);
  background(255);
  stroke(0);
  strokeWeight(2);
  let ox, oy, x, y;
  ox = oy = x = y = 0;
  for (let i=0; i<lines.length; i++) {
    let words = split(lines[i], '\t');
    if (i>0) {
      x = int(words[0]);
      y = int(words[1]);
      line(ox, oy, x, y);
    }
    ox = x;
    oy = y;
  }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch17-10-files_cleanup01.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: recurbox03.pde in Ch10
// Chapter: Ch10-10 recursion Figure 10.12
// Description: recursively drawn (side by side) rectangles of 'random'ly specified sizes and gray colors
//
function setup() {
   createCanvas(600, 400);
   noStroke();
   handleBox(0, 0, 600, 400, 128);
}

function handleBox(ulx, uly, wid, hgt, gray) {
   fill(gray);
   rect(ulx, uly, wid, hgt);
   let  minSide = 20;
   if ((wid < minSide) || (hgt < minSide)) {
      return;
   }
   if (wid > hgt) {
      let leftWid = wid * random(0.25, 0.75);  // width of the left box
      handleBox(ulx, uly, leftWid, hgt, gray-10);
      handleBox(ulx+leftWid, uly, wid-leftWid, hgt, gray+10);
   } else {
      let topHgt = hgt * random(0.25, 0.75);  // height of the top box
      handleBox(ulx, uly, wid, topHgt, gray-10);
      handleBox(ulx, uly+topHgt, wid, hgt-topHgt, gray+10);
   }
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch10-10-recursion_recurbox03.jpg')
}


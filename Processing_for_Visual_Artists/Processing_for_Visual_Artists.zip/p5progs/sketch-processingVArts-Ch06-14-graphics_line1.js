// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: line1.pde in Ch06
// Chapter: Ch06-14 graphics Figure 6.21
// Description: display pair of lines
//
function setup() { 
   createCanvas(600, 400);
   background(163, 143, 109);
}  

function draw() {
   strokeWeight(1);
   line(200, 40, 450, 350);
   strokeWeight(4);
   line(250, 40, 500, 350);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch06-14-graphics_line1.jpg')
}


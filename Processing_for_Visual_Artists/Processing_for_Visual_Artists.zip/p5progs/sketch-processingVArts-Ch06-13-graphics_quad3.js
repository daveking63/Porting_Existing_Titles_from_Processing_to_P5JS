// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: quad3.pde in Ch06
// Chapter: Ch06-13 graphics Figure 6.20
// Description: display bow tie quad
//
function setup() { 
   createCanvas(600, 400);
   background(163, 143, 109);
}  

function draw() {
   quad(150, 50, 50, 200, 500, 100, 400, 350);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch06-13-graphics_quad3.jpg')
}


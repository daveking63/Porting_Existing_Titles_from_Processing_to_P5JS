// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: point1.pde in Ch06
// Chapter: Ch06-15 graphics Figure 6.22
// Description: display single point
//
function setup() { 
   createCanvas(600, 400);
   background(163, 143, 109);
}  

function draw() {
   point(300, 200);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch06-15-graphics_point1.jpg')
}


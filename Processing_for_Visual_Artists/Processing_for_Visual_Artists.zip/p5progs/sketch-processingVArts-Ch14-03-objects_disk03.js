// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: disk03.pde in Ch14
// Chapter: Ch14-03 objects No Figure
// Description: Initialization of object program with two 'ghost disks' with one attribute
//
let Ghost0, Ghost1;

function setup() {
   createCanvas(600, 400);
   background(164, 164, 164);
   Ghost0 = new Disk(5);
   Ghost1 = new Disk(37);
   print("Ghost0 radius = "+Ghost0.radius);
   print("Ghost1 radius = "+Ghost1.radius);
   msg1 = "Ghost0 radius = " + str(Ghost0.radius);
   msg2 = "Ghost1 radius = " + str(Ghost1.radius);	   
   textSize(30);
   text(msg1,175,180);
   text(msg2,175,220);
}

function draw() {
   // draw something
}

class Disk {
	constructor(aRadius){
		this.xPos;   // 1. Current location (X and Y)
		this.yPos;
		this.xDir;   // 2. Current motion (X and Y)
		this.yDir;
		this.radius = aRadius; // 3. Radius
		this.clr;    // 4. Color
	}// constructor
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch14-03-objects_disk03.jpg')
}


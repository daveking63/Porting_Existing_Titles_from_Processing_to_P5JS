// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: sandstorm.pde in Ch24
// Chapter: Ch24-01 bigprojects Figure 24.7
// Description: flows of sand grains created by wind 
//

let LoopingEnabled;  // boolean true if draw() is being called
let Sparks = [];  //Grain [] Sparks - the Grains that fall down the screen
let Gusts = [];  // Wind [] Gusts - the winds that push them around

// Create the graphics window.  Then create the global
// arrays of Sparks and Gusts and initialize them with
// objects.  Turn on the flag that indicates we're looping.
//

function setup() {
	createCanvas(600, 400);
	let numSparks = 5000;

	//Sparks = new Grain[numSparks];
	//Gusts = new Wind[numGusts];

	for (let i=0; i<numSparks; i++) {
		Sparks[i] = new Grain();
	}

	let numGusts = 8;

	for (let i=0; i<numGusts; i++) {
		Gusts[i] = new Wind();
	}

	LoopingEnabled = true;
}

// Draw each Spark and update it.
// Then update all the Gusts.
function draw() {
	
	for (let i=0; i<Sparks.length; i++) {
	  Sparks[i].render();
	  Sparks[i].move();
	}
	for (i=0; i<Gusts.length; i++) {
	  Gusts[i].update();
	}
}

// If the user presses a key, stop looping if it's
// enabled, or start again if it's been stopped.
//
function keyPressed() {
	if (LoopingEnabled)  noLoop();
	else loop();
	LoopingEnabled = !LoopingEnabled;
}




// Grain class
// version 1.0 - AG 30 April 2009
//

class Grain {
	constructor() {
		this.center;       // PVector center location
		this.oldCenter;    // PVector - position in last frame
		this.oldVelocity;     // PVector - movement in last frame
		this.radius;        // float - size in pixels
		this.ch, this.cs, this.cb;    // float - color
		this.fillGrain(true);
	}

	// Fill in the Grain with random values.  Pick a point above the
	// screen so that the Grain will take a while to fall.  This is
	// not very efficient!  Assign a color based on the Grain's
	// horizontal position.
	//

	fillGrain(firstFill) {
		this.center = createVector(random(0, width), random(-height, 0));
		if (!firstFill) this.center.y = 0.0;
		this.oldCenter = createVector(this.center.x, this.center.y);
		this.oldVelocity = createVector(random(-.02,.02), random(.4, 1.8));
		this.radius = random(0.25, 2.0);

		// float - five hand-picked HSB colors I like
		let  colorSets = [  
			35, 238, 133,
			42, 231, 210,
			21, 232, 235,
			18, 204, 115,
			9, 248, 210] ;

		let colorSteps = int(colorSets.length/3)-1;
		let setWidth = float(1.0*width/colorSteps);
		let setNumber = int(this.center.x/setWidth);
		let a = float((this.center.x - (setNumber * setWidth))/setWidth);
		
		this.ch = lerp(colorSets[(setNumber*3)], colorSets[(setNumber*3)+3], a);
		this.cs = lerp(colorSets[(setNumber*3)+1], colorSets[(setNumber*3)+4], a);
		this.cb = lerp(colorSets[(setNumber*3)+2], colorSets[(setNumber*3)+5], a);

		this.ch = (this.ch + (frameCount * 0.02)) % 255.0;
		this.cs = constrain(this.cs+random(-10, 10), 0, 255);
		this.cb = constrain(this.cb+random(-10, 10), 0, 255); 
	}

	// draw this Grain as a short stroke from the oldCenter to center
	render() {
	strokeWeight(this.radius);      
	colorMode(HSB);
	stroke(this.ch, this.cs, this.cb);
	line(this.oldCenter.x, this.oldCenter.y, this.center.x, this.center.y);
	}

	// update the Grain's position.  First, store where it is now into
	// oldCenter.  Take the velocity from the last update and scale it
	// to simulate drag due to the effects of atmosphere.  Add in
	// gravity.  Then add in the total contribution of all wind gusts.
	// move the Grain to the new position.  If it's fallen off the bottom
	// of the screen, recycle it by loading it with new random values.
	move() {
		// save the current center
		this.oldCenter.x = this.center.x;
		this.oldCenter.y = this.center.y;

		// reduce the old velocity to account for atmospheric drag
		let newVelocity = createVector(this.oldVelocity.x, this.oldVelocity.y);
		newVelocity.mult(0.3);

		// start the new effect (in totalWind) with some gravity
		let totalWind = createVector(0, random(1.5, 2.0));

		// add in the effects of each wind gust
		for (let i=0; i<Gusts.length; i++) {
			let w = Gusts[i].windAt(this.center);
			totalWind.add(w);
	}

	// add the new effect (in totalWind) to the old velocity,
	// giving a new velocity.  Add that to the center.
	newVelocity.add(totalWind);
	this.center.add(newVelocity);

	this.oldVelocity.x = newVelocity.x;
	this.oldVelocity.y = newVelocity.y;

	// if the Grain has fallen below the screen, recycle it.
	if (this.center.y > height) {
	this.fillGrain(false);
	}
	}
}
  
// Wind class
// version 1.0 - AG 30 April 2009
//

class Wind {
   // PVector center;    center of the wind
   // PVector velocity;  speed of the wind itself across the screen
   // PVector wind;      direction of the wind
   // float radius;      radius of wind effect
   // float strength;    strength of the wind

   // create a new object with random values
   constructor() {
      this.center = createVector(random(50, width-50), random(50, height-50));
      this.velocity= createVector(random(-1, 1), random(-1, 1));
      this.wind= createVector(random(-3, 3), random(-1, 1));
      this.radius = random(40, 220);
      this.strength = random(-5, 5);
   }

	// find the effect of this wind at this point
	windAt(p) {
	let windSum = createVector(0, 0);  // by default, there's no effect
	let pointToWind = float(dist(p.x, p.y, this.center.x, this.center.y));
	if (pointToWind < this.radius) {
		// we're inside radius.  Find the strength from the distance
		// of this point to the center.
		let wstrength = float(map(pointToWind, 0, this.radius, this.strength, 0));
		// compute the line perpendicular to the line from
		// the center to this point; that's where the wind is pointing.
		let dPoint = createVector(p.x-this.center.x, p.y-this.center.y);
		let windDir = createVector(dPoint.y, -dPoint.x);
		// scale the wind based on its strength at this point
		windDir.normalize();
		windDir.mult(wstrength);
		windSum.add(windDir);
		}
		return(windSum);
	}

	// move the wind around on the screen like a bouncing ball
	update() {
		this.center.add(this.velocity);
		if ((this.center.x < 0) || (this.center.x >= width)) {
			this.velocity.x = -this.velocity.x;
			this.center.x += 2*this.velocity.x;
		}
		if ((this.center.y < 0) || (this.center.y >= height)) {
			this.velocity.y = -this.velocity.y;
			this.center.y += 2*this.velocity.y;
		}
	}
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch24-01-bigprojects_sandstorm.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: balls03.pde in Ch22
// Chapter: Ch22-03 oddsends Figure 22.3
// Description: randomly constructed balls moving randomly through the window

let Flies = [];
let numFlies = 4;

function  setup() {
	createCanvas(600, 400);
	for (let i = 0; i < numFlies; i++){
		Flies[i] = new Ball();
	}
}

function  draw() {
   background(128, 103, 103);
   for (let i=0; i<Flies.length; i++) {
      Flies[i].render();
      Flies[i].move();
   }
}

class Ball {
	constructor() {
		this.cx = float(random(50, width-50));  
		this.cy = float(random(50, height-50));
		this.vx = float(random(3, -3));  
		this.vy = float(random(3, -3));
		this.radius = float(random(10, 30));
		this.cr = float(random(100, 255)); 
		this.cg = float(random(100, 255)); 
		this.cb = float(random(100, 255)); 
		this.ca = float(random(100, 255));
	}

	render() {
		fill(this.cr, this.cg, this.cb, this.ca);
		ellipse(this.cx, this.cy, 2*this.radius, 2*this.radius);
	}

	move() {
		let noiseScale = 0.02;
		this.radius += lerp(-1, 1, noise(this.cx*noiseScale));
		this.radius = constrain(this.radius, 10, 100);
		this.vx += lerp(-0.25, 0.25, noise(noiseScale*this.cx, noiseScale*this.cy));
		this.vy += lerp(-0.25, 0.25, noise(noiseScale*this.cy, noiseScale*this.cx));
		this.cx += this.vx;
		this.cy += this.vy;
		if ((this.cx-this.radius < 0) || (this.cx+this.radius >= width)) {
			this.vx = -this.vx;
			this.cx += 2*this.vx;
		}
		if ((this.cy-this.radius < 0) || (this.cy+this.radius >= height)) {
			this.vy = -this.vy;
			this.cy += 2*this.vy;
		}
	}
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch22-03-oddsends_balls03.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: findPoint03.pde in Ch12
// Chapter: Ch12-26 cmcurves Figure 12.32
// Description: Finding the values of t for various horizontal line a particular points along a curve
//
let Xp = [40,  50, 540, 300];
let Yp = [940, 160, 200, 900];
let TimeAxisY = 300;
let  Tlo = 0.0;
let  Thi = 1.0;

function setup() {
   createCanvas(600, 400);
   background(210, 215, 140);
   noFill();
   curve(Xp[0], Yp[0], Xp[1], Yp[1], Xp[2], Yp[2], Xp[3], Yp[3]);

   line(50, TimeAxisY, 540, TimeAxisY);    // the time axis
   let  targetX = 120;
   for (let step=0; step<10; step++) {
      refineInterval(step, targetX);
      print("step "+step+":  Tlo = "+Tlo+"  Thi = "+Thi+"  (width = "+(Thi-Tlo)+")");
   } 
   
   line(targetX, 0, targetX, TimeAxisY);
   let  tmid = (Tlo+Thi)/2.0;
   let  px = curvePoint(Xp[0], Xp[1], Xp[2], Xp[3], tmid);
   let  py = curvePoint(Yp[0], Yp[1], Yp[2], Yp[3], tmid);
   ellipse(px, py, 20, 20);
}

function refineInterval(step, targetX) {
  let  xLeft = curvePoint(Xp[0], Xp[1], Xp[2], Xp[3], Tlo);
  let  xRight = curvePoint(Xp[0], Xp[1], Xp[2], Xp[3], Thi);
  let  barY = TimeAxisY - ((step+1)*10);
  line(xLeft, barY, xRight, barY); 
  
  let  tmid = (Tlo + Thi)/2.0;
  let  xval = curvePoint(Xp[0], Xp[1], Xp[2], Xp[3], tmid);
  if (targetX < xval) Thi = tmid;
                 else Tlo = tmid;
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch12-26-cmcurves_findPoint03.jpg')
}


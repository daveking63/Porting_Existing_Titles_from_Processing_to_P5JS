// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: swap3.pde in Ch16
// Chapter: Ch16-07 images Figure 16.8
// Description: pointilist effect by randomly swapping pixels with any neighbor
//
let img;

function preload(){
	img = loadImage("data/myPhoto.jpg");
}

function setup() {
	createCanvas(600, 400);
	image(img, 0, 0, 600, 400);
	img.loadPixels;
}

function draw() {
	for (let y=1; y<height; y++) {
		for (let x=0; x<width; x++) {
			if (random(1000) > 950) {
			let j = int(random(1000));
			if (j < 250) swap(x, y, x, y-1);
			else if (j < 500) swap(x, y, x, y+1);
			else if (j < 750) swap(x, y, x-1, y);
			else              swap(x, y, x+1, y);
			}
		}
	}
	img.updatePixels();
	image(img,0,0);
}

function swap(x0, y0, x1, y1) {
	let c0 = img.get(x0, y0);
	let c1 = img.get(x1, y1);
	img.set(x0, y0, c1);
	img.set(x1, y1, c0);
}

//
function keyTyped(){

	if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch16-07-images_swap3.jpg')
}


// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: strip02.pde in Ch21
// Chapter: Ch21-32 3D Figure 21.36
// Description: begin shape triangle_strip
//

let ax = 200;  let ay = 320;
let bx =  80;  let by = 160;
let cx = 220;  let cy = 200;
let dx = 300;  let dy =  40;
let ex = 380;  let ey = 200;
let fx = 520;  let fy = 160;
let gx = 400;  let gy = 320;

function  setup() {
	createCanvas(600, 400);
	background(222, 217, 177);
	fill(131, 209, 119);
	strokeWeight(3);
	smooth();
	drawLeaf();
}

function  drawLeaf() {
	beginShape(TRIANGLE_STRIP);
	vertex(ax, ay);
	vertex(bx, by);
	vertex(cx, cy);
	vertex(dx, dy);
	vertex(ex, ey);
	vertex(fx, fy);
	vertex(gx, gy);
	endShape();
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch21-32-3D_strip02.jpg')
}


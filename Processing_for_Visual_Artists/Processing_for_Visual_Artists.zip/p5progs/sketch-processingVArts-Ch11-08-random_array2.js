// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: array2.pde in Ch11
// Chapter: Ch11-08 random Figure 11.8
// Description: drawing concentric ellipses with an array of diameters
//
function setup() {
   createCanvas(600, 400);
   background(2, 59, 71);
   fill(155, 226, 242);
   noStroke();
}

function draw() {
let diameters = [ 30, 50, 90, 20, 44, 76, 22, 30 ];
   stroke(0);
   for (let i=0; i<8; i++) {
      ellipse(100, 100, diameters[i], diameters[i]);
   }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch11-08-random_array2.jpg')
}


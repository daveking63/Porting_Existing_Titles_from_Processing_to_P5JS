// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: bell3.pde in Ch19
// Chapter: Ch19-14 lamp Figure 19.21
// Description: moving circle with noFill following a curvilinear path in reverse direction
//
function setup() {
	createCanvas(600, 400);
	background(0);
	noFill();
	stroke(255);
}   

function draw() {
	if (frameCount > 75) return;
	let  percent = map(frameCount, 0, 75, 0, 1);
	let  v = exp(-4*percent*percent);
	let  w = 1-v;
	let  centerx = lerp(100, 500, w);
	let  centery = lerp(200, 100, sin(w * radians(180)));
	stroke(255, 255*w, 255*w);
	ellipse(centerx, centery, 75, 75);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch19-14-lamp_bell3.jpg')
}


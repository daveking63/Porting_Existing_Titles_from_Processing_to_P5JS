// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: array1.pde in Ch11
// Chapter: Ch11-07 random Figure 11.7
// Description: simple work of art with differing sized ellipses at same y loc with different x's
//

function setup() {
   createCanvas(600, 400);
   background(2, 59, 71);
   fill(155, 226, 242);
   noStroke();
}

function draw() {
   ellipse(50, 100, 30, 30);
   ellipse(110, 100, 50, 50);
   ellipse(200, 100, 90, 90);
   ellipse(275, 100, 20, 20);
   ellipse(327, 100, 44, 44);
   ellipse(407, 100, 76, 76);
   ellipse(475, 100, 22, 22);
   ellipse(521, 100, 30, 30);
}

function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch11-07-random_array1.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: mouse1.pde in Ch07
// Chapter: Ch07-05 human No Figure
// Description: setting background red & green components with mouse
//
let Redval = 192; // background red
let Grnval = 64;  // background green
let Bluval = 0;   // background blue
let  MyColor;

function setup() {
   createCanvas(600, 400);
   MyColor = color(Redval, Grnval, Bluval);
   background(MyColor);
}

function draw() {
   Redval = map(mouseX, 0, 599, 0, 255);  // convert 0-599 to 0-255
   Grnval = map(mouseY, 0, 399, 0, 255);  // convert 0-399 to 0-255
   background(MyColor);
   MyColor = color(Redval, Grnval, Bluval);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch07-05-human_mouse1.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: radar01.pde in Ch22
// Chapter: Ch22-09 oddsends Figure 22.15
// Description: background for simulated radar screen
//

let rBackground;

let Window = 480;       // createCanvas of the graphics window
let  Cx = Window/2.0;  // center x
let  Cy = Window/2.0;  // center y

let NumRings = 3;       // number of circles around the center
let RingLo = 0.3;     // percentage of window for first radius
let RingHi = 0.9;     // percentage of window for last radius

let NumLines = 8;          // how many radial lines 
let RadialLineLo = 0.2;  // percentage of window where they start
let RadialLineHi = 0.9;  // percentage of window where they end

let NumHashMarks = 360;    // number of little hash marks around outside
let HashLineLo = 0.9;    // percentage of window where they start
let HashLineHi = 0.95;   // percentage of window where they end

let BrightGreen; // bright-green color

function setup() {
   createCanvas(Window, Window);
   smooth();
   BrightGreen = color(140, 215, 85);  // bright-green color
   makeRBackground(); //create the background
}

function draw() {
   image(rBackground, 0, 0);   // draw the background
}

function makeRBackground() {
   rBackground = createGraphics(Window, Window);
   rBackground.background(24, 44, 18);   //dark green background

   // draw background grid

   rBackground.stroke(42, 94, 30);
   rBackground.strokeWeight(1);
   let  lineGap = (Window/16.0);
   rBackground.noFill();
   for (let i=1; i<16; i++) {
      rBackground.line(0, i*lineGap, Window, i*lineGap);
      rBackground.line(i*lineGap, 0, i*lineGap, Window);
   }

   // draw inner graphics
   rBackground.stroke(red(BrightGreen), green(BrightGreen), blue(BrightGreen));
   rBackground.strokeWeight(2);

   // inner rings
   let  diameter;
   for (let ring=0; ring<NumRings; ring++) {
      diameter = Window * lerp(RingLo, RingHi, ring*1.0/(NumRings-1));
      rBackground.ellipse(Cx, Cy, diameter, diameter);
   }

   // radial lines
   for (let lineCount=0; lineCount<NumLines; lineCount++) {
      let  theta = radians(360.0 * lineCount/NumLines);
      let  r0 = RadialLineLo * (Window/2.0);
      let  r1 = RadialLineHi * (Window/2.0);
      rBackground.line(Cx+(r0*cos(theta)), Cy+(r0*sin(theta)),
                      Cx+(r1*cos(theta)), Cy+(r1*sin(theta)));
   }

   // outer hash marks
   for (let lineCount=0; lineCount<NumHashMarks; lineCount++) {
      let  theta = radians(360.0 * lineCount/NumHashMarks);
      let  r0 = HashLineLo * (Window/2.0);
      let  r1 = HashLineHi * (Window/2.0);
      rBackground.line(Cx+(r0*cos(theta)), Cy+(r0*sin(theta)),
                      Cx+(r1*cos(theta)), Cy+(r1*sin(theta)));
   }
}   

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch22-09-oddsends_radar01.jpg')
}


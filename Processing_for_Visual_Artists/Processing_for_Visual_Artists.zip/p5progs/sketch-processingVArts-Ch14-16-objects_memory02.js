// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: memory02.pde in Ch14
// Chapter: Ch14-16 objects No Figure
// Description: Object program demonstrating the memory management of objects - no display
//

let myApple;

class Apple {    // a minimal Apple class
	constructor() { }
}

function setup() {
	createCanvas(600,400);
	background(200);
	let msg = "See console for results";
	textSize(30);
	text(msg,150,200);
	makeAnApple();
	print("back from setup");
}

function makeAnApple() {
   myApple = new Apple();    // line B
   print("I made an apple");
}




//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch14-16-objects_memory02.jpg')
}


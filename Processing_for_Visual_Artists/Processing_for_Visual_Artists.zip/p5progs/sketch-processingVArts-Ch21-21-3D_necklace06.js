// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: necklace06.pde in Ch21
// Chapter: Ch21-21 3D Figure 21.24
// Description: start of simulated 3D necklace using sphere and rectangles
//

function setup() {
	createCanvas(600, 400, WEBGL);
}

function draw() {
	background(180, 219, 180);
	lights();
	camera();
	//translate(width/2, height/2, 0.0);
	scale(height/2);
	fill(50, 106, 102);
	sphere(0.5);

	fill(226, 125, 156);

	let numBeads = 25;
	for (let i=0; i<numBeads; i++) {
		let a = float(map(i, 0, numBeads-1, 0, 1));
		push();
			rotateY(radians(a * 360));
			translate(0.85, 0, 0);
			drawBead();
		pop();
	}
}


function drawBead() {
	beginShape();
	vertex(-.1, -.2, 0);
	vertex( .1, -.2, 0);
	vertex( .1,  .2, 0);
	vertex(-.1,  .2, 0);
	endShape(CLOSE);
}  

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch21-21-3D_necklace06.jpg')
}


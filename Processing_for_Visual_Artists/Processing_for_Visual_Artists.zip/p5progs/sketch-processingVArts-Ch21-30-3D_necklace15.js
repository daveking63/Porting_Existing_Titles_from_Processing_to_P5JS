// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: necklace15.pde in Ch21
// Chapter: Ch21-30 3D Figure 21.33
// Description: putting texture on a neck
//
let Hike;
function preload(){
	Hike = loadImage("data/myPhoto.jpg");
}

function setup() {
	createCanvas(600, 400, WEBGL);
}

function draw() {
	background(180, 219, 180);
	//lights();
	ambientLight(128, 128, 128);
  	directionalLight(128, 128, 128, 0, 0, -1)
	camera();
	rotateX(radians(-30));
	translate(0, -50, 0.0);
	scale(height/2.5);
	
	fill(50, 106, 102);
	sphere(0.4);

	fill(226, 125, 156);

	let numBeads = 25;
	for (let i=0; i<numBeads; i++) {
		let a = float(map(i, 0, numBeads-1, 0, 1));
		push();
			rotateY(radians(a * 360));
			translate(1.1, 0, 0);
			rotateZ(radians(a*360) + (.02 * frameCount));
			rotateY(.03 * frameCount);
			drawBead();
		pop();
	}
}


function drawBead() {
	beginShape();
	texture(Hike);
	vertex(-.1, -.2, 0, 0, 0);
	vertex( .1, -.2, 0, 600, 0);
	vertex( .1,  .2, 0, 600, 450);
	vertex(-.1,  .2, 0, 0, 450);
	endShape(CLOSE);
}  

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch21-30-3D_necklace15.jpg')
}


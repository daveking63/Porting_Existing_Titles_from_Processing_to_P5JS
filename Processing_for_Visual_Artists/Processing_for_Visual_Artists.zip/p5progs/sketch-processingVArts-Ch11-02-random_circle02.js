// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: circle02.pde in Ch11
// Chapter: Ch11-02 random Figure 11.2
// Description: display circles in random locations
//
function setup() {
	createCanvas(600, 400);
	background(150, 90, 65);
	fill(250, 200, 90);

	let numCircles = 30;
	for (let count=0; count<numCircles; count++) {
		let  xCenter = random(0, width);
		let  yCenter = random(0, height);
		let  radius = random(10, 40);
		ellipse(xCenter, yCenter, radius*2, radius*2);
	} 
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch11-02-random_circle02.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: noise08.pde in Ch11
// Chapter: Ch11-23 random Figure 11.23
// Description: Multiple noise patterns
//
function setup() {
   createCanvas(600, 400);

   let  rx = 0;
   let  ry = 0;
   let  gx = 1000;
   let  gy = 1000;
   let  bx = 5000;
   let  by = 8000;

   let  noiseScale = 0.02;
   for (let y=0; y<height; y++) {
      for (let x=0; x<width; x++) {
         let  redVal = noise((x+rx)*noiseScale, (y+ry)*noiseScale);
         let  grnVal = noise((x+gx)*noiseScale, (y+gy)*noiseScale);
         let  bluVal = noise((x+bx)*noiseScale, (y+by)*noiseScale);

         stroke(255*redVal, 255*grnVal, 255*bluVal);
         point(x, y);
      }
   }
}




//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch11-23-random_noise08.jpg')
}


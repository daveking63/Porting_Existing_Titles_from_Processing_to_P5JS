// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: copy1.pde in Ch16
// Chapter: Ch16-16 images Figure 16.21
// Description: copying rectangles in an image
//

let MyPic;

function preload(){
	MyPic = loadImage("data/myPhoto.jpg");
}
function setup() {
  createCanvas(600, 450); 
  background(0);
}

function draw() {
	let  sulx = random(width);
	let  suly = random(height);
	let  swid = random(width-sulx);
	let  shgt = random(height-suly);
	let  dulx = sulx + random(-30, 30);
	let  duly = suly + random(-30, 30);
	let  dwid = swid + random(-30, 30);
	let  dhgt = shgt + random(-30, 30);

	copy(MyPic, int(sulx), int(suly), int(swid), int(shgt), 
	          int(dulx), int(duly), int(dwid), int(dhgt));
}




//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch16-16-images_copy1.jpg')
}


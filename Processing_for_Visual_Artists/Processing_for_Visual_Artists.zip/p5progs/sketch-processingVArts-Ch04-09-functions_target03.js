// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: target03.pde in Ch04
// Chapter: Ch04-09 functions Figure 4.7
// Description: Multi-circled bulls-eye target
//

let radius, redval, grnval, bluval;

function setup() {
   createCanvas(600, 400);
   background(87, 66, 8);
   noStroke();
   let score = 40;   // the score of this arrow

   // draw the ball for the current value of score
   switch (score) {
      case 40:
         drawBall(160, 212, 20, 20);
      case 30:
         drawBall(80, 231, 48, 3);
      case 20:
         drawBall(40, 255, 93, 8);
      case 10:
         drawBall(20, 255, 140, 5);
         break;
      default:
         drawBall(180, 32, 32, 32);
         break;
   }
}

function drawBall(radius, redval, grnval, bluval) {
   fill(color(redval, grnval, bluval));
   ellipse(300, 200, 2*radius, 2*radius);
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch04-09-functions_target03.jpg')
}


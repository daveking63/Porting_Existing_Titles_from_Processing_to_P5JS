// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: noise09.pde in Ch11
// Chapter: Ch11-24 random Figure 11.24
// Description: Offsetting noise patterns
//
function setup() {
   createCanvas(600, 400);

   let  rx = 0;
   let  ry = 0;
   let  gx = 10;
   let  gy = 10;
   let  bx = 10;
   let  by = 20;

   let  noiseScale = 0.02;
   for (let y=0; y<height; y++) {
      for (let x=0; x<width; x++) {
         let  redVal = noise((x+rx)*noiseScale, (y+ry)*noiseScale);
         let  grnVal = noise((x+gx)*noiseScale, (y+gy)*noiseScale);
         let  bluVal = noise((x+bx)*noiseScale, (y+by)*noiseScale);

         stroke(255*redVal, 255*grnVal, 255*bluVal);
         point(x, y);
      }
   }
}




//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch11-24-random_noise09.jpg')
}


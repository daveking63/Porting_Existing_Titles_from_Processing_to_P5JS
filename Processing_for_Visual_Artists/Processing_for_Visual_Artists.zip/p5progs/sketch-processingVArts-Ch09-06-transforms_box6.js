// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: box6.pde in Ch09
// Chapter: Ch09-06 transforms Figure 9.6
// Description: drawing two rectangles (boxes) represent before and after rotation with grids shown to display the 2 coordinate systems
//
function setup() {
   createCanvas(600, 400);
}

function draw() {
   background(210, 177, 68);
   stroke(0);
   
   fill(149, 93, 13, 128);
   drawBox(150, 100, 250, 150);
   fill(139, 49, 30, 128);
   rotate(radians(20));
   drawBox(150, 100, 250, 150);
}

function drawBox (left, top, wid, hgt) {
  rect(left, top, wid, hgt);
  // draw perfectly vertical lines
  for (let x=0; x<wid; x+=20) {
    line(left+x, top-20, left+x, top+hgt+20);
  }
  // draw perfectly horizontal lines
  for (let y=0; y<hgt; y+=20) {
    line(left-20, top+y, left+wid+20, top+y);
  }
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch09-06-transforms_box6.jpg')
}


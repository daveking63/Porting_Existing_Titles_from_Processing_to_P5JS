// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: smooth03.pde in Ch13
// Chapter: Ch13-11 bcurves Figure 13.12
// Description: Improving the smoothness of two touching Bezier curves
//
function setup() {
   createCanvas(600, 400);
   background(214, 242, 206);
   noFill();
}
function drawCurve(drawCircles, drawLines, p0, p1, p2, p3) {

   // control polet 1
   stroke(255,  0, 0);   // red
   if (drawCircles == true) {
      ellipse(Xp[p0], Yp[p0], 15, 15);
   }
   if (drawLines == true) {
      line(Xp[p0], Yp[p0], Xp[p1], Yp[p1]);
   }

   // control polet 1
   stroke(0, 0, 255);   // blue
   if (drawCircles == true) {
      ellipse(Xp[p3], Yp[p3], 15, 15);
   }
   if (drawLines == true) {
      line(Xp[p3], Yp[p3], Xp[p2], Yp[p2]);
   }

   // the knots
   stroke(0, 0, 0);   // black
   if (drawCircles == true) {
      ellipse(Xp[p1], Yp[p1], 15, 15);
      ellipse(Xp[p2], Yp[p2], 15, 15);
   }

   bezier(Xp[p0], Yp[p0], Xp[p1], Yp[p1], Xp[p2], Yp[p2], Xp[p3], Yp[p3]);
}

//               A0   A1   A2   A3   B0   B1   B2   B3
let Xp = [100, 150, 200, 250, 250, 300, 350, 400];
let Yp = [150, 100, 250, 200, 200, 150, 200, 200];

function draw() {
   noFill();
   drawCurve(true, true, 0, 1, 2, 3);  // curve A
   drawCurve(true, true, 4, 5, 6, 7);  // curve B
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch13-11-bcurves_smooth03.jpg')
}


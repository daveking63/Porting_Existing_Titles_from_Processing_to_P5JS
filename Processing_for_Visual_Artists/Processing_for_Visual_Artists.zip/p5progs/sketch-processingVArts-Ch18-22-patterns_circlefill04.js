// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: circlefill04.pde in Ch18
// Chapter: Ch18-22 patterns Figure 18.62
// Description: faster circle packing based on underlying mask with a black rect and distance from that area
//

let Distance = [];
let maskImage;

function preload(){
	maskImage = loadImage("data/mask0box.png");
}

function setup() {
   createCanvas(600, 600);
   background(0);
   smooth();
   buildDistance();
   showDistance();
   maskImage.updatePixels();
   image(maskImage, 0, 0);
}

function buildDistance() {
	maskImage.loadPixels();
	let pass = [];

	// anything with a black pixel has distance -1, else 0
	for (let y=0; y<height; y++) {
		pass[y] = [];
		for (let x=0; x<width; x++) {
			let indx = (x + y * width) * 4;
			redClr = maskImage.pixels[indx];
			pass[y][x] = -1;
			if (redClr == 0) pass[y][x] = 0;
		}
	}

	// dilate black pixels repeatedly, each newly-dilated
	// pixel has a distance equal to number of steps of dilation
	let dilateAgain = true;
	let passNumber = 1;
	while (dilateAgain) {
		dilateAgain = false;
		for (let y=1; y<height-1; y++) {
			for (let x=1; x<width-1; x++) {
				if (pass[y][x] >= 0) continue;
				if ((pass[y-1][x-1] == passNumber-1) ||
					(pass[y-1][x  ] == passNumber-1) ||
					(pass[y-1][x+1] == passNumber-1) ||
					(pass[y  ][x-1] == passNumber-1) ||
					(pass[y  ][x+1] == passNumber-1) ||
					(pass[y+1][x-1] == passNumber-1) ||
					(pass[y+1][x  ] == passNumber-1) ||
					(pass[y+1][x+1] == passNumber-1)) {
						dilateAgain = true;
						pass[y][x] = passNumber;
				}//if
			}//for
		}//for
		passNumber++;
	}//while

	// copy the temporary mask into the Distance array
	for (let y=0; y<height; y++) {
	Distance[y] = [];
		for (let x=0; x<width; x++) {
			Distance[y][x] = pass[y][x];
		}
	}
}//build

function showDistance() {
	let  minD = Distance[0][0];
	let  maxD = Distance[0][0];
	for (let y=0; y<height; y++) {
		for (let x=0; x<width; x++) {
			 minD = min(Distance[y][x], minD);
			 maxD = max(Distance[y][x], maxD);
		}
	}
	print("show: minD="+minD+"  maxD="+maxD);
	for (let y=0; y<height; y++) {
		for (let x=0; x<width; x++) {
			let indx = (x + y * width) * 4;
			let  mapD = float(map(Distance[y][x], minD, maxD, 0, 255));
			//maskImage.set(x, y, color(mapD, mapD, 0));
			let maskColor = color(mapD, mapD, 0, 0);
			maskImage.pixels[indx] = red(maskColor);
			maskImage.pixels[indx+1] = green(maskColor);
			maskImage.pixels[indx+2] = 0;
			maskImage.pixels[indx+3] = 255;
		}
	}
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch18-22-patterns_circlefill04.jpg')
}


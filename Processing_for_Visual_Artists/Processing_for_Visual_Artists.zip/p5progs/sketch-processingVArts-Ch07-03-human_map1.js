// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: map1.pde in Ch07
// Chapter: Ch07-03 human Figure 7.4
// Description: mapping from one number range to another
//
function setup() {
   createCanvas(200,200);
   let r1 = 10.0;
   let r2 = 20.0;
   let s1 = 30.0;
   let s2 = 40.0;
   let a = 12.0;
   showmap(a, r1, r2, s1, s2);
   showmap(a, r2, r1, s1, s2);
   showmap(a, r1, r2, s2, s1);
   showmap(a, r2, r1, s2, s1);
   
   background(200);
   textSize(15);
   text('See console for output',20,100);
}

function showmap(a, rlo, rhi, slo, shi)
{
   print("map "+a+" from ("+rlo+", "+rhi+") to ("+slo+", "+shi+") = "+map(a,rlo,rhi,slo,shi));
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch07-03-human_map1.jpg')
}


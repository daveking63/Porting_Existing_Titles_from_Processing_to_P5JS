// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011

// PDE Source: river1.pde in Ch04
// Chapter: Ch04-01 functions Figure 4.1
// Description: River created by noise


let  NoiseScale = 0.005;
let  NoiseOffsetX = 0.0;
let  NoiseOffsetY = 0.0;

function setup() {
   createCanvas(800, 600);
   background(255);
   smooth();
   noFill();
   stroke(0, 0, 0, 32);
   for (let i=0; i<300; i++) {
      NoiseOffsetX += 5.0;
      NoiseOffsetY += 7.1;
      drawOneStream();
   }
}

function drawOneStream() {
   let  px = 0.0;
   let  py = height/2.0;
   let  vx = 1.0;
   let  vy = 0.0;
   let pcnt = 0.0;
   while ((px>=0.0) && (px<width) && (py<height) && (py>=0.0)) {
      point(px, py);
      let  xNoise = noise((pcnt+NoiseOffsetX) * NoiseScale);
      let  yNoise = noise((pcnt+NoiseOffsetY) * NoiseScale);
      vx = ((2.0*vx) + 1 + map(xNoise, 0, 1, -1, 1))/4.0;
      vy = ((3.0*vy) + map(yNoise, 0, 1, -1, 1))/4.0;
      px += vx;
      py += vy;
      pcnt++;
   }
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch04-01-functions_river1.jpg')
}


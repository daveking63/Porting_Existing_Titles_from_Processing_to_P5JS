// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: spinner2.pde in Ch03
// Chapter: Ch03-02 variables Figure 3.5
// Description: spinning ellipse

function setup() {
	createCanvas(600, 600);
	background(0);
	smooth();
	translate(300, 300);
	for (let i=0; i<360; i += 0.5) {  // bump by .5 for ellipses, 1 for others
		push();
			rotate(radians(i));
			translate(0, 200);
			rotate(radians(i*3));
			scale(map(sin(radians(i*6)), -1, 1, .5, 1), map(sin(radians(i*3)), -1, 1, .5, 1));
			drawEllipse();
		pop();
	}
}

function drawRect() {
	noFill();
	stroke(255, 255, 255, 128);
	rect(-60, -40, 120, 80);
}  

function drawEllipse() {
	noFill();
	stroke(255, 255, 255, 128);
	ellipse(0, 0, 120, 80);
}

function drawStar() {
	let r1 = 40.0;
	let r2 = 120.0;
	let numPoints = 3;
	let dTheta = radians(360)/(numPoints * 2.0);
	for (let i=0; i<numPoints; i++) {
		let x0 = r1 * cos((2*i)*dTheta);
		let y0 = r1 * sin((2*i)*dTheta);
		let x1 = r2 * cos(((2*i)+1) * dTheta);
		let y1 = r2 * sin(((2*i)+1) * dTheta);
		let x2 = r1 * cos(((2*i)+2) * dTheta);
		let y2 = r1 * sin(((2*i)+2) * dTheta);
		noFill();
		stroke(255, 255, 255, 128);
		line(x0, y0, x1, y1);
		line(x1, y1, x2, y2);
	}		
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch03-02-variables_spinner2.jpg')
}


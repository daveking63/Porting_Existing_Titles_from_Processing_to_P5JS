// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: creepers01.pde in Ch23
// Chapter: Ch23-06 projects Figure 23.11
// Description: similar to streamsrunning down hill this is grass creeping along the ground
//

let LayerGroundMask;
let LayerGroundPicture;
let LayerGrass;
let LayerGrassShadow;

class Blade {
   // Blade grows from seed to tip.  pA and pB are along the way.
    // c1 and c2 are perpendiculars at pA and pB.  A and B values
   // are points above and below seed, c1, and c2 for blade thickness.
   //
   //                                 c2A
   //                   c1A      *****(c2)**
   //                 **(c1)*****     c2B   **
   //               **  c1B            |      **
   //      sA     **     |             |        **
   //    (seed)***------(pA)----------(pB)--------***(tip)
   //      sB
   //

	constructor(){
		this.seedA, this.seedB;
		this.c1, this.c1A, this.c1B;
		this.c2, this.c2A, this.c2B;
		this.r0, this.r1, this.r2;
		this.color0 = color(109, 204,  55, 192);  // greenish
		this.color1  = color(  9, 178, 150, 192); // blueish
		this.clr = lerpColor(this.color0, this.color1, random(0, 1));
		this.seed = createVector(0, 0);
		this.tip = createVector(0, 0);
	}

	plantSeed(mask) {
		let foundSeed = false;
		while (!foundSeed) {
			this.seed.x = random(0, width);
			this.seed.y = random(0, height);
			let maskx = round(this.seed.x);
			let masky = round(this.seed.y);
			let rval = red(mask.get(maskx, masky));
			if (rval < 1) foundSeed = true;
		}
	}

	buildBlade(layer) {
		let minLength = layer.width/20;
		let maxLength = layer.width/5;
		let bladeLength = lerp(minLength, maxLength, pow(random(0,1), 3));

		let bladeAngle = random(0, TWO_PI);
		this.tip = createVector(this.seed.x + (bladeLength * cos(bladeAngle)),
		                  this.seed.y + (bladeLength * sin(bladeAngle)));

		let aPercent = random(0.2, 0.4);
		let bPercent = random(0.6, 0.8);
		let pA = createVector(lerp(this.seed.x, this.tip.x, aPercent), lerp(this.seed.y, this.tip.y, aPercent));
		let pB = createVector(lerp(this.seed.x, this.tip.x, bPercent), lerp(this.seed.y, this.tip.y, bPercent));

		let tipMinusSeed = createVector(this.tip.x-this.seed.x, this.tip.y-this.seed.y);
		let perp = createVector(-tipMinusSeed.y, tipMinusSeed.x); // counter-clockwise
		perp.normalize();

		let c1sign = 1;
		if (random(1000) > 500) c1sign = -1;
		let c2sign = 1;
		if (random(1000) > 500) c2sign = -1;

		this.c1 = createVector(pA.x + (c1sign*((aPercent*bladeLength)*perp.x)), 
		            pA.y + (c1sign*((aPercent*bladeLength)*perp.y)));
		this.c2 = createVector(pB.x - (c2sign*(((1-bPercent)*bladeLength)*perp.x)), 
		                   pB.y - (c2sign*(((1-bPercent)*bladeLength)*perp.y)));


		this.r0 = bladeLength * random(.01, .04);
		this.r1 = this.r0 * random(.5, .75);
		this.r2 = this.r1 * random(.5, .75);

		let c1MinusSeed = createVector(this.c1.x-this.seed.x, this.c1.y-this.seed.y);
		let c1MSperp = createVector(-c1MinusSeed.y, c1MinusSeed.x);
		c1MSperp.normalize();
		this.seedA = createVector(this.seed.x+(this.r0*c1MSperp.x), this.seed.y+(this.r0*c1MSperp.y));
		this.seedB = createVector(this.seed.x-(this.r0*c1MSperp.x), this.seed.y-(this.r0*c1MSperp.y));
		this.c1A = createVector(this.c1.x+(this.r1*c1MSperp.x), this.c1.y+(this.r1*c1MSperp.y));
		this.c1B = createVector(this.c1.x-(this.r1*c1MSperp.x), this.c1.y-(this.r1*c1MSperp.y));

		let tipMinusC2 = createVector(this.tip.x-this.c2.x, this.tip.y-this.c2.y);
		let tMC2perp = createVector(-tipMinusC2.y, tipMinusC2.x);
		tMC2perp.normalize();
		this.c2A = createVector(this.c2.x+(this.r2*tMC2perp.x), this.c2.y+(this.r2*tMC2perp.y));
		this.c2B = createVector(this.c2.x-(this.r2*tMC2perp.x), this.c2.y-(this.r2*tMC2perp.y));
	}
   
	renderVein(layer) {
		//layer.beginDraw();
		layer.noFill();
		layer.stroke(this.clr);
		layer.bezier(this.seed.x, this.seed.y, this.c1.x, this.c1.y, this.c2.x, this.c2.y, this.tip.x, this.tip.y);
		//layer.endDraw();
	}

	renderBlade(layer) {
		//layer.smooth();
		//layer.beginDraw();

		layer.noFill();
		layer.stroke(0, 16);
		layer.strokeWeight(5);
		this.drawCurves(layer);

		layer.noStroke();
		layer.fill(this.clr);
		this.drawCurves(layer);
		layer.ellipse(this.seed.x, this.seed.y, this.r0, this.r0);

		//layer.endDraw();
	}

	drawCurves(layer) {
		layer.beginShape();
		layer.vertex(this.seedA.x, this.seedA.y);
		layer.bezierVertex(this.c1A.x, this.c1A.y, this.c2A.x, this.c2A.y, this.tip.x, this.tip.y);
		layer.bezierVertex(this.c2B.x, this.c2B.y, this.c1B.x, this.c1B.y, this.seedB.x, this.seedB.y);
		layer.endShape(CLOSE);
	}
}
let concreteImage;

function preload(){
   concreteImage = loadImage("data/ground600.png");
}

function setup() {
	createCanvas(600, 600);
	smooth();
	background(69, 51, 40);

	LayerGroundMask    = createGraphics(width, height);
	LayerGroundPicture = createGraphics(width, height);
	LayerGrass         = createGraphics(width, height);
	LayerGrassShadow   = createGraphics(width, height);

	buildGround();
	growGrass();
	makeGrassShadow();

	image(LayerGroundPicture, 0, 0);
	image(LayerGrassShadow, 0, 0);
	image(LayerGrass, 0, 0);
}

function buildGround() {
	LayerGroundMask.loadPixels();
	//LayerGroundMask.beginDraw();
	LayerGroundMask.background(255);
	for (let y=0; y<LayerGroundMask.height; y++) {
		for (let x=0; x<LayerGroundMask.width; x++) {
			if (noise(x*.02, y*.02) > 0.7) LayerGroundMask.set(x, y, color(0));
		}
	}
	//LayerGroundMask.endDraw();

	let c0 = color(65, 65, 65);
	let c1 = color(128, 128, 128);

	LayerGroundPicture.loadPixels();
	//LayerGroundPicture.beginDraw();
	for (let y=0; y<LayerGroundPicture.height; y++) {
		for (let x=0; x<LayerGroundPicture.height; x++) {
			let opacity = (red(LayerGroundMask.get(x,y)) == 0) ? 0 : 255;
			let a = noise(x*.02, y*.02);
			let clr = color(
			lerp(red(c0), red(c1), a), 
			lerp(green(c0), green(c1), a), 
			lerp(blue(c0), blue(c1), a), 
			opacity);

			let concreteColor = concreteImage.get(x,y);
			let ablend = 0.20;
			let cnew = color(red(concreteColor), green(concreteColor), blue(concreteColor), opacity);
			let blendColor = lerpColor(clr, cnew, ablend);

			LayerGroundPicture.set(x, y, blendColor);
		}
	}
   //LayerGroundPicture.endDraw();
   LayerGroundMask.updatePixels();
   LayerGroundPicture.updatePixels();
}


function growGrass() {
	LayerGrass.background(0, 0);
	for (let g=0; g<1000; g++) {
		let blade = new Blade();
		blade.plantSeed(LayerGroundMask);
		blade.buildBlade(LayerGrass);
		blade.renderBlade(LayerGrass);
	}
}

function makeGrassShadow() {
	let blurLayerSrc = [];
	let blurLayerDst = [];
	for (let y=0; y<height; y++) {
		blurLayerSrc[y] = [];
		for (let x=0; x<width; x++) {
			blurLayerSrc[y][x] = 0;
			let clr = LayerGrass.get(x,y);
			if (alpha(clr) > 0) blurLayerSrc[y][x] = 1;
		}
	}

	let numPasses = 3;
	let blurRadius = 8;
	for (let pass=0; pass<numPasses; pass++) {
		// blur src into dst
		for (let y=0; y<height; y++) {
			blurLayerDst[y] = [];
			for (let x=0; x<width; x++) {
				let numAdded = 0;
				let blurSum = 0;
				let ixlo = max(0, x-blurRadius);
				let ixhi = min(width, x+blurRadius);
				let iylo = max(0, y-blurRadius);
				let iyhi = min(height, y+blurRadius);
				for (let iy=iylo; iy<iyhi; iy++) {
						for (let ix=ixlo; ix<ixhi; ix++) {
						numAdded++;
						blurSum += blurLayerSrc[iy][ix];
					}
				}
				if (numAdded == 0) numAdded = 1;
				blurLayerDst[y][x] = blurSum/numAdded;
			}
		}

		// copy dst into src
		for (let y=0; y<height; y++) {
			for (let x=0; x<width; x++) {
				blurLayerSrc[y][x] = blurLayerDst[y][x];
			}
		}
	}

	// copy src into the layer
	//LayerGrassShadow.beginDraw();
	for (let y=0; y<height; y++) {
		for (let x=0; x<width; x++) {
			let opacity = 96 * blurLayerSrc[y][x];
			LayerGrassShadow.set(x, y, color(0, 0, 0, opacity));
		}
	}
   //LayerGrassShadow.endDraw();
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch23-06-projects_creepers01.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: cmcurves4.pde in Ch12
// Chapter: Ch12-04 cmcurves Figure 12.6
// Description: A Catmull-Rom curve with supporting graphics
//
function setup() {
   createCanvas(600, 400);
   background(242, 240, 174);
   noFill();
}

let Xp = [100, 300, 300, 100];
let Yp = [100, 100, 300, 300];

function draw() {
   stroke(255, 0, 0);   // red
   ellipse(Xp[0], Yp[0], 15, 15);
   line(Xp[0], Yp[0], Xp[1], Yp[1]);
  
   stroke(0, 0, 255);   // blue
   ellipse(Xp[3], Yp[3], 15, 15);
   line(Xp[3], Yp[3], Xp[2], Yp[2]);

   stroke(0, 0, 0);   // black
   ellipse(Xp[1], Yp[1], 15, 15);
   ellipse(Xp[2], Yp[2], 15, 15);

   curve(Xp[0], Yp[0], Xp[1], Yp[1], Xp[2], Yp[2], Xp[3], Yp[3]);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch12-04-cmcurves_cmcurves4.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: circlefill03.pde in Ch18
// Chapter: Ch18-21 patterns Figure 18.61
// Description: circle packing based on underlying mask with a black rect and distance from that area
//
let Distance = [];
let maskImage;

function preload(){
	maskImage = loadImage("data/mask001.png");
}

function setup() {
	createCanvas(300,300);
	pixelDensity(1);
	background(255);
	smooth();
	maskImage.loadPixels();
	buildDistance();
	showDistance();
	maskImage.updatePixels();
	image(maskImage,0,0);
}

function buildDistance() {
	image(maskImage,0,0);
	let clr;
	for (let dy = 0; dy < height; dy++) {
		Distance[dy] = [];
		for (let dx = 0; dx < width; dx++) {
			let indx = (dx + dy * width) * 4;
			redClr = maskImage.pixels[indx];
			if (redClr == 0) {
				Distance[dy][dx] = float(0.0);
			} else {
				Distance[dy][dx] = float(width*height);
				for (let py = 0; py < height; py++) {
					for (let px = 0; px < width; px++) {
						let indx2 = (px + py * width) * 4;
						redClr2 = maskImage.pixels[indx2];
						if (redClr2 == 0) {
							let  d = float(dist(px, py, dx, dy));
							Distance[dy][dx] = float(min(d, Distance[dy][dx]));
						}
					}
				}
			}
		}
	}
}

function showDistance() {
	let  minD = float(Distance[0][0]);
	let  maxD = float(Distance[0][0]);
	for (let y=0; y<height; y++) {
		for (let x=0; x<width; x++) {
			minD = float(min(Distance[y][x], minD));
			maxD = float(max(Distance[y][x], maxD));
		}
	}
	for (let y=0; y<height; y++) {
		for (let x=0; x<width; x++) {
			let indx = (x + y * width) * 4;
			let  mapD = float(map(Distance[y][x], minD, maxD, 0, 255));
			//maskImage.set(x, y, color(mapD, mapD, 0));
			let maskColor = color(mapD, mapD, 0, 0);
			maskImage.pixels[indx] = red(maskColor);
			maskImage.pixels[indx+1] = green(maskColor);
			maskImage.pixels[indx+2] = 0;
			maskImage.pixels[indx+3] = 255;
		}
	}
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch18-21-patterns_circlefill03.jpg')
}


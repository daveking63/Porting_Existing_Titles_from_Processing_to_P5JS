// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: xheight04.pde in Ch22
// Chapter: Ch22-08 oddsends Figure 22.13
// Description: final attempt to  draw strips to reflect the heights of various components of a font including base-textAscent-textDescent
//
// This approach differs somewhat from the tact used in the book
// Although the basic idea is the same.

// Different for different fonts
let myFont;
let fSize = 64;

let edgeAdjust = 20;
let scalar = 0.65; // Different for each font

function preload(){
	myFont = loadFont("data/PlayfairDisplay-Bold.ttf");
}

function setup(){
 
	createCanvas(600,400);
	background(240, 215, 175); 
	rectMode(CORNERS);
	textFont(myFont);

	let base = height*0.5; 
	let msg = "raspberry!";
	let tSize = textSize(fSize);
	let tWidth = textWidth(msg);
	let xStrt = (width - tWidth)/2;
	let xEnd = (width + tWidth)/2;

	let desc = textDescent() * scalar;
	let aesc = textAscent() * scalar;

	//top rectangle
	fill(189, 176, 130);
	rect(xStrt, base-0.75*aesc ,xEnd, base-1.1*aesc);
	//center rectangle
	fill(126, 189, 152);
	rect(xStrt-edgeAdjust,base,xEnd+edgeAdjust,base-0.75*aesc);
	//bottom rectangle
	fill(145, 185, 189);
	rect(xStrt-2*edgeAdjust,base+desc,xEnd+2*edgeAdjust,base);

	fill(145, 44, 66);
	text(msg, xStrt, base);
}
/* -- inactive
function getXHeight(myFont) {  
   let hwid = int(textWidth("x"));
   let hhgt = int(textAscent());
  
   let pg = createGraphics(hwid, hhgt);
   
   pg.background(0);
   pg.fill(255);
   pg.textFont(myFont);
   pg.textSize(fSize);
   pg.text("x", 0, hhgt);
   
   let ytop = 0;
   // scan down from top
   for (ytop=0; ytop<hhgt; ytop++) {
     for (let x=0; x<width; x++) {
       let c = pg.get(x, ytop);
       if (red(c) != 0) {
         let xHeight = 1 + hhgt - ytop;
         return(xHeight);
       }
     }
   }
   return(hhgt);
}
*/
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch22-08-oddsends_xheight04.jpg')
}


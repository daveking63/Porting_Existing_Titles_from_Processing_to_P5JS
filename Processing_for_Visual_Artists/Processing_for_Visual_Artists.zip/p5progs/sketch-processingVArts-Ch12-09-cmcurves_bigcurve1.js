// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: bigcurve1.pde in Ch12
// Chapter: Ch12-09 cmcurves Figure 12.12
// Description: Starting canvas for new curve project - selected curve points
//
let NumPoints = 6;
let Xp = [];
let Yp = [];

function setup() {
   createCanvas(600, 400);
   background(194, 216, 242);
   noFill();
   for (let i=0; i<NumPoints; i++) {
      Xp[i] = random(100, 500);
      Yp[i] = random(100, 300);
   }
}

function draw() {
   for (let i=0; i<NumPoints; i++) {
      ellipse(Xp[i], Yp[i], 10, 10);
   }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch12-09-cmcurves_bigcurve1.jpg')
}


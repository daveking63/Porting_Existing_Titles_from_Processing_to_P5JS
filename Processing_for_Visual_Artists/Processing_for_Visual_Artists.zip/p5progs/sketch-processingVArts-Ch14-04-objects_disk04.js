// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: disk04.pde in Ch14
// Chapter: Ch14-04 objects Figure 14.1
// Description: IObject program with two 'ghost disks' with multiple attributes and displayed on screen
//
let Ghost0, Ghost1;

function setup() {
   createCanvas(600, 400);
   background(164, 164, 164);
   Ghost0 = new Disk(100, 100,  5,  5, 20, color(242, 203, 5));
   Ghost1 = new Disk(400, 200, -3, -7, 30, color(209, 117, 4));
}

function draw() {
   fill(Ghost0.clr);
   ellipse(Ghost0.xPos, Ghost0.yPos, Ghost0.radius*2, Ghost0.radius*2);
   fill(Ghost1.clr);
   ellipse(Ghost1.xPos, Ghost1.yPos, Ghost1.radius*2, Ghost1.radius*2);
}

class Disk {
	constructor(aXPos, aYPos, aXDir, aYDir, aRadius, aClr){
		this.xPos = aXPos;   // 1. Current location (X and Y)
		this.yPos = aYPos;
		this.xDir = aXDir;   // 2. Current motion (X and Y)
		this.yDir = aYDir;
		this.radius = aRadius; // 3. Radius
		this.clr = aClr;    // 4. Color
	}// constructor
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch14-04-objects_disk04.jpg')
}


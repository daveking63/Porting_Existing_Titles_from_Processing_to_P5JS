// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: cmcurves2.pde in Ch12
// Chapter: Ch12-02 cmcurves Figure 12.3
// Description: New curve skeleton
//
function setup() {
   createCanvas(600, 400);
   background(242, 240, 174);
   noFill();
} 

let Xp = [100, 300, 300, 100];
let Yp = [100, 100, 300, 300];

function draw() {
   for (let i=0; i<4; i++) {
      ellipse(Xp[i], Yp[i], 15, 15);
   }
   // draw curves here
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch12-02-cmcurves_cmcurves2.jpg')
}


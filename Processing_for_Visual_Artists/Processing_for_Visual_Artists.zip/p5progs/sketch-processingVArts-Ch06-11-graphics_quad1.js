// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: quad1.pde in Ch06
// Chapter: Ch06-11 graphics Figure 6.18
// Description: display a quad
//
function setup() { 
   createCanvas(600, 400);
   background(163, 143, 109);
}  

function draw() {
   quad(40, 60, 550, 250, 400, 350, 150, 300);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch06-11-graphics_quad1.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: box3.pde in Ch09
// Chapter: Ch09-03 transforms Figure 9.3
// Description: drawing two rectangles (boxes) representing before and after rotation of 20 degrees
//
function setup() {
   createCanvas(600, 400);
}

function draw() {
   background(210, 177, 68);
   fill(149, 93, 13, 128);
   rect(150, 100, 250, 150);    
   fill(139, 49, 30, 128);
   rotate(radians(20));
   rect(150, 100, 250, 150);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch09-03-transforms_box3.jpg')
}


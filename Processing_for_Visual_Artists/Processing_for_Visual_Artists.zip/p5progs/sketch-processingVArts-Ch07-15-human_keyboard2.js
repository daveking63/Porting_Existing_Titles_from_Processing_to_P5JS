// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: keyboard2.pde in Ch07
// Chapter: Ch07-15 human No Figure
// Description: printing out key that is pressed with KeyPressed and keyCode
//
function setup() {
	createCanvas(600,400);
	background(200);
}

function draw() {
   textSize(15);
   text('Press any Key',250,200);
   text('see Console', 250,220);
}

function keyPressed() {
  print("key="+key+" keyCode="+keyCode);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch07-15-human_keyboard2.jpg')
}


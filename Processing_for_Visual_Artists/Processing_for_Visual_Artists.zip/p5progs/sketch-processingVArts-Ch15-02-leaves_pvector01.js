// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: pvector01.pde in Ch15
// Chapter: Ch15-02 leaves No Figure
// Description: calculating distance from p5.Vectors
//
function setup() {
	
	createCanvas(400, 400);
	background(200, 190, 143);
	textSize(30);
	text("See console for results",50,200);
	let A = createVector(10, 20);
	let Acopy = A.copy();
	let B = createVector(40, 80);
	let BminusA = B.copy();
	BminusA.sub(A);
	BminusA.normalize();
	BminusA.mult(3);
	A.add(BminusA);
	print("new A: ("+A.x+", "+A.y+")");
	print("distance from A to original A: "+A.dist(Acopy));
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch15-02-leaves_pvector01.jpg')
}


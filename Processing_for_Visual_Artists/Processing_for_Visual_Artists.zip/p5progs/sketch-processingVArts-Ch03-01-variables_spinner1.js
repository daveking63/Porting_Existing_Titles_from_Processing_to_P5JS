// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011

// PDE Source: spinner1.pde in Ch03
// Chapter: Ch03-00 variables Figure 3.1
// Description: spinning rectangle

function setup() {
  createCanvas(1000, 400);
  background(255);
  smooth();
}

function draw() {
	translate(frameCount*2, 200);
	rotate(radians(frameCount*3));
	let sclSize = sin(radians(frameCount * 3.5));
	scale(map(sclSize, -1, 1, .5, 1));
	drawFigure();
}

function drawFigure() {
	noFill();
	stroke(0, 0, 0, 128);
	rect(-60, -40, 120, 80);
}  

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch03-01-variables_spinner1.jpg')
}


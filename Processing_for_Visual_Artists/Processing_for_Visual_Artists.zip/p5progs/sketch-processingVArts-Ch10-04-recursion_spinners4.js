// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: spinners4.pde in Ch10
// Chapter: Ch10-04 recursion Figure 10.6
// Description: recursively drawn concentric circles of different colors
//
let  MaxDepth = 4;

function setup() {
   createCanvas(500, 500);
   noStroke();
}

function draw() {
   background(119, 112, 127);
   translate(250, 250);
   scale(240.0);
   drawCircles(1);
}

function drawCircles(depth) {
        if (depth == 1) fill(color(89, 9, 21));
   else if (depth == 2) fill(color(148, 14, 35));
   else if (depth == 3) fill(color(181, 86, 70));
   else if (depth == 4) fill(color(199, 172, 115));
   else return;   

   ellipse(0, 0, 2, 2);
   scale(0.75);
   drawCircles(depth+1);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch10-04-recursion_spinners4.jpg')
}


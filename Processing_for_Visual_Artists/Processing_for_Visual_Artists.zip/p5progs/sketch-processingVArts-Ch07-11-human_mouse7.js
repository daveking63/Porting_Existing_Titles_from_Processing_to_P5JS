// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: mouse7.pde in Ch07
// Chapter: Ch07-11 human No Figure
// Description: setting background red & green components with mouseY and blue with mouseX-mouseDragged-mouseClicked
//
let Redval = 192; // background red
let Grnval = 64;  // background green
let Bluval = 0;   // background blue
let  MyColor;

function setup() {
   createCanvas(600, 400);
   MyColor = color(Redval, Grnval, Bluval);
   background(MyColor);
}

function draw() {
   background(MyColor);
   textSize(15);
   text('Move mouse',250,200);
}

function mouseMoved() {
   Redval = map(mouseX, 0, 599, 0, 255);
   Grnval = map(mouseY, 0, 399, 0, 255);
   MyColor = color(Redval, Grnval, Bluval);
}

function mouseDragged() {
   updateBlueValue();
}

function mouseClicked() {
   updateBlueValue();
}

function updateBlueValue() {
   Bluval = map(mouseX, 0, 599, 0, 255);
   MyColor = color(Redval, Grnval, Bluval);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch07-11-human_mouse7.jpg')
}


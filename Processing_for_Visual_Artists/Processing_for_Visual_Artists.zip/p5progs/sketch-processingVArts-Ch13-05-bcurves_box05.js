// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: box05.pde in Ch13
// Chapter: Ch13-05 bcurves Figure 13.5
// Description: Moving Bezier control point far away
//
function setup() {
   createCanvas(600, 400);
   background(242, 207, 194);
   noFill();
}

function drawCurve(drawCircles, drawLines, p0, p1, p2, p3) {

   // control polet 1
   stroke(255,  0, 0);   // red
   if (drawCircles == true) {
      ellipse(Xp[p0], Yp[p0], 15, 15);
   }
   if (drawLines == true) {
      line(Xp[p0], Yp[p0], Xp[p1], Yp[p1]);
   }

   // control polet 1
   stroke(0, 0, 255);   // blue
   if (drawCircles == true) {
      ellipse(Xp[p3], Yp[p3], 15, 15);
   }
   if (drawLines == true) {
      line(Xp[p3], Yp[p3], Xp[p2], Yp[p2]);
   }

   // the knots
   stroke(0, 0, 0);   // black
   if (drawCircles == true) {
      ellipse(Xp[p1], Yp[p1], 15, 15);
      ellipse(Xp[p2], Yp[p2], 15, 15);
   }

   bezier(Xp[p0], Yp[p0], Xp[p1], Yp[p1], Xp[p2], Yp[p2], Xp[p3], Yp[p3]);
}

let Xp = [100, 590, 300, 100];
let Yp = [100,  50, 330, 300];

function draw() {
   drawCurve(true,  true, 0, 1, 2, 3);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch13-05-bcurves_box05.jpg')
}


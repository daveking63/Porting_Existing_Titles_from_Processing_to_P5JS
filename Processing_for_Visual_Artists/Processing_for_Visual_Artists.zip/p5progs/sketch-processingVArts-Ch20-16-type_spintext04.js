// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: spintext04.pde in Ch20
// Chapter: Ch20-16 type Figure 20.18
// Description: displaying type in a circle
//

let myFont;
function preload(){
	myFont = loadFont("data/AvenirNextLTPro-Demi.otf"); 
}

function setup() 
{
	createCanvas(600, 400);
	textFont(myFont);
	textSize(36);
}

function draw() {
	fill(199, 172, 115);
	background(89, 9, 21);
	let message = "Pomegranate and lime juice";
	let  radius = 150;
	let numChars = message.length;
	for (let i=0; i<numChars; i++) {
		let thisChar = message.charAt(i);
		let  theta = map(i, 0, numChars, radians(0), radians(360));
		let  xpos = 300 + (radius * cos(theta));
		let  ypos = 200 - (radius * sin(theta));
		text(thisChar, xpos, ypos);
	}
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch20-16-type_spintext04.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: arc4.pde in Ch06
// Chapter: Ch06-09 graphics Figure 6.16
// Description: Display nearly full ellipse
//
function setup() { 
   createCanvas(600, 400);
   background(163, 143, 109);
}  

function draw() {
   arc(300, 180, 450, 250, radians(30), radians(305));
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch06-09-graphics_arc4.jpg')
}


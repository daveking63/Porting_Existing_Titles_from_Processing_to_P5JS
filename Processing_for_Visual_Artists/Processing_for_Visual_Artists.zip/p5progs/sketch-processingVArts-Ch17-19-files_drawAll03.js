// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: drawAll03.pde in Ch17
// Chapter: Ch17-19 files Figure 17.18
// Description: Display of whole figure of primitive 'oddman' reading points from external file and using begin and end shape with in correct dimensions
//
let lines = [];
let linesToDraw = [];

function preload(){
	for (let i = 0; i < 6; i++){
		lines[i] = [];
	}
	lines[0] = loadStrings("data/Body-ManPoints2.txt");
	lines[1] = loadStrings("data/BellyHole-ManPoints2.txt");
	lines[2] = loadStrings("data/EyeHole-ManPoints2.txt");
	lines[3] = loadStrings("data/FootHole-ManPoints2.txt");
	lines[4] = loadStrings("data/UpCircleHole-ManPoints2.txt");
	lines[5] = loadStrings("data/UpperHole-ManPoints2.txt");	
}

function setup() {
	createCanvas(315, 800);
	background(214, 192, 178);
	noStroke();
	smooth();
	let black = color(0, 0, 0);
	let white = color(255, 255, 255);
	for (i = 0; i < 6; i++){
		linesToDraw = lines[i];
		if (i == 0) {drawShape(black);}
		else {drawShape(white);}
	}
}

function drawShape(clr) {
   fill(clr);
   beginShape();
   for (let i=0; i<linesToDraw.length; i++) {
      let vals = split(linesToDraw[i], '\t');
      let x = int(vals[0])/2.0;
      let y = int(vals[1])/2.0;
      print(x,y);
      vertex(y, x);
   }
   endShape();
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch17-19-files_drawAll03.jpg')
}


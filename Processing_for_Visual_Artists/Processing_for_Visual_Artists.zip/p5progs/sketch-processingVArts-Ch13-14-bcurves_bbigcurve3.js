// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: bbigcurve3.pde in Ch13
// Chapter: Ch13-14 bcurves Figure 13.15
// Description: Connecting multiple Bezier curves into one curve
//
let NumPoints = 24;
let Xp = [];
let Yp = [];

function setup() {
   createCanvas(600, 400);
   background(206, 214, 242);
   noFill();
   for (let i=0; i<NumPoints; i++) {
      Xp[i] = random(100, 500);
      Yp[i] = random(100, 300);
   }
}

function draw() {
   for (let i=0; i<NumPoints; i+=4) {
      ellipse(Xp[i], Yp[i], 10, 10);
   }
   for (let i=0; i<NumPoints; i+=4) {
      bezier(Xp[i],   Yp[i],   Xp[i+1], Yp[i+1],
             Xp[i+2], Yp[i+2], Xp[i+3], Yp[i+3]);
   }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch13-11-bcurves_bigcurve3.jpg')
}


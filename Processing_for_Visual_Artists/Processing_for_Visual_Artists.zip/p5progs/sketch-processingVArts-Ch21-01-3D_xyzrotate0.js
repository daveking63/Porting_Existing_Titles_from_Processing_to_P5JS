// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: xyzrotate0.pde in Ch21
// Chapter: Ch21-01 3D Figure 21.3
// Description: colored boxes in default 3D view
//
function setup() {
  createCanvas(600, 600, WEBGL);
  //translate(300, 300, 0);
  translate(0,0,0);
  background(191, 223, 227);
  fill(128, 128, 128); makeBox(0, 0, 0);    // gray box at origin 
  fill(209,  98, 133); makeBox(150, 0, 0);  // red box on +X axis
  fill(153, 229, 149); makeBox(0, 150, 0);  // green box on +Y axis
  fill( 45, 111, 173); makeBox(0, 0, 150);  // blue box on +Z axis
}

function makeBox(tx, ty, tz) {
  push();
	  translate(tx, ty, tz);
	  box(100);
  pop();
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch21-01-3D_xyzrotate0.jpg')
}


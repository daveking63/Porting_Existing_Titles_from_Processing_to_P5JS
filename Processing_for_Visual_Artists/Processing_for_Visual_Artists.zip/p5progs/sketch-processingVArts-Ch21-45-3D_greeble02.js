// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: greeble02.pde in Ch21
// Chapter: Ch21-45 3D Figure 21.54
// Description: greeble 3D grid
//

let Window = 600;
let GridX = 13;
let GridZ = 10;

function setup(){
   createCanvas(600, 600, WEBGL);
   //translate(-300, -300, 0);
   smooth();
}

function  draw() {
   background(25, 42, 51);
   translate(-50, -50, -400.0);
   scale(600, -600, 600);
   lights();

   noStroke();
   fill(255);
   rotateX(radians(35));
   let gScale = 0.5;
   scale(gScale);

   for (let iz=0; iz<GridZ; iz++) {
      for (let ix=0; ix<GridX; ix++) {
         push();
         translate(ix-(GridX/2.0), 0, iz-(GridZ/2.0));
         drawGreeble00(); 
         pop();
      }
   }

   drawGreeble00(); 
}

function  drawGreeble00() {
   drawBox(.5, -.1, .5, 1, .1, 1);
   drawSphere(.4, 0, .35, .2);
   drawBox(.3, 0, .05, .2, .1, .1);
   drawBox(.25, 0, .75, .2, .05, .15);
   drawBox(.75, 0, .25, .1, .1, .1);
   drawBox(.75, 0, .4, .1, .1, .1);
   drawBox(.75, 0, .55, .1, .1, .1);
   drawBox(.9,  0, .8,  .2, .15, .25);
   drawBox(.55, 0, .8,  .08, .2, .22);
}

function  drawSphere(cx, cy, cz, r)
{
   push();
   translate(cx, cy, cz);
   sphere(r);
   pop();
}

function  drawBox(cx, cy, cz, dx, dy, dz)
{
   push();
   translate(cx, cy+(dy/2.0), cz);
   box(dx, dy, dz);
   pop();
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch21-45-3D_greeble02.jpg')
}


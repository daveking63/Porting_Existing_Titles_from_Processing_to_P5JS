// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: recurbox02.pde in Ch10
// Chapter: Ch10-09 recursion Figure 10.11
// Description: recursively drawn (side by side) rectangles of differing specified sizes and gray colors
//
function setup() {
   createCanvas(600, 400);
   noStroke();
   handleBox(0, 0, 600, 400, 128);
}

function handleBox(ulx, uly, wid, hgt, gray) {
   fill(gray);
   rect(ulx, uly, wid, hgt);
   let  minSide = 20;
   if ((wid < minSide) || (hgt < minSide)) {
      return;
   }
   if (wid > hgt) {
      let wid2 = wid/2.0;
      handleBox(ulx, uly, wid2, hgt, gray-10);
      handleBox(ulx+wid2, uly, wid2, hgt, gray+10);
   } else {
      let hgt2 = hgt/2.0;
      handleBox(ulx, uly, wid, hgt2, gray-10);
      handleBox(ulx, uly+hgt2, wid, hgt2, gray+10);
   }
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch10-09-recursion_recurbox02.jpg')
}


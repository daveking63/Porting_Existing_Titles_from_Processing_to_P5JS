// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: bell5.pde in Ch19
// Chapter: Ch19-16 lamp Figure 19.23
// Description: moving circle with noFill following a curvilinear path in reverse direction and with a baseline
//
function setup() {
	createCanvas(600, 400);
	background(0);
	noFill();
	stroke(255);
	line(0, 237, 600, 237);
}   

function draw() {
	let  percent = map(frameCount, 0, 75, 0, 1);
	let  v = exp(-4*percent*percent);
	if (frameCount > 75) v = 0;
	let  w = 1-v;
	let  centerx = lerp(100, 500, w);
	let  centery = lerp(200, 100, sin(w * radians(180)));
	stroke(255, 255*w, 255*w);
	ellipse(centerx, centery, 75, 75);
	}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch19-16-lamp_bell5.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: p3d01.pde in Ch21
// Chapter: Ch21-08 3D Figure 21.11
// Description: first 3D polygon
//

function  setup() {
  createCanvas(600, 600, WEBGL);
  translate(0,0,0);
}

function  draw() {
  background(225, 192, 145);
  //lights();
  camera();
  smooth(); 
  //translate(width/2, height/2);
  scale(width/2, height/2);
  drawPicture();
  stroke(0);
  textSize(20);
  text("Intentionally blank",200,300);
  
}

function  drawPicture() {
  fill(241, 100, 95);
  drawPolygon();
  
}

function  drawPolygon() {
  beginShape();
  vertex(-.2, -.4, 0);
  vertex( .2, -.4, 0);
  vertex( .2,  .4, 0);
  vertex(-.2,  .4, 0);
  endShape(CLOSE);
}  



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch21-08-3D_p3d01.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: p3d05.pde in Ch21
// Chapter: Ch21-12 3D Figure 21.15
// Description: stack of spinning 3D polygons'
//

function  setup() {
	createCanvas(600, 600, WEBGL);
	createCanvas(600, 600);
	//translate(0,0,0);
}

function  draw() {
	background(225, 192, 145);
	lights();
	camera();
	smooth(); 
	//translate(width/2, height/2);
	scale(width/2, height/2);
	drawPicture();
}

function  drawPicture() {
  rotateX(frameCount * .02);
  rotateY(frameCount * .013);
  
  let color0 = color(241, 100, 95);
  let color1 = color(128, 173, 135);
  let numSteps = 30;
  for (let i=0; i<numSteps; i++) {
    let a = map(i, 0, numSteps-1, 0, 1);
    fill(lerpColor(color0, color1, a));
    translate(0, 0, -1.0/numSteps);
    drawPolygon();
  }
}

function  drawPolygon() {
  beginShape();
  vertex(-.2, -.4, 0);
  vertex( .2, -.4, 0);
  vertex( .2,  .4, 0);
  vertex(-.2,  .4, 0);
  endShape(CLOSE);
}  



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch21-12-3D_p3d05.jpg')
}


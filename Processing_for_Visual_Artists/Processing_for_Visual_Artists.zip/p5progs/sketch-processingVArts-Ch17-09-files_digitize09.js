// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: digitize09.pde in Ch17
// Chapter: Ch17-09 files Figure 17.6
// Description: Display of scanned silhouette of primitive 'oddman' showing mouse clicks with red circles where circles move to silhouette border
//
let Picture;
let OutputFile;
let Bx, By;

function preload(){
	Picture = loadImage("data/oddman.png");
}

function setup() {
   createCanvas(800, 303);
   image(Picture, 0, 0);
   OutputFile = createWriter("DrawingPoints9.txt");
   textSize(10);
   msg1 = "Click mouse to digitize point &"
   msg2 = "and write to file DrawingPoints9.txt";
   msg3 = "Type letter 'z' to signify error with last click"
   text(msg1,600,20);
   text(msg2,600,35);
   text(msg3,600,50);
   fill(255, 0, 0);
   noStroke();
}

function draw() {
}

function mouseClicked() {
   findBorder(mouseX, mouseY);
   OutputFile.print(Bx + "\t" + By);
   ellipse(Bx, By, 5, 5);
}

function keyPressed() {
  if (key == 'z') {
    OutputFile.print("ERROR!");
    print("ERROR!");
    return;
  }
  OutputFile.close();
  OutputFile.clear();
}

function findBorder(mx, my) {
   Bx = mx;
   By = my;
   let foundBorder = false;
   let  nearestDistance = 0;
   for (let dy= -5; dy<6; dy++) {
      for (let dx= -5; dx<6; dx++) {
         if (onBorder(mx+dx, my+dy)) {
            let  distance = mag(dx, dy);
            if ((!foundBorder) || (distance < nearestDistance)) {
                foundBorder = true;
                nearestDistance = distance;
                Bx = mx+dx;
                By = my+dy;
            }
         }
      }
   }
}

function onBorder(tx, ty) {
   let tcolor = Picture.get(tx, ty);
   if ((tcolor != Picture.get(tx-1, ty-1)) || // upper left
       (tcolor != Picture.get(tx,   ty-1)) || // above
       (tcolor != Picture.get(tx+1, ty-1)) || // upper right
       (tcolor != Picture.get(tx-1, ty  )) || // left
       (tcolor != Picture.get(tx+1, ty  )) || // right
       (tcolor != Picture.get(tx-1, ty+1)) || // lower left
       (tcolor != Picture.get(tx,   ty+1)) || // below
       (tcolor != Picture.get(tx+1, ty+1)))   // lower right
      return(true);
   return(false);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch17-09-files_digitize09.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: cleanup03.pde in Ch17
// Chapter: Ch17-12 files Figure 17.10
// Description: Display of scanned silhouette of primitive 'oddman' created from digitized points read from text file with errors corrected
//

let words = [];
let lines = [];

function preload(){
  lines = loadStrings("data/Body-ManPoints.txt");
}

function setup() {
  createCanvas(1600,630);
  background(255);
  stroke(0);
  strokeWeight(2);
  let ox, oy, x, y;
  ox = oy = x = y = 0;
  for (let i=0; i<=lines.length; i++) {
    let words = split(lines[i%lines.length], '\t');
    x = int(words[0]);
    y = int(words[1]);
    if (i>0) {
      line(ox, oy, x, y);
    }
    if (i%10 == 0) {
      stroke(color(random(50, 200), random(50, 200), random(50, 200)));
    }
    ox = x;
    oy = y;
  }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch17-12-files_cleanup03.jpg')
}


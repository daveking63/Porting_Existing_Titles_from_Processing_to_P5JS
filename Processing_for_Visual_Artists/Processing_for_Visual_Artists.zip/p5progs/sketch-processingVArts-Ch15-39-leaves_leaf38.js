// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: leaf38.pde in Ch15
// Chapter: Ch15-39 leaves Figure 15.39
// Description: leaf color based on position
//
// Fall leaves project
// version 1.0, Andrew, 16 April 2009
//

// dimensions of the square drawing area
let Window = 400;

function setup() {
   createCanvas(Window, Window);
   background(82, 52, 12);
   noStroke();
   //frameRate(1);
}

function draw() {
   //background(200, 190, 143);
   drawOneLeaf();
}

function drawOneLeaf() {
   let pA = createVector(-0.5, 0.0);  // left end
   let pB = createVector( 0.5, 0.0);  // right end

   let pG1 = makeControlPoint(-0.25, -0.15,  0.15, -0.05, -0.15, 0.0);
   let pG2 = makeControlPoint( 0.25, -0.15,  0.15, -0.05, -0.15, 0.0);
   let pH1 = makeControlPoint(-0.25, -0.15,  0.15,  0.05,  0.0, 0.15);
   let pH2 = makeControlPoint( 0.25, -0.15,  0.15,  0.05,  0.0, 0.15);
   
   // move the H control points so that the leaf bends
   let  yMove = random(0, 0.35);
   if (random(100) > 80) {
      yMove = -yMove;
   }
   pG2.y += yMove;
   pH2.y += yMove;
  
   let sA = pointToWindow(pA);
   let sB = pointToWindow(pB);
   let sG1 = pointToWindow(pG1);
   let sG2 = pointToWindow(pG2);
   let sH1 = pointToWindow(pH1);
   let sH2 = pointToWindow(pH2);

   translate(Window/2, Window/2);
   
   let  xTrans = random(-Window, Window);
   let  yTrans = random(-Window, Window);
   translate(xTrans, yTrans);

   let  scaleFactor = random(0.6, 1.0);
   scale(scaleFactor*Window/2);
   let  rotationAngle = random(0, 360);
   rotate(radians(rotationAngle));
   
   let tdist = mag(xTrans, yTrans);     // distance of polet to window center
   let  ddist = mag(Window/2, Window/2); // distance from window center to a corner
   let  td = tdist/ddist;                // how far we are from the cneter
   let rVal = int(random(200, 255));      // random red
   let gVal = int(random(-40, 40)) + int(td * 215);  // more green with distance
   let bVal = int(random(0, 80));         // random blue
   let leafColor = color(rVal, gVal, bVal);   // create the color
   fill(leafColor);

   beginShape();
   vertex(pA.x, pA.y);
   bezierVertex(pG1.x, pG1.y, pG2.x, pG2.y, pB.x, pB.y);
   bezierVertex(pH2.x, pH2.y, pH1.x, pH1.y, pA.x, pA.y);
   endShape();
}

function pointToWindow(p) {
   let t = p.copy();
   t.x = map(t.x, -1, 1, 0, Window-1);
   t.y = map(t.y, -1, 1, 0, Window-1);
   return(t);
}

function makeControlPoint(x, dxlo, dxhi, y, dylo, dyhi)  {
   let  px = x + random(dxlo, dxhi);
   let  py = y + random(dylo, dyhi);
   let t = createVector(px, py);
   return(t);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch15-39-leaves_leaf38.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: cleanup06.pde in Ch17
// Chapter: Ch17-15 files Figure 17.15
// Description: Cleaned up display of scanned silhouette of primitive 'oddman' created from digitized points read from text file with different chunks displayed in different colors along with points to represent each point in file
//

let words = [];
let lines = [];

function preload(){
  lines = loadStrings("data/Body-ManPoints.txt");
}

function setup() {
  createCanvas(1600,630);
  background(255);
  stroke(0);
  strokeWeight(2);
  showCurve();
}

function showCurve() {
  let ox, oy, x, y;
  ox = oy = x = y = 0;
  for (let i=0; i<=lines.length; i++) {
    words = split(lines[i%lines.length], '\t');
    print(words);
    x = int(words[0]);
    y = int(words[1]);
    if (i>0) {
      line(ox, oy, x, y);
      let  radius = 3;
      if (i%10 == 0) radius = 6;
      ellipse(x, y, radius, radius);
    }
    if (i%10 == 0) {
      stroke(color(random(50, 200), random(50, 200), random(50, 200)));
    }
    ox = x;
    oy = y;
  }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch17-15-files_cleanup06.jpg')
}


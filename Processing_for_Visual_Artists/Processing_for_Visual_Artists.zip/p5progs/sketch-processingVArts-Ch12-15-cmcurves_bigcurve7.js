// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: bigcurve7.pde in Ch12
// Chapter: Ch12-15 cmcurves Figure 12.19
// Description: Smooth curve that closes
//
let NumPoints = 8;
let Xp = [];
let Yp = [];

function setup() {
   createCanvas(600, 400);
   background(194, 216, 242);
   noFill();
   for (let i=0; i<NumPoints; i++) {
      Xp[i] = random(100, 500);
      Yp[i] = random(100, 300);
   }
}

function draw() {
   for (let i=0; i<NumPoints; i++) {
      ellipse(Xp[i], Yp[i], 10, 10);
   }
   beginShape();
   for (let i=0; i<NumPoints+3; i++) {
      let j = i%NumPoints;
      curveVertex(Xp[j], Yp[j]);
   }
   endShape();
}




//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch12-15-cmcurves_bigcurve7.jpg')
}


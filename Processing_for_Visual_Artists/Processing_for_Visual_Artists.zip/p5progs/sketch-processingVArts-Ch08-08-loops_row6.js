// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: row6.pde in Ch08
// Chapter: Ch08-08 loops Figure 8.11
// Description: drawing a row of yellow ellipses with varying transparency controlled by 'alpha' value in 'color'
//
function setup() {
   createCanvas(600, 250);
}

function draw() {
   background(200);
   fill(47, 64, 84);
   rect(25, 50, 550, 140);
   
   for (let eCount = 0; eCount<11; eCount++) {
      let  xValue = 60 + (eCount * 48);
      let myAlpha = map(eCount, 0, 9, 0, 255);
      let  myColor = color(249, 246, 155, myAlpha);
      fill(myColor);
      ellipse(xValue, 120, 40, 40);
   }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch08-08-loops_row6.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: disk05.pde in Ch14
// Chapter: Ch14-05 objects Figure 14.3
// Description: Object program with an array of 'ghost disks' with multiple attributes displayed on screen
//
let Ghosts = [];
let numGhosts = 10;

function setup() {
	createCanvas(600, 400);
	background(164, 164, 164);
	buildGhosts(numGhosts);
}

function draw() {
	for (let i=0; i<Ghosts.length; i++) {
		fill(Ghosts[i].clr);
		ellipse(Ghosts[i].xPos, Ghosts[i].yPos, Ghosts[i].radius*2, Ghosts[i].radius*2);
	}
}

function buildGhosts(numGhosts){
	let border = 50;
	for (let i=0; i<numGhosts; i++) {
	let  xPos = random(border, width-border);
	let  yPos = random(border, height-border);
	let  xDir = 10;
	let  yDir = 10;
	let  radius = random(10, 30);
	let clr = color(random(20, 255), random(20, 255), random(20, 255), 128);
	Ghosts[i] = new Disk(xPos, yPos, xDir, yDir, radius, clr);
	}	
}
class Disk {
	constructor(aXPos, aYPos, aXDir, aYDir, aRadius, aClr){
		this.xPos = aXPos;   // 1. Current location (X and Y)
		this.yPos = aYPos;
		this.xDir = aXDir;   // 2. Current motion (X and Y)
		this.yDir = aYDir;
		this.radius = aRadius; // 3. Radius
		this.clr = aClr;    // 4. Color
	}// constructor
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch14-05-objects_disk05.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: noise07.pde in Ch11
// Chapter: Ch11-22 random Figure 11.22
// Description: 2D noise pushed a little into darkness
//
function setup() {
   createCanvas(600, 400);
   let  noiseScale = 0.02;
   for (let y=0; y<height; y++) {
      for (let x=0; x<width; x++) {
         let  noiseVal = noise(x*noiseScale,y*noiseScale*.1);
         noiseVal *= noiseVal;
         let  redVal = lerp(114, 194, noiseVal);
         let  grnVal = lerp( 32, 106, noiseVal);
         let  bluVal = lerp( 12,  14, noiseVal);
         stroke(redVal, grnVal, bluVal);
         point(x, y);
      }
   }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch11-22-random_noise07.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: tint2.pde in Ch16
// Chapter: Ch16-15 images Figure 16.20
// Description: tinting over an image background
//
let myPhoto;

function preload(){
	myPhoto = loadImage("data/myPhoto.jpg");	
}

function setup() {
	createCanvas(600, 450); 
	background(0);
	noStroke();
	fill(255);
	rect(0, 0, width/2, height);

	tint(255, 255, 0, 128);
	image(myPhoto, 0, 0);
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch16-15-images_tint2.jpg')
}


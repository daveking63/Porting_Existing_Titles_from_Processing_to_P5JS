// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: blob4.pde in Ch19
// Chapter: Ch19-05 lamp Figure 19.7
// Description: two spherical blobs with gray background
//
let Img;

function setup() {
   createCanvas(600, 400);

   Img = createImage(width, height, RGB);
	
   let bgcolor = color(128, 128, 128);
   for (let y=0; y<height; y++) {
      for (let x=0; x<width; x++) {
      Img.set(x, y, bgcolor);
      }
   }

   let blob0 = new Blob(300, 200, 100);
   let blob1 = new Blob(400, 230, 75);

   Img.loadPixels();
   blob0.render();
   blob1.render();
   Img.updatePixels();
   image(Img, 0, 0);
}

function draw() {
}

class Blob {
	constructor(acx, acy, ar) {
		this.cx = acx;
		this.cy = acy;
		this.r = ar;
	}

	render() {
		for (let  y = this.cy-this.r; y < this.cy+this.r; y++) {
			for (let  x=this.cx-this.r; x<this.cx+this.r; x++) {
				let  d = dist(x, y, this.cx, this.cy);
				if (d > this.r) continue;
				let  h = map(d, 0, this.r, 1, 0);
				let ix = int(x);
				let iy = int(y);
				let oldColor = Img.get(ix, iy);
				let  newRed = (255*h) + red(oldColor);
				let  newGrn = (255*h) + green(oldColor);
				let  newBlu = blue(oldColor);
				Img.set(int(x), int(y), color(newRed, newGrn, newBlu));
			}
		}
	}
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch19-05-lamp_blob4.jpg')
}


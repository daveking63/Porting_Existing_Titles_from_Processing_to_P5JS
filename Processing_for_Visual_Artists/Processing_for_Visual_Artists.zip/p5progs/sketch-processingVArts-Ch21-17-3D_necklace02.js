// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: necklace02.pde in Ch21
// Chapter: Ch21-17 3D Figure 21.20
// Description: meshwired 3d sphere
//

function setup() {
	createCanvas(600, 400, WEBGL);
}

function draw() {
	background(180, 219, 180);
	lights();
	camera();
	//translate(width/2, height/2, 0.0);
	scale(width/2, height/2, 1.0);
	fill(50, 106, 102);
	sphere(0.5);
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch21-17-3D_necklace02.jpg')
}


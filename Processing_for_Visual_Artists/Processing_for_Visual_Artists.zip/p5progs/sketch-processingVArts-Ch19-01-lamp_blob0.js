// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: blob0.pde in Ch19
// Chapter: Ch19-01 lamp No Figure
// Description: skelton program for simulating blobs in lava lamp
//
function setup() {
	createCanvas(600, 400);
	background(200);
	textSize(30);
	text("Intentionally left blank",150,200);
	let blob0 = new Blob(300, 200, 100);
	blob0.render();
}

function draw() {
}

class Blob {
	constructor(acx, acy, ar) {
		this.cx = acx;
		this.cy = acy;
		this.r = ar;
   }

   render() {
	}
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch19-01-lamp_blob0.jpg')
}

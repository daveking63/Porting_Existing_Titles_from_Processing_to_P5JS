// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: strip03.pde in Ch21
// Chapter: Ch21-33 3D Figure 21.39
// Description: building triangle strip for base
//

let ax = 200;  let ay = 320;
let bx =  80;  let by = 160;
let cx = 220;  let cy = 200;
let dx = 300;  let dy =  40;
let ex = 380;  let ey = 200;
let fx = 520;  let fy = 160;
let gx = 400;  let gy = 320;
let hx = 300;  let hy = 320;

function  setup() {
	createCanvas(600, 400);
	background(222, 217, 177);
	fill(131, 209, 119);
	strokeWeight(3);
	strokeJoin(ROUND);
	smooth();
	drawLeaf();
}

function  drawLeaf() {
	beginShape(TRIANGLE_STRIP);
	vertex(bx, by);
	vertex(ax, ay);
	vertex(cx, cy);
	vertex(hx, hy);
	vertex(ex, ey);
	vertex(gx, gy);
	vertex(fx, fy);
	endShape();
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch21-33-3D_strip03.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: spinners6.pde in Ch10
// Chapter: Ch10-06 recursion Figure 10.8
// Description: recursively drawn nested circles of different colors that are translated then scaled and rotating together
//
let  MaxDepth = 4;
let Theta = 0;

function setup() {
   createCanvas(500, 500);
   noStroke();
}

function draw() {
   background(119, 112, 127);
   translate(250, 250);
   scale(240.0);
   drawCircles(1);
   Theta += radians(1);
}

function drawCircles(depth) {
   switch (depth) {
      case 1:  fill(color(89, 9, 21));     break;
      case 2:  fill(color(148, 14, 35));   break;
      case 3:  fill(color(181, 86, 70));   break;
      case 4:  fill(color(199, 172, 115)); break;
      default: return;     
   }   
   ellipse(0, 0, 2, 2);

   rotate(Theta);
   translate(0, 0.6);
   scale(0.4);
   drawCircles(depth+1);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch10-06-recursion_spinners6.jpg')
}


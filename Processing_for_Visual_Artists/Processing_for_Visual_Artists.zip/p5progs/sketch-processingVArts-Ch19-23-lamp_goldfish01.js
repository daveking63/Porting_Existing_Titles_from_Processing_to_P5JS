// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: goldfish01.pde in Ch19
// Chapter: Ch19-23 lamp Figure 19.38
// Description: single goldfish with aqua-green background
//
let Fish;

function setup() {
	createCanvas(600, 400);
	background(83, 181, 169);

	Fish = new Goldfish(color(255, 184, 51));
	Fish.render(100, 100, .5);
}


class Goldfish { 
	// Goldfish constructor
	constructor(afishColor) {    
		this.fishColor = afishColor;
		// Goldfish outline
		this.fx = [150, 130,  110, 90,  70,  50,   0, -40, -50, -80, -100, -80];
		this.fy = [0, -20,  -30, -40, -50, -50, -30, -10, -10, -40, -30, 0];
}

	// draw a Goldfish using this fish's color
	render(cx, cy, scl) {
		fill(this.fishColor);
		beginShape();
			for (let i=0; i<this.fx.length; i++) vertex(cx+(scl*this.fx[i]), cy+(scl*this.fy[i]));
			for (let i=this.fx.length-1; i>=0; i--) vertex(cx+(scl*this.fx[i]), cy+(scl*-this.fy[i]));
		endShape();
	}
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch19-23-lamp_goldfish01.jpg')
}


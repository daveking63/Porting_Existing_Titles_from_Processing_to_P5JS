// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: blendingWithColorsHSB.pde in Ch18
// Chapter: Ch18-05 patterns Figure 18.34
// Description: Rectangular displays of colors using linear versus cosine blending
//
function setup() {
	createCanvas(600, 400);
	background(128);
	noFill();
	let c1 = color(25, 45, 210);
	let c2 = color(250, 140, 0);
	let c3 = color(65, 120, 80);
	colorMode(HSB);
	drawSet(c1, c2, c3, false, 50, 50);
	drawSet(c1, c2, c3, true, 50, 250);
	}

function drawSet(c1, c2, c3, useCosine, xLeft, yTop) {
	drawBlend(c1, c1, xLeft,     100, yTop, 100, useCosine);
	drawBlend(c1, c2, xLeft+100, 100, yTop, 100, useCosine);
	drawBlend(c2, c2, xLeft+200, 100, yTop, 100, useCosine);
	drawBlend(c2, c3, xLeft+300, 100, yTop, 100, useCosine);
	drawBlend(c3, c3, xLeft+400, 100, yTop, 100, useCosine);
}

function drawBlend(c1, c2, xLeft, wid, yTop, hgt, useCosine) {
	let xRight = xLeft + wid;
	for (let x=xLeft; x<xRight; x++) {
		let  a = map(x, xLeft, xRight-1, 0, 1);
		if (useCosine) a = map(cos(a*radians(180)), 1, -1, 0, 1);
		let stripe = lerpColor(c1, c2, a);
		stroke(stripe);
		line(x, yTop, x, yTop+hgt);
  }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch18-05-patterns_blendingWithColorsHSB.jpg')
}


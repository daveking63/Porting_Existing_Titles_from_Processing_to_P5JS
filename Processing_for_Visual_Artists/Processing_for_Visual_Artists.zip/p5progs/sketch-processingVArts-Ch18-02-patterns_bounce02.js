// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: bounce02.pde in Ch18
// Chapter: Ch18-02 patterns Figure 18.2
// Description: Bouncing ball hopping downward across screen
//
function setup() {
	createCanvas(600, 400);
	noStroke();
}

function draw() {
	background(145, 236, 152);
	fill(6, 119, 120);
	let  time = frameCount;
	let ballCenter = getBallCenter(time);
	ellipse(ballCenter.x, ballCenter.y, 40, 40);
}

function getBallCenter(time)
{
   let  xPosition = time;
   let  angle = time/40.0;
   let  bounceHeight = max(0, map(time, 0, 600, 1, 0));
   let  yPosition = bounceHeight * abs(cos(angle));
   yPosition = map(yPosition, 0, 1, 350, 50);
   let center = createVector(xPosition, yPosition);
   return(center);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch18-02-patterns_bounce02.jpg')
}


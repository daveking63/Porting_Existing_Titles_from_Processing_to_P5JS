// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: blend1.pde in Ch16
// Chapter: Ch16-17 images Figure 16.23
// Description: blending a mountain image and a rock image using various modes
//

let Hike, Rock;

function preload(){
	Hike = loadImage("data/mountains300.jpg");
	Rock = loadImage("data/rocks300.jpg");
}

function setup() {
	createCanvas(1350, 1050); 
	background(128);

	for (let y=0; y<4; y++) {
		for (let x=0; x<4; x++) {
			showPictures(x, y);
		}
	}
}

function showPictures(x, y) {
	let ulx = x * 350;
	let uly = y * 275;
	image(Hike, ulx, uly, 300, 225);
	switch ((y*4)+x) {
	case  0: blend(Rock, 0, 0, 300, 225, ulx, uly, 300, 225, BLEND); break;
	case  1: blend(Rock, 0, 0, 300, 225, ulx, uly, 300, 225, ADD); break;
	case  2: blend(Rock, 0, 0, 300, 225, ulx, uly, 300, 225, DIFFERENCE); break;
	case  3: blend(Rock, 0, 0, 300, 225, ulx, uly, 300, 225, DARKEST); break;

	case  4: blend(Rock, 0, 0, 300, 225, ulx, uly, 300, 225, LIGHTEST); break;
	case  5: blend(Rock, 0, 0, 300, 225, ulx, uly, 300, 225, DIFFERENCE); break;
	case  6: blend(Rock, 0, 0, 300, 225, ulx, uly, 300, 225, EXCLUSION); break;
	case  7: blend(Rock, 0, 0, 300, 225, ulx, uly, 300, 225, MULTIPLY); break;

	case  8: blend(Rock, 0, 0, 300, 225, ulx, uly, 300, 225, SCREEN); break;
	case  9: blend(Rock, 0, 0, 300, 225, ulx, uly, 300, 225, OVERLAY); break;
	case 10: blend(Rock, 0, 0, 300, 225, ulx, uly, 300, 225, HARD_LIGHT); break;
	case 11: blend(Rock, 0, 0, 300, 225, ulx, uly, 300, 225, SOFT_LIGHT); break;

	case 12: blend(Rock, 0, 0, 300, 225, ulx, uly, 300, 225, DODGE); break;
	case 13: blend(Rock, 0, 0, 300, 225, ulx, uly, 300, 225, BURN); break;
	case 14: tint(255, 255, 0); image(Rock, ulx, uly, 300, 225); noTint(); break;
	case 15: tint(255, 128);    image(Rock, ulx, uly, 300, 225); noTint(); break;
	default: break;
  }
}
    



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch16-17-images_blend1.jpg')
}


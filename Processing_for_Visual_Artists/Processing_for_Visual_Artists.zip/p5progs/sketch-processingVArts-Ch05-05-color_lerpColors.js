// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: lerpColors.pde in Ch05
// Chapter: Ch05-05 color Figure 5.8
// Description: Using lerpColor function to interpolate colors along a continuum
//
function setup() {
   let c0 = color(199, 172, 115 );
   let c1 = color( 46, 106, 148 );
   createCanvas(800, 450);
   noStroke();
   let numSteps = 700;
   for (let i=0; i<numSteps; i++) {
     let a = i/(numSteps-1.0);
     
     // RGB upper
     colorMode(RGB);
     fill(lerpColor(c0, c1, a));
     rect(50+i, 50, 1, 150);
     
     // HSB lower
     colorMode(HSB);
     fill(lerpColor(c0, c1, a));
     rect(50+i, 250, 1, 150);
     colorMode(RGB);
   }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch05-05-color_lerpColors.jpg')
}


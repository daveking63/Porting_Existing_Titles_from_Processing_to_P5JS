// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: pixels04.pde in Ch16
// Chapter: Ch16-11 images Figure 16.16
// Description: animated image contours from noise with a problem
//
let NumLayers = 10;   // smaller values = bigger blobs
let Speed = 20;       // smaller values = faster animation
let WindowSize = 400; // smaller values = smaller window = smoother animation

function setup() {
	createCanvas(WindowSize, WindowSize);
}

function draw() {
	background(0);
	loadPixels();
	let color0 = color(35, 160, 255);
	let color1 = color(255, 116, 0);
	let thisColor = color0;
	let  layerHeight = 1.0/NumLayers;
	for (let y=0; y<height; y++) {
		for (let x=0; x<width; x++) {
			let  noiseVal = noise(x*.015, y*.015);

			let  noiseBump = lerp(0, layerHeight, (frameCount % Speed)/(1.0*Speed));
			let whichColor = int((noiseVal+noiseBump)/layerHeight);
			if (((whichColor) % 2) == 0) thisColor = color0;
			else thisColor = color1;

			set(x, y, thisColor);
		}
	}
	updatePixels();
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch16-11-images_pixels04.jpg')
}


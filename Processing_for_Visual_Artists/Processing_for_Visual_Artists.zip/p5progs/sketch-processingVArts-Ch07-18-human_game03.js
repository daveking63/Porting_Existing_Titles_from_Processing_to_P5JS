// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: game03.pde in Ch07
// Chapter: Ch07-18 human Figure 7.10
// Description: playing Simple game with score register when mousePressed on yellow parts of bar and Bulls eye on green part of bar
//
let  Score = 0;

let ZoneCenterX, ZoneSpeed, OuterZoneWidth, InnerZoneWidth;
let  ZoneDirection;

function setup() {
	createCanvas(600, 400);
	ZoneCenterX = 0;
	ZoneSpeed = 1.5;    // pixels per frame 
	InnerZoneWidth = width/50.0;  
	OuterZoneWidth = width/15.0;
	ZoneDirection = 1;   
}

function draw() {
	ZoneCenterX += ZoneDirection * ZoneSpeed;
	if ((ZoneCenterX < 0) || (ZoneCenterX >= width)) {
		ZoneSpeed *= -1;
	}
	background(115, 40, 22);
	noStroke();
	fill(186, 186, 115);  
	rect(ZoneCenterX-OuterZoneWidth/2, 0, OuterZoneWidth, height);
	fill(46, 118, 56);
	rect(ZoneCenterX-InnerZoneWidth/2, 0, InnerZoneWidth, height);
   fill(255);
   textSize(15);
   text('See Console for Score',400,375);
}

function mousePressed() {
  let distance = ZoneCenterX - mouseX;
  if (distance < 0) distance = -distance;   // better: distance = abs(distance);
  if (distance < InnerZoneWidth/2.0) {
     Score += 20;
     print("BULLS EYE! ");
  } else if (distance < OuterZoneWidth/2.0) {
     Score += 5;
  } else {
     print("oops ");
     Score -= 5;
  }
  print(Score);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch07-18-human_game03.jpg')
}


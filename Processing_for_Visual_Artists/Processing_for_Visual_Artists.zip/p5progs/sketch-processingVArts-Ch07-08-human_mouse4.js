// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: mouse4.pde in Ch07
// Chapter: Ch07-08 human No Figure
// Description: setting background blue component with mouseMoved subroutine and mouseIsPressed
//
let Redval = 192; // background red
let Grnval = 64;  // background green
let Bluval = 0;   // background blue
let  MyColor;

function setup() {
   createCanvas(600, 400);
   MyColor = color(Redval, Grnval, Bluval);
   background(MyColor);
}

function draw() {
   background(MyColor);
   textSize(15);
   text('Move and Press mouse',230,200);
   moveMouse();
}


function moveMouse() {
   if (mouseIsPressed) {
      Bluval = map(mouseX, 0, 599, 0, 255);
   }
   Redval = map(mouseX, 0, 599, 0, 255);
   Grnval = map(mouseY, 0, 399, 0, 255);
   MyColor = color(Redval, Grnval, Bluval);
   
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch07-08-human_mouse4.jpg')
}


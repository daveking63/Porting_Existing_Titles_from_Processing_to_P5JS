// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: game01.pde in Ch07
// Chapter: Ch07-16 human Figure 7.8
// Description: Simple game setup - moving vertical yellow-green-yellow bar horizontally across screen
//
let  Score = 0;

let ZoneCenterX, ZoneSpeed, OuterZoneWidth, InnerZoneWidth;

function setup() {
  createCanvas(600, 400);
  
   ZoneCenterX = 0;
   ZoneSpeed = 1.5;    // pixels per frame 
   InnerZoneWidth = width/50.0;  
   OuterZoneWidth = width/15.0;   
}

function draw() {
   ZoneCenterX += ZoneSpeed;
   background(115, 40, 22);
   noStroke();
   fill(186, 186, 115);  
   rect(ZoneCenterX-OuterZoneWidth/2, 0, OuterZoneWidth, height);
   fill(46, 118, 56);
   rect(ZoneCenterX-InnerZoneWidth/2, 0, InnerZoneWidth, height);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch07-16-human_game01.jpg')
}


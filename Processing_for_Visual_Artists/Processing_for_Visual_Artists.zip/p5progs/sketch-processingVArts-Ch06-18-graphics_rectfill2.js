// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: rectfill2.pde in Ch06
// Chapter: Ch06-18 graphics Figure 6.25
// Description: specifying different fill color for 4 rectangles
//
function setup() { 
   createCanvas(600, 400);
   background(106, 158, 155);
   strokeWeight(10);
}  

function draw() {
   fill(122, 99, 12);
   rect(40, 140, 80, 50);

   fill(194, 176, 100);
   rect(150, 140, 80, 50);

   fill(240, 231, 166);
   rect(260, 140, 80, 50);

   fill(198, 209, 173);
   rect(370, 140, 80, 50);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch06-18-graphics_rectfill2.jpg')
}


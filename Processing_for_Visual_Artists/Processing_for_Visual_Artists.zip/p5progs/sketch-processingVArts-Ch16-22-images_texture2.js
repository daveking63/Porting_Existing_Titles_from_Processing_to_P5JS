// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: texture2.pde in Ch16
// Chapter: Ch16-22 images Figure 16.29
// Description: texture with openGL
//
//import processing.opengl.*;

let Hike;

function preload(){
	Hike = loadImage("data/myPhoto.jpg");
}

function setup() {
  createCanvas(600, 400, WEBGL); 
  background(192);
  translate(-300,-200);
  
  // tall thin rectangle
	beginShape();
		texture(Hike);
		vertex(50, 50, 0, 0);
		vertex(150, 50, 599, 0);
		vertex(150, 350, 599, 449);
		vertex(50, 350, 0, 449);
	endShape(CLOSE);
  
	// short wide rectangle
	beginShape();
		texture(Hike);
		vertex(200, 250, 0, 0);
		vertex(550, 250, 599, 0);
		vertex(550, 350, 599, 449);
		vertex(200, 350, 0, 449);
	endShape(CLOSE);
  
	// square
	beginShape();
		texture(Hike);
		vertex(300, 50,   50, 200);
		vertex(450, 50,  200, 200);
		vertex(450, 200, 200, 400);
		vertex(300, 200,  50, 400);
	endShape(CLOSE);
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch16-22-images_texture2.jpg')
}


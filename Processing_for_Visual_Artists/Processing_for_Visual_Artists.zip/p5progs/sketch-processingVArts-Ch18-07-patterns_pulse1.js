// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: pulse1.pde in Ch18
// Chapter: Ch18-07 patterns Figure 18.36
// Description: Pulsing circles moving in horizontal direction
//
let  Angle = 0;

function setup() {
	createCanvas(600, 400);
	fill(196, 84, 94);
}

function draw() {
	background(135, 125, 112);
	for (let i=0; i<6; i++) {
		let  radius = map(sin(Angle), -1, 1, 20, 40);
		ellipse(50+(100*i), 200, 2*radius, 2*radius);
	}
	Angle += .1;
}

//
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch18-07-patterns_pulse1.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: circle01.pde in Ch11
// Chapter: Ch11-01 random Figure 11.1
// Description: display circle in center of canvas
//
function setup() {
  createCanvas(600, 400);
  background(150, 90, 65);
  fill(250, 200, 90);
  ellipse(width/2, height/2, 100, 100);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch11-01-random_circle01.jpg')
}


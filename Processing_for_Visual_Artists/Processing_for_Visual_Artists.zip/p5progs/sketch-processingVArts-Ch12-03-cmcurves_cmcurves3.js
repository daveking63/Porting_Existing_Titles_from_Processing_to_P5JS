// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: cmcurves3.pde in Ch12
// Chapter: Ch12-03 cmcurves Figure 12.4
// Description: Curve between two points
//
function setup() {
   createCanvas(600, 400);
   background(242, 240, 174);
   noFill();
}

let Xp = [100, 300, 300, 100];
let Yp = [100, 100, 300, 300];

function draw() {
   for (let i=0; i<4; i++) {
      ellipse(Xp[i], Yp[i], 15, 15);
   }
   curve(Xp[0], Yp[0], Xp[1], Yp[1], Xp[2], Yp[2], Xp[3], Yp[3]);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch12-03-cmcurves_cmcurves3.jpg')
}


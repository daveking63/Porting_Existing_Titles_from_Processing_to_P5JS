// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: curvePoint02.pde in Ch12
// Chapter: Ch12-20 cmcurves Figure 12.25
// Description: Drawing ellipses on a curve using curvePoint function
//
let Xp = [40,  50, 540, 300];
let Yp = [940, 160, 200, 900];

function setup() {
  createCanvas(600, 400);
  background(237, 180, 198);
  noFill();
  curve(Xp[0], Yp[0], Xp[1], Yp[1], Xp[2], Yp[2], Xp[3], Yp[3]);
  
  let numSteps = 8;
  for (let i=0; i<numSteps; i++) {
    let  t = map(i, 0, numSteps-1, 0, 1);
    let  xPos = curvePoint(Xp[0], Xp[1], Xp[2], Xp[3], t);
    let  yPos = curvePoint(Yp[0], Yp[1], Yp[2], Yp[3], t);
    fill(255);
    strokeWeight(1);
    stroke(0, 0, 0);
    ellipse(xPos, yPos, 20, 20);
  }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch12-20-cmcurves_curvePoint02.jpg')
}


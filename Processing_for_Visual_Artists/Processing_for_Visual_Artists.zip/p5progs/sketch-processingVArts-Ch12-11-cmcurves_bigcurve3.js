// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: bigcurve3.pde in Ch12
// Chapter: Ch12-11 cmcurves Figure 12.14
// Description: New curve project with curve touching multiple points - but with bug
//
let NumPoints = 8;
let Xp = [];
let Yp = [];

function setup() {
   createCanvas(600, 400);
   background(194, 216, 242);
   noFill();
   for (let i=0; i<NumPoints; i++) {
      Xp[i] = random(100, 500);
      Yp[i] = random(100, 300);
   }
}

function draw() {
   for (let i=0; i<NumPoints; i++) {
      ellipse(Xp[i], Yp[i], 10, 10);
      }
   for (i=0; i<NumPoints; i++) {
      let p0 = i;
      let p1 = i+1;
      let p2 = i+2;
      let p3 = i+3;
      curve(Xp[p0], Yp[p0], Xp[p1], Yp[p1], Xp[p2], Yp[p2], Xp[p3], Yp[p3]);
   }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch12-11-cmcurves_bigcurve3.jpg')
}


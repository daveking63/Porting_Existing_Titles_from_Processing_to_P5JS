// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: blob6.pde in Ch19
// Chapter: Ch19-07 lamp Figure 19.9
// Description: two spherical blobs with pixel intensity controlled by simulated temperature
//
let Img;
let Temperature = [];

function setup() {
   createCanvas(600, 400);
   Img = createImage(width, height, RGB);

   let blob0 = new Blob(300, 200, 100);
   let blob1 = new Blob(400, 230, 75);
  
   zeroTemperature();
   blob0.render();
   blob1.render();
   
   Img.loadPixels();
   buildImage();
   Img.updatePixels();
   image(Img, 0, 0);
}

function draw() {
}

function zeroTemperature() {
   for (let y=0; y<height; y++) {
   	  Temperature[y] = [];
      for (let x=0; x<width; x++) {
         Temperature[y][x] = 0;
      }
   }
}

function buildImage() {
   for (let y=0; y<height; y++) {
      for (let x=0; x<width; x++) {
         if (Temperature[y][x] == 0.4) {
            Img.set(x, y, color(255, 0, 0));
         } else {
            let  t = map(Temperature[y][x], 0, 1.5, 0, 255);
            Img.set(x, y, color(t, t, 0));
         }
      }
   }
}

class Blob {
	constructor(acx, acy, ar) {
		this.cx = acx;
		this.cy = acy;
		this.r = ar;
	}

	render() {
		for (let  y = this.cy-this.r; y < this.cy+this.r; y++) {
			for (let  x=this.cx-this.r; x<this.cx+this.r; x++) {
				let  d = dist(x, y, this.cx, this.cy);
				if (d > this.r) continue;
				let  h = map(d, 0, this.r, 1, 0);
            	Temperature[int(y)][int(x)] += h;
         }
      }
   }
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch19-07-lamp_blob6.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: bigcurveanim.pde in Ch12
// Chapter: Ch12-17 cmcurves Figure 12.21
// Description: Animated smooth curve with changing tightness
//
let Xp = [];
let Yp = [];
let NumPoints = 10;

function setup() {
   createCanvas(600, 400);
   noFill();
   for (let i=0; i<NumPoints; i++) {
      Xp[i] = random(100, 500);
      Yp[i] = random(100, 300);
   }
}

function draw() {
   background(194, 216, 242);
   for (let i=0; i<NumPoints; i++) {
      ellipse(Xp[i], Yp[i], 10, 10);
   }
   let  tightness = map(sin(frameCount * .1), -1, 1, 0, 1);
   curveTightness(tightness);
   beginShape();
   for (let i=0; i<NumPoints+3; i++) {
      let j = (i+1)%NumPoints;
      curveVertex(Xp[j], Yp[j]);
   }
   endShape();
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch12-17-cmcurves_bigcurveanim.jpg')
}


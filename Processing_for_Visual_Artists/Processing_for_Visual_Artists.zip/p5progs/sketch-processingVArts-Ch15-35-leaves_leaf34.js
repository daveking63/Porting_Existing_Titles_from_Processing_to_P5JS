// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: leaf34.pde in Ch15
// Chapter: Ch15-35 leaves Figure 15.35
// Description: splitting off color calculation from leaf construction
//
// Fall leaves project
// version 0.1, Andrew, 16 April 2009
//

// dimensions of the square drawing area
let Window = 400;

function setup() {
   createCanvas(Window, Window);
   background(200, 190, 143);
   noStroke();
   //frameRate(1);
}

function draw() {
   //background(200, 190, 143);
   drawOneLeaf();
}

function drawOneLeaf() {
   let pA = createVector(-0.5, 0.0);  // left end
   let pB = createVector( 0.5, 0.0);  // right end

   let pG1 = makeControlPoint(-0.25, -0.15,  0.15, -0.05, -0.15, 0.0);
   let pG2 = makeControlPoint( 0.25, -0.15,  0.15, -0.05, -0.15, 0.0);
   let pH1 = makeControlPoint(-0.25, -0.15,  0.15,  0.05,  0.0, 0.15);
   let pH2 = makeControlPoint( 0.25, -0.15,  0.15,  0.05,  0.0, 0.15);
   
   // move the H control points so that the leaf bends
   let  yMove = random(0, 0.35);
   if (random(100) > 80) {
      yMove = -yMove;
   }
   pG2.y += yMove;
   pH2.y += yMove;
  
   let leafColor = makeLeafColor();
   fill(leafColor);

   translate(Window/2, Window/2);
   
   let  xTrans = random(-Window, Window);
   let  yTrans = random(-Window, Window);
   translate(xTrans, yTrans);

   let  scaleFactor = random(0.6, 1.0);
   scale(scaleFactor*Window/2);
   let  rotationAngle = random(0, 360);
   rotate(radians(rotationAngle));
   beginShape();
   vertex(pA.x, pA.y);
   bezierVertex(pG1.x, pG1.y, pG2.x, pG2.y, pB.x, pB.y);
   bezierVertex(pH2.x, pH2.y, pH1.x, pH1.y, pA.x, pA.y);
   endShape();
}

function makeControlPoint(x, dxlo, dxhi, y, dylo, dyhi)  {
   let  px = x + random(dxlo, dxhi);
   let  py = y + random(dylo, dyhi);
   let t = createVector(px, py);
   return(t);
}

function makeLeafColor() {
   let myRed = int(random(50, 255));
   let myGrn = int(random(50, 255));
   let myBlu = int(random(50, 255));
   let clr = color(myRed, myGrn, myBlu, 128);
   return(clr);
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch15-35-leaves_leaf34.jpg')
}


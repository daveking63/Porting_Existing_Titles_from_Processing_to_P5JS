// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: digitize08.pde in Ch17
// Chapter: Ch17-08 files No Figure
// Description: Display of scanned silhouette of primitive 'oddman' showing mouse clicks with red circles where circles move to silhouette border
//
let Picture;
let OutputFile;

function preload(){
	Picture = loadImage("data/oddman.png");
}

function setup() {
   createCanvas(800, 303);
   image(Picture, 0, 0);
   OutputFile = createWriter("DrawingPoints8.txt");
   textSize(10);
   msg1 = "Click mouse to digitize point &"
   msg2 = "and write to file DrawingPoints8.txt";
   msg3 = "Type letter 'z' to signify error with last click"
   text(msg1,600,20);
   text(msg2,600,35);
   text(msg3,600,50);
   fill(255, 0, 0);
   noStroke();
}

function draw() {
}

function mouseClicked() {
   OutputFile.print(mouseX + "\t" + mouseY);
   ellipse(mouseX, mouseY, 5, 5);
}

function keyPressed() { 
  if (key == 'z') {
    OutputFile.print("ERROR!");
    print("ERROR!");
    return;
  }
  OutputFile.close(); 
  OutputFile.clear(); 
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch17-08-files_digitize08.jpg')
}


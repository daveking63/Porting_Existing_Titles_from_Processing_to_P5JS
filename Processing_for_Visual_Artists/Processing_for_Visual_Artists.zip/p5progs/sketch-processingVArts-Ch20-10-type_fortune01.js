// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: fortune01.pde in Ch20
// Chapter: Ch20-10 type No Figure
// Description: program to generate fortune cookie text
//
// Fortune cookie program
// version 1.0 - AG 24 April 2009
// 1. <Number> <Animal>s are out to get <Person>.
// 2. <When>'s lucky sandwich is <Food> on <Bread>.


let myFont;
function preload(){
	myFont = loadFont("data/AvenirNextLTPro-Demi.otf"); 
}

let F1_1 = "1. ";
let F1_2 = " ";
let F1_3 = "s are out to get ";
let F1_4 = ".";
let F2_1 = "2. ";
let F2_2 = "'s lucky sandwich is ";
let F2_3 = " on ";
let F2_4 = ".";

let Num, Animal, Person, When, Food, Bread;

function setup() {
	createCanvas(600, 400);
	smooth();
	Numb = split("Three,Seventeen,Some,A few,Lots of,Most,No", ',');
	Animal = split("lion,giraffe,elephantalope,worm", ',');
	Person = split("you,your neighbor,Uncle Bob,Crazy Harry", ',');
	When = split("Today,This week,Yesterday,March,2003", ',');
	Food = split("macaroni,roasted apple,peanut brittle,frog", ',');
	Bread = split("rye,wheat,multi-grain,pita,a hot-dog bun", ',');

	textFont(myFont);
	textAlign(LEFT);
	textSize(36);
	frameRate(1/3.0);
}

function draw() {
	background(240);
	frameRate(1/3.0);
	textSize(36);
	text("Content intentionally blank",50,200);

}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch20-10-type_fortune01.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: blob15.pde in Ch19
// Chapter: Ch19-29 lamp Figure 19.44
// Description: blobs and subclasses of animated blobs
//
let Img;
let Temperature = [];
let MinBlobVal = 0.01831564; 
let WarmWax = [];

function setup() {
	createCanvas(600, 400);
	Img = createImage(width, height, RGB);
	makeWax();
	}

function draw() {
	zeroTemperature();
	for (let i=0; i<WarmWax.length; i++) {
		WarmWax[i].move();
		WarmWax[i].render();
	}

	Img.loadPixels();
	buildImage();
	Img.updatePixels();
	image(Img, 0, 0);
}

function makeWax() {
	let numWarmBlobs = 1+int(width/100);
	let xcenter = 0;
	for (let i=0; i<numWarmBlobs; i++) {
		WarmWax[i] = new WarmBlob(i*100, height, 100);
	}
}

function zeroTemperature() {
	for (let y=0; y<height; y++) {
		Temperature[y] =[];
		for (let x=0; x<width; x++) {
			Temperature[y][x] = 0;
		}
	}
}

function buildImage() {
	for (let y=0; y<height; y++) {
		for (let x=0; x<width; x++) {
			let  midT = 0.4;
			let  rangeT = 0.05;
			if (abs(Temperature[y][x] - midT) < rangeT) {
				Img.set(x, y, color(255, 0, 0));
			} else {
				let  t = map(Temperature[y][x], 0, 1.5, 0, 255);
				Img.set(x, y, color(t, t, 0));
		}
		}
	}
}

class Blob {
	constructor(acx, acy, ar) {
		this.cx = acx;
		this.cy = acy;
		this.r = ar;
		this.startWobbles(radians(20)*random(-1, 1), this.r*random(0.1, 0.3),    
		       radians(20)*random(-1, 1), this.r*random(0.1, 0.3));
	}

	startWobbles(axinc, axrad, ayinc, ayrad) {
		this.xangle = random(0, radians(360));
		this.yangle = random(0, radians(360));
		this.xinc = axinc;
		this.yinc = ayinc;
		this.xrad = axrad;
		this.yrad = ayrad;
		this.xorig = this.cx;
		this.yorig = this.cy;
   }
   
	move() {
		this.cx = this.xorig + (this.xrad * cos(this.xangle));
		this.cy = this.yorig + (this.yrad * cos(this.yangle));
		this.xangle += this.xinc;
		this.yangle += this.yinc;
   }

	render() {
		let lox = max(0, int(this.cx-this.r));
		let hix = min(width, int(this.cx+this.r));
		let loy = max(0, int(this.cy-this.r));
		let hiy = min(height, int(this.cy+this.r));
		for (let y=loy; y<hiy; y++) {
			for (let x=lox; x<hix; x++) { 
				let  d2 = sq(x-this.cx)+sq(y-this.cy);
				if (d2 > this.r*this.r) continue;
				let  d = sqrt(d2);
				let  h = map(d, 0, this.r, 1, 0);
				let  v = exp(-4*h*h);
				v = map(v, 1, MinBlobVal, 0, 1);  
				Temperature[y][x] += v;
			}
		}
	}
}

class WarmBlob extends Blob {    
	constructor(acx, acy, ar) {
		super(acx, acy, ar);
		this.startWobbles(radians(3)*random(-1, 1), ar*random(0.1, 0.2),
		           radians(3)*random(-1, 1), ar*random(0.1, 0.2));
	}
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch19-29-lamp_blob15.jpg')
}


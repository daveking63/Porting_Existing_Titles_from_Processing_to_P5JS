// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: disk06.pde in Ch14
// Chapter: Ch14-06 objects Figure 14.4
// Description: Object program with an array of 'ghost disks' with multiple attributes displayed on screen with render method
//
let Ghosts = [];
let numGhosts = 10;

function setup() {
	createCanvas(600, 400);
	background(164, 164, 164);
	buildGhosts(numGhosts);
}

function draw() {
   for (let i=0; i<Ghosts.length; i++) {
      Ghosts[i].render();
   }
}

function buildGhosts(numGhosts){
	let border = 50;
	for (let i=0; i<numGhosts; i++) {
	let  xPos = random(border, width-border);
	let  yPos = random(border, height-border);
	let  xDir = 10;
	let  yDir = 10;
	let  radius = random(10, 30);
	let clr = color(random(20, 255), random(20, 255), random(20, 255), 128);
	Ghosts[i] = new Disk(xPos, yPos, xDir, yDir, radius, clr);
	}	
}
class Disk {
	constructor(aXPos, aYPos, aXDir, aYDir, aRadius, aClr){
		this.xPos = aXPos;   // 1. Current location (X and Y)
		this.yPos = aYPos;
		this.xDir = aXDir;   // 2. Current motion (X and Y)
		this.yDir = aYDir;
		this.radius = aRadius; // 3. Radius
		this.clr = aClr;    // 4. Color
	}// constructor
	render() {
		fill(this.clr);
		ellipse(this.xPos, this.yPos, this.radius*2, this.radius*2);
   }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch14-06-objects_disk06.jpg')
}


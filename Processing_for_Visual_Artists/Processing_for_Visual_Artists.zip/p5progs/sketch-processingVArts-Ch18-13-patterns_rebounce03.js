// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: rebounce03.pde in Ch18
// Chapter: Ch18-13 patterns Figure 18.43
// Description: Making a ball bounce with abs of cos function
//
let WindowSize = 800;
let MinimumX = 0;   // the minimum input value
let MaximumX = 1000;   // the maximum input value

function setup() {
	createCanvas(WindowSize, WindowSize);
	background(255);

	let border = 20;                      // leave a gap around the plot
	let windowMin = border;               // left and bottom
	let windowMax = WindowSize - border;  // right and top

	// draw a box around the plot
	noFill();
	stroke(0, 0, 0);
	rect(windowMin, windowMin, windowMax-windowMin, windowMax-windowMin);

	// run through the function and find the output range
	let  yMin = plotFunction(MinimumX);
	let  yMax = yMin;
	for (let screenX=windowMin; screenX<windowMax; screenX++) {
		let  xValue = map(screenX, windowMin, windowMax, MinimumX, MaximumX);
		let  yValue = plotFunction(xValue);
		if (yValue < yMin) yMin = yValue;
		if (yValue > yMax) yMax = yValue;
	}

	// now run through the values again, and plot them
	let  oldx = 0;
	let  oldy = 0;
	for (let screenX=windowMin; screenX<windowMax; screenX++) {
		let  xValue = map(screenX, windowMin, windowMax, MinimumX, MaximumX);
		let  yValue = plotFunction(xValue);

		let  screenY = map(yValue, yMin, yMax, windowMax, windowMin);
		if (screenX > windowMin) {
			line(oldx, oldy, screenX, screenY);
		}
		oldx = screenX;
		oldy = screenY;
	}
}

function plotFunction (x)
{
	let  v = abs(cos(x/40.0));
	return(v);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch18-13-patterns_rebounce03.jpg')
}


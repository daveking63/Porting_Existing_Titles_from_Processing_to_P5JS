// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: blur01.pde in Ch22
// Chapter: Ch22-12 oddsends Figure 22.20
// Description: using a moving blur box of 5 pixels to blur an image
// Note: in today's p5.js and processing this can easily be done
// with one call using the filter(BLUR...) method, here:
//  image(pic, 0, 0);
//  filter(BLUR, blurRadius);


let pic;
let blurSrc;
let blurDst;
let numPasses = 1;
let blurRadius = 5;

function preload(){
	pic = loadImage("data/myPhoto-600-450.jpg");
}

function setup() {
	createCanvas(600, 450);
	pixelDensity(1);
	pic.loadPixels();
	blurImage(pic, numPasses, blurRadius);
	image(blurDst, 0, 0);
}

function blurImage(img, numPasses, blurRadius) {
	// copy the input layer's pixels into the source blurSrc
	blurSrc = createImage(600,450);
	blurSrc.loadPixels();
	for (y = 0; y < img.height; y++){
		for (x = 0; x < img.width; x++){
			let indx = (x + y * img.width) * 4;
	    	blurSrc.pixels[indx] = img.pixels[indx];
	    	blurSrc.pixels[indx+1] = img.pixels[indx+1];
	    	blurSrc.pixels[indx+2] = img.pixels[indx+2];
	    	blurSrc.pixels[indx+3] = img.pixels[indx+3];
		}
	}
	blurSrc.updatePixels();

	// blur the image in blurSrc and save that in blurDst
	blurDst = createImage(600,450);
	blurDst.loadPixels();
	for (let pass=0; pass<numPasses; pass++) {
		for (let y=0; y<img.height; y++) {
			for (let x=0; x<img.width; x++) {
				let indx1 = (x + y * img.width) * 4;
				let count = 0;
				let rSum = 0;
				let gSum = 0;
				let bSum = 0;
				let aSum = 0;
				let ixlo = max(0, x-blurRadius);
				let ixhi = min(width, x+blurRadius);
				let iylo = max(0, y-blurRadius);
				let iyhi = min(height, y+blurRadius);
				for (let iy=iylo; iy<iyhi; iy++) {
				   for (let ix=ixlo; ix<ixhi; ix++) {
						let indx2 = (ix + iy * img.width) * 4;
						let redClr = blurSrc.pixels[indx2];
						let greenClr = blurSrc.pixels[indx2+1];
						let blueClr = blurSrc.pixels[indx2+2];
						let alphaClr = blurSrc.pixels[indx2+3];
						count++;
						rSum += redClr;
						gSum += greenClr;
						bSum += blueClr;
						aSum += alphaClr;
				   }
				}
				if (count == 0) count = 1;
				let blurClr = color(rSum/count, gSum/count, bSum/count, aSum/count);
				blurDst.pixels[indx1] = red(blurClr);
				blurDst.pixels[indx1+1] = green(blurClr);
				blurDst.pixels[indx1+2] = blue(blurClr);
				blurDst.pixels[indx1+3] = alpha(blurClr);
			}
		}
        blurDst.updatePixels();
	}

}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch22-12-oddsends_blur01.jpg')
}


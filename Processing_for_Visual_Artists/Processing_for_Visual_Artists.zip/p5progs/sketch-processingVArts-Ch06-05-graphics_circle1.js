// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: circle1.pde in Ch06
// Chapter: Ch06-05 graphics Figure 6.11
// Description: Display circle
//
function setup() { 
   createCanvas(600, 400);
   background(163, 143, 109);
}  

function draw() {
   ellipse(250, 200, 250, 250);
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch06-05-graphics_circle1.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: directionalLight.pde in Ch21
// Chapter: Ch21-39 3D Figure 21.48
// Description: illuminated grid of spheres from a directional light to the right
//


function setup() {
  createCanvas(600, 600, WEBGL);
  //translate(-300, -300, 0);	
}

function draw(){
	background(144, 196, 224);
	translate(-300, -300, 0);
	specularMaterial(255, 255, 255);
	directionalLight(255, 255, 255, -1, 0, -1);
	perspective(PI / 3.0, width / height, 0.1, 500);
	drawPicture();
	noLoop;
}

function drawPicture(){

	noStroke();
	fill(255);

	let xSteps = 5;
	let ySteps = 5;
	for (let y = 0; y < ySteps; y++) {
		for (let x = 0; x < xSteps; x++) {
			let xAlpha = float(x / (xSteps - 1.0));
			let yAlpha = float(y / (ySteps - 1.0));
			let xPos = float(lerp(100, 500, xAlpha));
			let yPos = float(lerp(100, 500, yAlpha));
			push();
				translate(xPos, yPos, 0);
				sphere(30);
			pop();
		}
	}
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch21-39-3D_directionalLight.jpg')
}


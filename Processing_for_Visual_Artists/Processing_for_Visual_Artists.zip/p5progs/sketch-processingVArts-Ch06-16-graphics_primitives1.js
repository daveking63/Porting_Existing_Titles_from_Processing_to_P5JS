// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: primitives1.pde in Ch06
// Chapter: Ch06-16 graphics Figure 6.23
// Description: display nine separate geometric primitives
//
function setup() { 
   createCanvas(600, 400);
   background(163, 143, 109);
}  

function draw() {
   rect(20, 40, 100, 50);
   rect(150, 40, 80, 80);
   ellipse(70, 200, 100, 50);
   ellipse(190, 200, 80, 80);
   arc(300, 180, 100, 100, radians(0), radians(90));
   triangle(50, 300, 110, 320, 90, 360);
   quad(190, 300, 220, 320, 210, 360, 150, 340);
   line(300, 40, 340, 100);
   point(300, 320);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch06-16-graphics_primitives1.jpg')
}


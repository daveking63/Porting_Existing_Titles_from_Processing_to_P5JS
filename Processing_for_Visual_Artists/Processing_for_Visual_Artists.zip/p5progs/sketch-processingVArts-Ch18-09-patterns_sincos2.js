// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: sincos2.pde in Ch18
// Chapter: Ch18-09 patterns Figure 18.39
// Description: Green stop sign made with sin() and cos()
//
function setup() {
	createCanvas(600, 400);
	background(177, 224, 214);

	let  centerx = 300;
	let  centery = 200;
	let  r = 150;

	fill(79, 168, 81);
	beginShape();
		for (let i=0; i<8; i++) {
			let  angle = map(i, 0, 8, 0, 360);
			let  x = r * cos(radians(angle));
			let  y = r * sin(radians(angle));
			x += centerx;
			y += centery;
			vertex(x,y);
		}
	endShape(CLOSE);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch18-09-patterns_sincos2.jpg')
}


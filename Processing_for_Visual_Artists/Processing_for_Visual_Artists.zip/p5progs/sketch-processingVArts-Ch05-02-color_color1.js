// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: color1.pde in Ch05
// Chapter: Ch05-02 color No Figure
// Description: Background color as a variable
//

let Redval = 192;
let Grnval = 64;
let Bluval = 0;
let MyColor;

function setup() {
   createCanvas(600, 400);
   MyColor = color(Redval, Grnval, Bluval);
   background(MyColor);
}

function draw() {
   Redval = Redval+1;
   if (Redval > 255) Redval=0;
   MyColor = color(Redval, Grnval, Bluval);
   background(MyColor);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch05-02-color_color1.jpg')
}


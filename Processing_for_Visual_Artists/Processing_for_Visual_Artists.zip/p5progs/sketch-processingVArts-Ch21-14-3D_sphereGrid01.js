// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: sphereGrid01.pde in Ch21
// Chapter: Ch21-14 3D Figure 21.17
// Description: changing sphereDetail
//


function setup() {
  createCanvas(600, 600, WEBGL);
}

function draw(){
	background(225, 192, 145);
	translate(-300, -300, 0);	
	stroke(150);
	line(-300,0,300,0);
	line(0,-300,0,300);
	directionalLight(255, 255, 255, -1, 0, -1);
	perspective(PI / 3.0, width / height, 0.1, 500);
	fill(128, 183, 135);
	drawPicture();
}

function drawPicture(){
	let xSteps = 5;
	let ySteps = 5;
	for (let y = 0; y < ySteps; y++) {
		for (let x = 0; x < xSteps; x++) {
			let xAlpha = float(x / (xSteps - 1.0));
			let yAlpha = float(y / (ySteps - 1.0));
			let xPos = lerp(100, 500, xAlpha);
			let yPos = lerp(100, 500, yAlpha);
			let latRes = int(lerp(3, 24, xAlpha));
			let longRes = int(lerp(3, 24, yAlpha));
			//print(x, y, xAlpha, yAlpha, xPos, yPos, latRes, longRes);
			push();
				translate(xPos, yPos, 0);
				sphere(40, latRes, longRes);
			pop();
		}
	}
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch21-14-3D_sphereGrid01.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: pixels01.pde in Ch16
// Chapter: Ch16-08 images Figure 16.13
// Description: skeleton for setting image pixels
//
let WindowSize = 400; 

function setup() {
	createCanvas(WindowSize, WindowSize);
}

function draw() {
	background(0);
	let color0 = color(35, 160, 255);
	let color1 = color(255, 116, 0);
	for (let y=0; y<height; y++) {
		for (let x=0; x<width; x++) {
			// do something here with get() and set()
		}
	}
}

//
function keyTyped(){
	if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch16-08-images_pixels01.jpg')
}


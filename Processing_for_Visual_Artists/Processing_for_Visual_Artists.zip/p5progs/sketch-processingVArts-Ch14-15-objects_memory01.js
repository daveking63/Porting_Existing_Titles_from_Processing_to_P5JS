// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: memory01.pde in Ch14
// Chapter: Ch14-15 objects No Figure
// Description: Object program demonstrating the memory management of objects - no display
//
function setup() {
   createCanvas(600,400);
   background(200);
   let msg = "See console for results";
   textSize(30);
   text(msg,150,200);
   let a = 3;
   let b = 100;
   b = a;
   print("just assigned b=a. a = "+a+", b = "+b);
   b = 15;
   print("just assigned to b.  a = "+a+", b = "+b);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch14-15-objects_memory01.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: recurbox04.pde in Ch10
// Chapter: Ch10-11 recursion Figure 10.13
// Description: recursively drawn (side by side) rectangles of 'random'ly specified sizes and rgb colors
//
function setup() {
   createCanvas(600, 400);
   noStroke();
   handleBox(0, 0, 600, 400, color(128, 128, 128));
}

function handleBox(ulx, uly, wid, hgt, clr) {
   fill(clr);
   rect(ulx, uly, wid, hgt);
   let  minSide = 20;
   if ((wid < minSide) || (hgt < minSide)) {
      return;
   }
   if (wid > hgt) {
      let leftWid = wid * random(0.25, 0.75);  // width of the left box
      handleBox(ulx, uly, leftWid, hgt, wiggleColor(clr, -20, -10));
      handleBox(ulx+leftWid, uly, wid-leftWid, hgt, wiggleColor(clr, 10, 20));
   } else {
      let topHgt = hgt * random(0.25, 0.75);  // height of the top box
      handleBox(ulx, uly, wid, topHgt, wiggleColor(clr, -20, -10));
      handleBox(ulx, uly+topHgt, wid, hgt-topHgt, wiggleColor(clr, 10, 20));
   }
}

function wiggleColor(clr, lo, hi) {
   let  newclr = color(red(clr)+random(lo, hi), green(clr)+random(lo, hi), blue(clr)+random(lo, hi));
   return (newclr);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch10-11-recursion_recurbox04.jpg')
}


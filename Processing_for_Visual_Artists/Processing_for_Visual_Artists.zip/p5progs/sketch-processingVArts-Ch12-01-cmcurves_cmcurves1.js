// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: cmcurves1.pde in Ch12
// Chapter: Ch12-01 cmcurves Figure 12.1
// Description: Curve skeleton showing curve patterns
//
function setup() {
   createCanvas(600, 400);
   background(242, 240, 174);
   noFill();
}

function draw() {
   stroke(0);
   let x0 = 100;  let y0 = 100;
   let x1 = 300;  let y1 = 100;
   let x2 = 300;  let y2 = 300;
   let x3 = 100;  let y3 = 300;
   ellipse(x0, y0, 15, 15);
   ellipse(x1, y1, 15, 15);
   ellipse(x2, y2, 15, 15);
   ellipse(x3, y3, 15, 15);
   // and now do some curve drawing
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch12-01-cmcurves_cmcurves1.jpg')
}


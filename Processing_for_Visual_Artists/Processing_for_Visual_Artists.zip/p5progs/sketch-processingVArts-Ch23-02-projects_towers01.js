// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: towers01.pde in Ch23
// Chapter: Ch23-02 projects Figure 23.5
// Description: world of cylindrical towers
//
let NumTowers = 1500;    // the total number of towers to draw
let MinStartD = 0.05;  // distance to the base of the innermost tower
let MaxStartD = 0.2;   // distance to the base of the outermost tower

let Xoffset = .5;     // center X location (as a percent of the window) of the vent
let Yoffset = .5;      // center Y location (as a percent of the window) of the vent

function setup() {
	createCanvas(600, 600);
	smooth();
	noStroke();
	background(0);
	drawTowers();
}

function drawTowers() {

	let origin = createVector(Xoffset*width, Yoffset*height);
	for (let i=0; i<NumTowers; i++) {
		let  alfa = i*1.0/(NumTowers-1);
		alfa = 1-cos(radians(90*alfa)); 
		let  startDistancePercent = lerp(MaxStartD, MinStartD, alfa);
		drawTower(startDistancePercent, origin);
	}
}

function drawTower(startDistancePercent, origin) {
	let start;
	let end;
	let farRadius, nearRadius;
	let clr;
	let direction;
	let  normDist;
	let base0, base1;

	let  windowRadius = dist(0, 0, width, width)/2;
	let  distToStart = startDistancePercent * windowRadius;
	let  distToEnd = 5*distToStart;
	  
	direction = createVector(random(-1, 1), random(-1, 1));
	direction.normalize();
	start = createVector(origin.x + distToStart * direction.x, origin.y + distToStart * direction.y);
	end   = createVector(origin.x + distToEnd   * direction.x, origin.y + distToEnd   * direction.y);

	normDist = norm(startDistancePercent, MinStartD, MaxStartD);
	farRadius = width/100.0;
	nearRadius = lerp(farRadius*10, farRadius, normDist);

	base0 = color(226, 105, 8);
	base1 = color(27, 205, 226);
	let  dr = 25;
	base0 = color(red(base0)+(dr*random(-1, 1)), green(base0)+(dr*random(-1, 1)), blue(base0)+(dr*random(-1,1)));
	base1 = color(red(base1)+(dr*random(-1, 1)), green(base1)+(dr*random(-1, 1)), blue(base1)+(dr*random(-1,1)));
	clr = lerpColor(base0, base1, normDist);

	let numSteps = width/4;
   	for (let step=0; step<numSteps; step++) {
		let  alfa = step*1.0/(numSteps-1);
		let drawStroke = (random(0, 1000) > 900) ;
		if (step == numSteps-1) drawStroke = true;

		let  rHere = lerp(farRadius, nearRadius, alfa);
		let  xHere = lerp(start.x, end.x, alfa);
		let  yHere = lerp(start.y, end.y, alfa);

		let  bigr = rHere * 1.2;
		fill(0, 0, 0, 16);
		noStroke();
		ellipse(xHere, yHere, bigr, bigr);
		        
		fill(clr);
		if (drawStroke) stroke(0); else noStroke();
		ellipse(xHere, yHere, rHere, rHere);
   }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch23-02-projects_towers01.jpg')
}


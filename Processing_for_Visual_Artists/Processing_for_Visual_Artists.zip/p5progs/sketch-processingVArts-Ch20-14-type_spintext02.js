// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: spintext02.pde in Ch20
// Chapter: Ch20-14 type Figure 20.17
// Description: displaying a message one character at a time
//

let myFont;
function preload(){
	myFont = loadFont("data/AvenirNextLTPro-Demi.otf"); 
}

function setup() 
{
	createCanvas(600, 400);
	textFont(myFont);
	textSize(36);
}

function draw() {
	fill(199, 172, 115);
	background(89, 9, 21);
	let message = "Pomegranate and lime juice ";
	for (let i=0; i<message.length; i++) {
		let thisChar = message.charAt(i);
		text(thisChar, 10+(10*i), 200+(10*i));
	}
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch20-14-type_spintext02.jpg')
}


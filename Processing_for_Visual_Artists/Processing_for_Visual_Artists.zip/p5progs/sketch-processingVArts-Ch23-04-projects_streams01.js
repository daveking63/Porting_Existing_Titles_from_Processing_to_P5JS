// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: streams01.pde in Ch23
// Chapter: Ch23-04 projects Figure 23.9
// Description: streams created by drops of water running down hill
//
let  TopoMap = [];

function setup() {
   createCanvas(600, 400);
   //TopoMap = new float[height][width];
   initTopoMap();
   background(0);
   drawTopoMap();
}

function draw() {
   let numDropsToFollow = 50;
   for (let i=0; i<numDropsToFollow; i++) {
      drawOneDrop();
   }
}

function initTopoMap() {
	for (let y=0; y<height; y++) {
	TopoMap[y] = [];
		for (let x=0; x<width; x++) {
		 	TopoMap[y][x] = noise(x*.01, y*.01);
		}
	}
}

// draw the topo map in blue isobands
function drawTopoMap() {
   background(0);
   for (let y=0; y<height; y++) {
      for (let x=0; x<width; x++) {
         let  v = TopoMap[y][x];
         let vphase = int(v/.1);
         if (vphase%2 == 0) set(x, y, color(0, 0, 192));
         else set(x, y, color(0, 0, 128));
      }
   }
}

function drawOneDrop() {
	// pick a color for this drop 
	let  rval = random(100, 255);
	let  gval = random(100, 255);
	let  bval = random(20, 150);
	stroke(rval, gval, bval, 32);
	noFill();

	// pick a random polet on the window to start from
	let center = createVector(random(0, width), random(0, height));

	// as long as we don't have a reason to stop, keep moving
	let motion = createVector(0, 0);
	let stepCount = 0;
	let updateAgain = true;
	while (updateAgain) {
		let searchRadius = 7;

		let  minx = center.x;
		let  miny = center.y;
		let  minv = 999;

		// find the smallest value in a circle around the current center
		let angleSteps = round(12 * searchRadius);
		for (let i=0; i<angleSteps; i++) {
			let  theta = map(i, 0, angleSteps-1, 0, TWO_PI);
			let px = round(center.x + (searchRadius * cos(theta)));
			let py = round(center.y + (searchRadius * sin(theta)));
			if ((px<0) || (px >= width-1) || (py<0) || (py >= height-1)) continue;
			let  v = TopoMap[py][px];
			if (v < minv) { minv = v;  minx = px;  miny = py; }
		}

		// move 1 unit in that direction and draw a short line behind us
		motion.x = minx-center.x;
		motion.y = miny-center.y;
		motion.normalize();

		line(center.x, center.y, center.x+motion.x, center.y+motion.y);
		center.x += motion.x;
		center.y += motion.y;

		// stop if we're not moving, off screen, or have taken too many steps
		if (mag(motion.x, motion.y) < 0.01) updateAgain = false;
		if ((center.x < 0) || (center.x >= width) || (center.y < 0) || (center.y >= height)) updateAgain = false;
		if (++stepCount > width*2) updateAgain = false;
	}
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch23-04-projects_streams01.jpg')
}


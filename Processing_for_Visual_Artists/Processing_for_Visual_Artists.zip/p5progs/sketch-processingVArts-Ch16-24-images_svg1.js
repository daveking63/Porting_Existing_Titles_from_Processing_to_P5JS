// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: svg1.pde in Ch16
// Chapter: Ch16-24 images Figure 16.31
// Description: drawing an SVG file
//

let s;

function preload(){
	s = loadImage("data/lamp.svg");
}

function setup() {
  createCanvas(350, 500);
  smooth();
  image(s,50,50);
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch16-24-images_svg1.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: circle04.pde in Ch11
// Chapter: Ch11-04 random Figure 11.4
// Description: display random pattern of randomly colored circles
//
function setup() {
	createCanvas(600, 400);
	background(150, 90, 65);
	fill(250, 200, 90);

	let numCircles = 30;

	for (let count=0; count<numCircles; count++) {
		let  redval = random(0, 256);
		let  grnval = random(0, 256);
		let  bluval = random(0, 256);
		fill(redval, grnval, bluval);

		let  radius = random(10, 40);
		let  xCenter = random(radius, width-radius);
		let  yCenter = random(radius, height-radius);
		ellipse(xCenter, yCenter, radius*2, radius*2);
	} 
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch11-04-random_circle04.jpg')
}


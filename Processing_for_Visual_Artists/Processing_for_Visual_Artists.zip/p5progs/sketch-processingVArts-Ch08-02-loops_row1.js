// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: row1.pde in Ch08
// Chapter: Ch08-02 loops Figure 8.4
// Description: setup drawing a row of yellow ellipses (circles) on blue rectangle
//
function setup() {
   createCanvas(600, 250);
}

function draw() {
   background(200);
   fill(47, 64, 84);
   rect(25, 50, 550, 140);
   
   fill(249, 246, 155);
   ellipse (80, 120, 80, 80);
   ellipse(190, 120, 80, 80);
   ellipse(300, 120, 80, 80);
   ellipse(410, 120, 80, 80);
   ellipse(520, 120, 80, 80);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch08-02-loops_row1.jpg')
}


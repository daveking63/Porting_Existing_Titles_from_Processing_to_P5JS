// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: circlefill01.pde in Ch18
// Chapter: Ch18-19 patterns No Figure
// Description: skeleton program for circle packing 
//
function setup() {
	createCanvas(600, 600);
	background(0);
	smooth();
	stroke(255);
	textSize(30);
    text('Intentionally left blank',140,300);
}

class Disk {
   constructor(acenter, aradius, aclr) {
      this.center = createVector(acenter.x, acenter.y);
      this.radius = aradius;
      this.clr = color(aclr);
   }

   render(drawStroke, drawFill) {
      noFill();
      noStroke();
      if (drawFill) fill(clr);
      if (drawStroke) stroke(clr);
      ellipse(this.center.x, this.center.y, 2*this.radius, 2*this.radius);
   }
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch18-19-patterns_circlefill01.jpg')
}


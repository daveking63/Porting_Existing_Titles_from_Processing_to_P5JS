// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: arraybug1.pde in Ch11
// Chapter: Ch11-11 random Figure 11.11
// Description: drawing ellipses with a global array of different diameters at y different x's where some y's are out of bounds
//
function setup() {
   createCanvas(600, 400);
   background(2, 59, 71);
   fill(155, 226, 242);
   noStroke();
}

let Diameters = [30, 50, 90, 20, 44, 76, 22, 30];

function draw() {
   let xpos = 50;
   for (let i=0; i<8; i++) {
      ellipse(xpos, 100, Diameters[i], Diameters[i]);
      xpos += (Diameters[i]/2.0) + 20 + (Diameters[i+1]/2.0);
   }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch11-11-random_arraybug1.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: bouncer1.pde in Ch20
// Chapter: Ch20-12 type Figure 20.15
// Description: bouncing type
//

let myFont;
function preload(){
	myFont = loadFont("data/AvenirNextLTPro-Demi.otf"); 
}

function setup() {
	createCanvas(600, 400);
	smooth();
	textAlign(CENTER);
	textFont(myFont);
	textSize(48);
	fill(207, 113, 53);
}

function draw() {
	background(31, 35, 71);
	let  sinVal = sin(frameCount * .07);
	let  scaleMul = map(sinVal, -1, 1, .5, 2);
	translate(300, 200);
	scale(scaleMul);
	text("Delicious apricots!", 0, 0);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch20-12-type_bouncer1.jpg')
}


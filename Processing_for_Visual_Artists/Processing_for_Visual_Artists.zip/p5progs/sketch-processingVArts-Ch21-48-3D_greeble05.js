// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: greeble05.pde in Ch21
// Chapter: Ch21-48 3D Figure 21.57
// Description: greeble 3D grid consisting of multiple greebles with random y rotation
//

let Window = 600;
let GridX = 13;
let GridZ = 10;
let Ggrid = [];

class Greeble {
	constructor(x, z) {
		this.tx = x-(GridX/2.0);
		this.tz = z-(GridZ/2.0);    
		this.i4 = int(random(0, 1000))%4;
		this.angleY = radians(this.i4*90);
		this.angleZ = radians(3.0*(x-(GridX/2.0)));
	}

	render() {
		push();
			translate(this.tx, 0, this.tz);
			translate(.5, 0, .5);
			rotateZ(this.angleZ);
			rotateY(this.angleY);
			translate(-.5, 0, -.5);

			drawBox(.5, -.1, .5, 1, .1, 1);
			drawSphere(.4, 0, .35, .2);
			drawBox(.3, 0, .05, .2, .1, .1);
			drawBox(.25, 0, .75, .2, .05, .15);
			drawBox(.75, 0, .25, .1, .1, .1);
			drawBox(.75, 0, .4, .1, .1, .1);
			drawBox(.75, 0, .55, .1, .1, .1);
			drawBox(.9,  0, .8,  .2, .15, .25);
			drawBox(.55, 0, .8,  .08, .2, .22);
		pop();
	}
}

function setup(){
	createCanvas(600, 600, WEBGL);
	smooth();
	for (let z=0; z<GridZ; z++) {
		Ggrid[z] = [];
		for (let x=0; x<GridX; x++) {
			Ggrid[z][x] = new Greeble(x, z);
		}
	}
}

function draw() {
	background(25, 42, 51);
	//translate(Window/2.0, Window/2.0, -400.0);
	translate(-50, -50, -400.0);
	scale(Window, -Window, Window);
	lights();

	noStroke();
	fill(255, 255, 200);
	rotateX(radians(35));
	let gScale = 0.2;
	scale(gScale);

	for (let iz=0; iz<GridZ; iz++) {
		//Ggrid[iz] = [];
		for (let ix=0; ix<GridX; ix++) {
			Ggrid[iz][ix].render(); 
		}
	}
}

function drawSphere( cx,  cy,  cz,  r)
{
   push();
   translate(cx, cy, cz);
   sphere(r);
   pop();
}

function drawBox( cx,  cy,  cz,  dx,  dy,  dz)
{
   push();
   translate(cx, cy+(dy/2.0), cz);
   box(dx, dy, dz);
   pop();
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch21-48-3D_greeble05.jpg')
}


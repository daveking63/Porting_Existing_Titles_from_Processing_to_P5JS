// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: puppetshow01.pde in Ch23
// Chapter: Ch23-05 projects Figure 23.10
// Description: puppet theater version of an ocean at night
//

let NumLayers = 4;
let LayerImage = [];
let LayerShadow = [];
let MotionRadius = 10;
let blurSrc = [];
let blurDst = [];

// starry sky: http://www.sxc.hu/photo/1005288
// mooon: http://www.sxc.hu/photo/1115121
let ImgBackground;

function preload(){
	ImgBackground = loadImage("data/nightbg01.png");
}

function setup() {
	createCanvas(600, 400);
	for (let layer=0; layer<NumLayers; layer++) {
		makeLayer(layer);
	}
}

function draw() {
	image(ImgBackground, 0, 0);
	for (let layer=0; layer<NumLayers; layer++) {
		let distanceFromBack = (NumLayers-1)-layer;
		let  angleAtBack = 2.5 * frameCount;
		let  theta = radians(angleAtBack) + (1.3 * layer);
		let  radius = MotionRadius * pow(.8, distanceFromBack);
		let  xoff = radius * cos(theta);
		let  yoff = (layer * 20) + (radius * abs(sin(theta)));
		image(LayerShadow[layer], (-MotionRadius)+xoff, (-MotionRadius)+yoff);
		image(LayerImage[layer], (-MotionRadius)+xoff, (-MotionRadius)+yoff);
	}
}

function makeLayer(layer) {
	let layerWidth = round(width + (2.5*MotionRadius));
	let layerHeight = round(height + (2.5*MotionRadius));

	let thisMask = createGraphics(layerWidth, layerHeight);
	LayerShadow[layer] = createGraphics(layerWidth, layerHeight);
	LayerImage[layer] = createGraphics(layerWidth, layerHeight);

	LayerShadow[layer].loadPixels();
	LayerImage[layer].loadPixels();

	// create the mask.  0=transparent, 255=opaque
	//thisMask.beginDraw();
	thisMask.background(0, 255); // start completely opaque
	//thisMask.smooth();
	thisMask.noStroke();
	thisMask.fill(255, 255);     // draw = erase opacity

	let  circleYLine = layerHeight * 0.6;
	thisMask.rect(0, 0, layerWidth, circleYLine);

	let  minRadius = layerHeight/10.0;
	let  maxRadius = layerHeight/7.0;
	let  radius = random(minRadius, maxRadius);
	let  xCenter = -random(0, radius);
	while (xCenter-radius < layerWidth) {
		let  yCenter = circleYLine + ((radius/4.0) *lerp(-1, 1, random(0,1)));
		thisMask.ellipse(xCenter, yCenter, radius*2, radius*2);
		xCenter += radius;
		radius = random(minRadius, maxRadius);
		xCenter += random(.25, .9)*radius;
	} //while
   //thisMask.endDraw();

	// create the shadow: black with alpha
	// the let  array is 1 for black (shadow), else 0
	for (let y=0; y<layerHeight; y++) {
		blurSrc[y] = [];
		for (let x=0; x<layerWidth; x++) {
			let c = thisMask.get(x, y);
			blurSrc[y][x] = red(c)/255.0;
		}
	}

	let numPasses = 1;
	let blurRadius = 8;
	for (let pass=0; pass<numPasses; pass++) {
		for (let y=0; y<layerHeight; y++) {
			blurDst[y] = [];
			for (let x=0; x<layerWidth; x++) {
				let ixlo = max(0, x-blurRadius);
				let ixhi = min(layerWidth, x+blurRadius);
				let iylo = max(0, y-blurRadius);
				let iyhi = min(layerHeight, y+blurRadius);
				let numAdded = 0;   
				let  blurSum = 0;
				for (let iy=iylo; iy<iyhi; iy++) {
					for (let ix=ixlo; ix<ixhi; ix++) {
						blurSum += blurSrc[iy][ix];
						numAdded++;
					}
				}
				if (numAdded == 0) numAdded = 1;
				blurDst[y][x] = blurSum/numAdded;
			}
		}				
   
	// copy dst back into src to prepare for next pass
		for (let y=0; y<layerHeight; y++) {
			for (let x=0; x<layerWidth; x++) {
				blurSrc[y][x] = blurDst[y][x];
			}
		}
	}

   //LayerShadow[layer].beginDraw();
	for (let y=0; y<layerHeight; y++) {
		for (let x=0; x<layerWidth; x++) {
			let  blurVal = blurDst[y][x];
			LayerShadow[layer].set(x, y, color(0, 0, 0, 255*(1-blurVal)));
		}
	}
   //LayerShadow[layer].endDraw();

   // draw the image
   let c0 = color(255, 255, 255);
   let c1 = color(0, 0, 255);
	//LayerImage[layer].beginDraw();
	for (let y=0; y<layerHeight; y++) {
		for (let x=0; x<layerWidth; x++) {
			let  a = noise((x+(layerWidth*layer))*.02, (y+(layerHeight*layer))*.02);
			let maskColor = thisMask.get(x, y);
			let  opacity = 255 - red(maskColor);
			let imgColor = lerpColor(c0, c1, a);
			imgColor = color(red(imgColor), green(imgColor), blue(imgColor), opacity);
			LayerImage[layer].set(x, y, imgColor);
		}
	}
	//LayerImage[layer].endDraw();
	LayerShadow[layer].updatePixels();
	LayerImage[layer].updatePixels();
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch23-05-projects_puppetshow01.jpg')
}


// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: type05.pde in Ch20
// Chapter: Ch20-05 type Figure 20.7
// Description: fitting type to a box
//

function preload(){
	myFont = loadFont("data/AvenirNextLTPro-Demi.otf"); 
}

function setup() {
   createCanvas(600, 400);
   background(92, 39, 44);
   fill(232, 200, 72);     // draw in yellow
   textFont(myFont);      // make myFont the active font
   textSize(48);
   let message = "Blueberry Pie is a delicious summertime treat!";
   text(message, 50, 100, 500, 200);
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch20-05-type_type05.jpg')
}


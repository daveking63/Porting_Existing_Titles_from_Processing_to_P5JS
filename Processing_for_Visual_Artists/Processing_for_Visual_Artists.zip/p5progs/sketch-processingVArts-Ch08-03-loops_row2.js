// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: row2.pde in Ch08
// Chapter: Ch08-03 loops Figure 8.5
// Description: drawing a row of yellow ellipses on blue rectangle using 'while' loop
//
function setup() {
   createCanvas(600, 250);
}

function draw() {
   background(200);
   fill(47, 64, 84);
   rect(25, 50, 550, 140);
   
   fill(249, 246, 155);
   let  xValue = 80;
   let  ellipseNumber = 0; 
   while (ellipseNumber < 5) {
      ellipse(xValue, 120, 80, 80);
      ellipseNumber = ellipseNumber + 1;
      xValue = xValue + 110;
   }
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch08-03-loops_row2.jpg')
}


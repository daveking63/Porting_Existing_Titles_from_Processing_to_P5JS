// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: bigcurve4.pde in Ch12
// Chapter: Ch12-12 cmcurves Figure 12.16
// Description: New curve project with smooth curve correctly touching multiple points
//
let NumPoints = 8;
let Xp = [];
let Yp = [];

function setup() {
   createCanvas(600, 400);
   background(194, 216, 242);
   noFill();
   for (let i=0; i<NumPoints; i++) {
      Xp[i] = random(100, 500);
      Yp[i] = random(100, 300);
   }
}

function draw() {
   for (let i=0; i<NumPoints; i++) {
      ellipse(Xp[i], Yp[i], 10, 10);
   }
   for (let i=0; i<NumPoints; i++) {
      let p0 = (i  )%NumPoints;
      let p1 = (i+1)%NumPoints;
      let p2 = (i+2)%NumPoints;
      let p3 = (i+3)%NumPoints;
      //println("p0="+p0+ " p1="+p1+" p2="+p2+" p3="+p3);
      curve(Xp[p0], Yp[p0], Xp[p1], Yp[p1], Xp[p2], Yp[p2], Xp[p3], Yp[p3]);
   }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch12-12-cmcurves_bigcurve4.jpg')
}


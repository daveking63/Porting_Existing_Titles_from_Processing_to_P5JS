// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: blob12.pde in Ch19
// Chapter: Ch19-20 lamp Figure 19.35
// Description: multiple spherical blobs encapsulated by an isoband created using blob array
//
let Img;
let Temperature = [];
let MinBlobVal = 0.01831564; 
let Wax = [];

function setup() {
	createCanvas(600, 400);
	Img = createImage(width, height, RGB);

	makeWax();

	zeroTemperature();
	for (let i=0; i<Wax.length; i++) {
		Wax[i].render();
	}

	Img.loadPixels();
	buildImage();
	Img.updatePixels();
	image(Img, 0, 0);
}

function draw() {
}

function makeWax() {
	Wax[0] = new Blob(300, 200, 100);
	Wax[1] = new Blob(400, 230, 75);
	Wax[2] = new Blob(145, 270, 210);
}

function zeroTemperature() {
	for (let y=0; y<height; y++) {
		Temperature[y] = [];
		for (let x=0; x<width; x++) {
			Temperature[y][x] = 0;
		}
	}
}

function buildImage() {
	for (let y=0; y<height; y++) {
		for (let x=0; x<width; x++) {
			let  midT = 0.4;
			let  rangeT = 0.05;
			if (abs(Temperature[y][x] - midT) < rangeT) {
				Img.set(x, y, color(255, 0, 0));
			} else {
				let  t = map(Temperature[y][x], 0, 1.5, 0, 255);
				Img.set(x, y, color(t, t, 0));
			}
		}
	}
}

class Blob {
	constructor(acx, acy, ar) {
		this.cx = acx;
		this.cy = acy;
		this.r = ar;
   }

	render() {
		let lox = max(0, int(this.cx-this.r));
		let hix = min(width, int(this.cx+this.r));
		let loy = max(0, int(this.cy-this.r));
		let hiy = min(height, int(this.cy+this.r));
		for (let y=loy; y<hiy; y++) {
			for (let x=lox; x<hix; x++) { 
				let  d2 = sq(x-this.cx)+sq(y-this.cy);
				if (d2 > this.r*this.r) continue;
				let  d = sqrt(d2);
				let  h = map(d, 0, this.r, 1, 0);
				let  v = exp(-4*h*h);
				v = map(v, 1, MinBlobVal, 0, 1); 
				Temperature[y][x] += v;
			}
		}
	}
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch19-20-lamp_blob12.jpg')
}


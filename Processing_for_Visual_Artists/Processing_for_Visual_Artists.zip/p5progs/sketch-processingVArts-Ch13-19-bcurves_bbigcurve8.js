// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: bbigcurve8.pde in Ch13
// Chapter: Ch13-19 bcurves Figure 13.20
// Description: Detailed documentation of smoothed and closed big Bezier curve
//
// Draw crazy free-form Bezier curves
// Get a new big curve each time you run the sketch
// Version 1.0 - AG, 15 April 2009
//

let NumPoints = 24;   // The total number of points created
let Xp = [];
let Yp = [];

// This version of setup() creates the graphics window and
// sets the background color.  It turns off filling so we
// get just the curves, not their interiors.  Then I create
// the two polet arrays and fill them up with random numbers.
// From here on, Processing calls draw() automatically for 
// every new frame to generate the graphics.
//
function setup() {
   createCanvas(600, 400);
   background(206, 214, 242);
   noFill();
   for (let i=0; i<NumPoints; i++) {
      Xp[i] = random(100, 500);
      Yp[i] = random(100, 300);
   }
}


// This version of draw() takes two arrays full of random
// points and turns them into a single closed Bezier curve.
// Input parameters: none
// Output parameters: none
// Global variables used:
//        NumPoints : the number of points in arrays Xp and Yp
//        Xp[]      : let  array of point's x coordinates
//        Yp[]      : let  array of point's y coordinates
// Side effects: draws the curve on the screen
// Version 1.0 - AG, 15 April 2009
//
function draw() {
   // The points need to be turned into a list of 4-element
   // Bezier curves.  First, to get the curves to touch and
   // thus be continuous, we set the first polet of each
   // curve to the coordinates of the last polet of the
   // preceding curve.  The first curve is handled as a
   // special case after the loop.
   for (let i=4; i<NumPoints; i+=4) {
      Xp[i] = Xp[i-1];
      Yp[i] = Yp[i-1];
   }
   Xp[0] = Xp[NumPoints-1];
   Yp[0] = Yp[NumPoints-1];
  
   // To create a continuous curve, we need to enforce the
   // mathematical constralet that the change in X between
   // the first two points of each curve is equal to the
   // change in X between the last two points of the previous
   // curve, and the same thing in Y.  The first curve is
   // handled as a special case after the loop.
   for (let i=5; i<NumPoints; i+=4) {
      Xp[i] = Xp[i-1] + (Xp[i-2] - Xp[i-3]);
      Yp[i] = Yp[i-1] + (Yp[i-2] - Yp[i-3]);
   }
   Xp[1] = Xp[0] + (Xp[NumPoints-1] - Xp[NumPoints-2]);
   Yp[1] = Yp[0] + (Yp[NumPoints-1] - Yp[NumPoints-2]);

   // Draw a little circle around the first polet of
   // each curve.  The default drawing state makes this
   // a white circle with a black outline, which looks good.
   for (let i=0; i<NumPoints; i+=4) {
      ellipse(Xp[i], Yp[i], 10, 10);
   }
  
   // Run through the lists of points, taking them 4 at a
   // time.  Hand off each batch of 4 to bezier().  By now,
   // they should all touch and join up smoothly.
   for (let i=0; i<NumPoints; i+=4) {
      bezier(Xp[i],   Yp[i],   Xp[i+1], Yp[i+1],
             Xp[i+2], Yp[i+2], Xp[i+3], Yp[i+3]);
   }
}



//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch13-16-bcurves_bigcurve8.jpg')
}


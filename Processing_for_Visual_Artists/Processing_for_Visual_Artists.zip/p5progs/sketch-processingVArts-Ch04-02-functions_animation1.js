// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: animation1.pde in Ch04
// Chapter: Ch04-02 functions Figure 4.2
// Description: Display Background
//
function setup() {
   createCanvas(600, 400);
   let redval = 192;
   let grnval = 64;
   let bluval = 0;
   background(redval, grnval, bluval);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch04-02-functions_animation1.jpg')
}


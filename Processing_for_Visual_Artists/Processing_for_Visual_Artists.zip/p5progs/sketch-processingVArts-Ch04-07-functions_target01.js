// Source: Processing for Visual Artists
// Artist: Andrew Glassner
// Source: book - rewrite of .pde code at https://github.com/apress/processing
// Date: 2011
// PDE Source: target01.pde in Ch04
// Chapter: Ch04-07 functions Figure 4.5
// Description: Draw bulls-eye target (ball) size set by score
//

let radius, redval, grnval, bluval;

function setup() {
   createCanvas(600, 400);
   background(87, 66, 8);
   noStroke();
   let score = 40;   // the score of this arrow

   // draw the ball for the current value of score
   if (score == 40) {
      drawBall(160, 212, 20, 20);
   } else if (score == 30) {
      drawBall(80, 231, 48, 3);
   } else if (score == 20) {
      drawBall(40, 255, 93, 8);
   } else if (score == 10) {
      drawBall(20, 255, 140, 5);
   } else {
      drawBall(180, 32, 32, 32);
   }
}

function drawBall(radius, redval, grnval, bluval) {
   fill(color(redval, grnval, bluval));
   ellipse(300, 200, 2*radius, 2*radius);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-processingVArts-sketch-Ch04-07-functions_target01.jpg')
}


// Source: Visualizing Data
// Artist: Ben Fry
// SourceType: Book & https://benfry.com/writing/archives/3/
// Date: 2008
// PDE: step01_fig1_red_dots.pde
// Chapter: Ch03-01, Mapping, Figure 3-1
// Description: US map of the states with the center of each state demarcated by a small red circle/dot


let mapImage;
let locationTable;
let rowCount;

function preload(){
	mapImage = loadImage("data/map.png");
	locationTable = loadTable("data/locations.tsv","tsv");
	dataTable = loadTable("data/random.tsv","tsv");
}

function setup() {
	createCanvas(640, 400);	
	rowCount = locationTable.getRowCount();
	noLoop();
}


function draw() {
	background(255);
	image(mapImage, 0, 0);
	smooth();
	fill(192, 0, 0);
	noStroke();
	
	for (let r = 0; r < rowCount; r++) {
		let x = float(locationTable.getNum(r,1));
		let y = float(locationTable.getNum(r,2));
		circle(x, y, 9, 9);
	}
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-visData-ch03-step01_fig1_red_dots.jpg')
}

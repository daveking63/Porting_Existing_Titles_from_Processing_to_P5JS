// Source: Visualizing Data
// Artist: Ben Fry
// SourceType: Book & https://benfry.com/writing/archives/3/
// Date: 2008
// PDE: step06_fig6_two_sided_range.pde
// Chapter: Ch03-06, Mapping, Figure 3-6
// Description: US map of the states with each state containing a circle who diameter varies by magnitude of data value and whose color indicates whether the data value is positive (blue) or negative (red) value

let mapImage;
let locationTable;
let dataTable;
let dataMin = 20.0;
let dataMax = -20.0;
let rowCount;

function preload(){
	mapImage = loadImage("data/map.png");
	locationTable = loadTable("data/locations.tsv","tsv");
	dataTable = loadTable("data/random.tsv","tsv");
}

function setup() {
	createCanvas(640, 400);	
	rowCount = locationTable.getRowCount();
	// Find the minimum and maximum values
	for (let r = 0; r < rowCount; r++) {
		let value = float(dataTable.getNum(r,1));
		if (value > dataMax) {
			dataMax = value;
		}
		if (value < dataMin) {
			dataMin = value;
		}
	}
	noLoop();
}


function draw() {
	background(255);
	image(mapImage, 0, 0);
	smooth();
	fill(192, 0, 0);
	noStroke();
	
	for (let r = 0; r < rowCount; r++) {
		let abbrev = dataTable.getString(r,0);
		let row = locationTable.findRow(abbrev,0);
		let x = float(row.getNum(1));
		let y = float(row.getNum(2));
		drawData(x, y, abbrev);
  	}
  	noLoop;
}


// Map the size of the ellipse to the data value
function drawData(x, y, abbrev) {
	// Get data value for state
	let row = dataTable.findRow(abbrev,0);
	let value = float(row.getNum(1));
	let diameter, highClr, lowClr;
	if (value >= 0){
		diameter = float(map(value, 0, dataMax, 3, 30));
		highClr = color('#333366');
		fill(highClr);
	} else {
		diameter = float(map(value, 0, dataMin, 3, 30));
		lowClr = color('#ec5166');
		fill(lowClr);
	}
	circle(x, y, diameter);
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-visData-ch03-step06_fig6_two_side_range.jpg')
}

// Source: Visualizing Data
// Artist: Ben Fry
// SourceType: Book & https://benfry.com/writing/archives/3/
// Date: 2008
// PDE: figure_07a-c_shapes.pde
// Chapter: Ch04-07, Mapping, Figure 4-7
// Description: Shapes defined by beginShape-endShape with different fill, stroke & closure.

function setup(){
	createCanvas(400,150);
	smooth();
	background(240);
    
    //Shape 7a - no fill, default stroke, and open shape
	push();
		translate(20,20);
		noFill();
		beginShape();
			vertex(10, 10);
			vertex(90, 30);
			vertex(40, 90);
			vertex(50, 40);
		endShape();
	pop();
	
	//Shape 7b - white fill, black stroke, and open shape
	push();
		translate(150,20);
		fill(255);
		stroke(0);
		beginShape();
			vertex(10, 10);
			vertex(90, 30);
			vertex(40, 90);
			vertex(50, 40);
		endShape();
	pop();
	
	////Shape 7c - white fill, black stroke, and closed shape
	push(); 
		translate(280,20);
		fill(255);
		stroke(0);  
		beginShape();
			vertex(10, 10);
			vertex(90, 30);
			vertex(40, 90);
			vertex(50, 40);
		endShape(CLOSE);
	pop();
  
}
 
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-visData-ch04-figure_07a-c_shapes.jpg')
}

// Source: Visualizing Data
// Artist: Ben Fry
// SourceType: Book & https://benfry.com/writing/archives/3/
// Date: 2008
// PDE: step010_single_rollover.pde
// Chapter: Ch03-10, Mapping, No Figure
// Description: US map of the states with state name and value displayed when mouse passed near a state's circle - improved version

let mapImage;
let locationTable;
let dataTable;
let dataMin = 20.0;
let dataMax = -20.0;
let rowCount;
let font;
let tSize = 12;

let closestDist;
let closestText;
let closestTextX;
let closestTextY;

function preload(){
	mapImage = loadImage("data/map.png");
	locationTable = loadTable("data/locations.tsv","tsv");
	dataTable = loadTable("data/random.tsv","tsv");
	nameTable = loadTable("data/names.tsv","tsv");
	font = loadFont("data/FreeSans.otf");
}

function setup() {
	createCanvas(640, 400);
	rowCount = locationTable.getRowCount();
	// Find the minimum and maximum values
	for (let r = 0; r < rowCount; r++) {
		let value = float(dataTable.getNum(r,1));
		if (value > dataMax) {
			dataMax = value;
		}
		if (value < dataMin) {
			dataMin = value;
		}
	}
}

function draw() {
	background(255);
	image(mapImage, 0, 0);
	smooth();
	fill(192, 0, 0);
	noStroke();
	
	// Use the built-in width and height variables to set the
	// closest distance high so it will be replaced immediately
	closestDist = width*height;
	
	for (let r = 0; r < rowCount; r++) {
		let abbrev = dataTable.getString(r,0);
		let row = locationTable.findRow(abbrev,0);
		let x = float(row.getNum(1));
		let y = float(row.getNum(2));
		drawData(x, y, abbrev);
  	}
  	
  	textFont(font);
  	textSize(12);
	// Use global variables set in drawData()
	// to draw text related to closest circle.
	if (closestDist != width*height) {
		fill(0);
		textAlign(CENTER);
		text(closestText, closestTextX, closestTextY);
	}
}


// Map the size of the ellipse to the data value
function drawData(x, y, abbrev) {
	// Get data value for state
	let row = dataTable.findRow(abbrev,0);
	let value = float(row.getNum(1));
	let nRow = nameTable.findRow(abbrev,0);
	let name = nRow.getString(1);
	let radius = 0;
	let clr;
	if (value >= 0){
		radius = float(map(value, 0, dataMax, 1.5, 15));
		clr = color('#4422cc'); //blue
	} else {
		radius = float(map(value, 0, dataMin, 1.5, 15));
		clr = color('#ff4422'); //red
	}
	fill(clr);
	ellipseMode(RADIUS)
	circle(x, y, radius);
	
	let d = dist(x, y, mouseX, mouseY);
	// Because the following check is done each time a new
	// circle is drawn, we end up with the values of the
	// circle closest to the mouse.
	if ((d < radius + 2) && (d < closestDist)) {
		closestDist = d;
		closestText = name + " " + value;
		closestTextX = x;
		closestTextY = y-radius-4;
	}	
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-visData-ch03-step10_single_rollover.jpg')
}

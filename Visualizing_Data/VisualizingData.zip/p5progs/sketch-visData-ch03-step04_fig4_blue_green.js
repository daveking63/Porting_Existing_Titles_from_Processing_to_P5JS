// Source: Visualizing Data
// Artist: Ben Fry
// SourceType: Book & https://benfry.com/writing/archives/3/
// Date: 2008
// PDE: step03_fig4_blue_green.pde
// Chapter: Ch03-04, Mapping, Figure 3-4
// Description: US map of the states with each state containing a circle who color varies by the magnitude of a random data value (green to turquoise blue)

let mapImage;
let locationTable;
let dataTable;
let dataMin = 20.0;
let dataMax = -20.0;
let rowCount;

function preload(){
	mapImage = loadImage("data/map.png");
	locationTable = loadTable("data/locations.tsv","tsv");
	dataTable = loadTable("data/random.tsv","tsv");
}

function setup() {
	createCanvas(640, 400);	
	rowCount = locationTable.getRowCount();
	// Find the minimum and maximum values
	for (let r = 0; r < rowCount; r++) {
		let value = float(dataTable.getNum(r,1));
		if (value > dataMax) {
			dataMax = value;
		}
		if (value < dataMin) {
			dataMin = value;
		}
	}
	noLoop();
}


function draw() {
	background(255);
	image(mapImage, 0, 0);
	smooth();
	fill(192, 0, 0);
	noStroke();
	
	for (let r = 0; r < rowCount; r++) {
		let abbrev = dataTable.getString(r,0);
		let row = locationTable.findRow(abbrev,0);
		let x = float(row.getNum(1));
		let y = float(row.getNum(2));
		drawData(x, y, abbrev);
  	}
  	noLoop;
}


// Map the size of the ellipse to the data value
function drawData(x, y, abbrev) {
	// Get data value for state
	let row = dataTable.findRow(abbrev,0);
	let value = float(row.getNum(1));
	let percent = norm(value, dataMin, dataMax);
	// from color is greenish - lower value
	let fromClr = color('#296f34');
	// to color is turquoise blue'ish - higher value
	let toClr = color('#61e2f0');
	let between = lerpColor(fromClr, toClr, percent);
	fill(between)
	circle(x, y, 15);
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-visData-ch03-step04_fig4_blue_green.jpg')
}

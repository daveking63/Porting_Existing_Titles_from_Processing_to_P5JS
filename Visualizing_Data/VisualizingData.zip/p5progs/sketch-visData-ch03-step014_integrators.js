// Source: Visualizing Data
// Artist: Ben Fry
// SourceType: Book & https://benfry.com/writing/archives/3/
// Date: 2008
// PDE: step014_integrators.pde
// Chapter: Ch03-14, Mapping, No Figure
// Description: US map of the states with state name and target values displayed when mouse passed near a state's circle
let mapImage;
let locationTable;
let dataTable;
let dataMin = 20.0;
let dataMax = -20.0;
let rowCount;
let font;
let tSize = 12;

let closestDist;
let closestText;
let closestTextX;
let closestTextY;

let interpolators = [];

function preload(){
	mapImage = loadImage("data/map.png");
	locationTable = loadTable("data/locations.tsv","tsv");
	dataTable = loadTable("data/random.tsv","tsv");
	nameTable = loadTable("data/names.tsv","tsv");
	font = loadFont("data/FreeSans.otf");
}

function setup() {
	createCanvas(640, 400);
	rowCount = locationTable.getRowCount();
	// Find the minimum and maximum values
	for (let row = 0; row < rowCount; row++) {
		let initialValue = float(dataTable.getNum(row,1));
		interpolators[row] = new Integrator(initialValue, 0.5, 0.2); // (value, damping, attraction)
	}
	for (let r = 0; r < rowCount; r++) {
		let value = float(dataTable.getNum(r,1));
		if (value > dataMax) {
			dataMax = value;
		}
		if (value < dataMin) {
			dataMin = value;
		}
	}
}

function draw() {
	background(255);
	image(mapImage, 0, 0);
	smooth();
	fill(192, 0, 0);
	noStroke();
	textFont(font);
  	textSize(12);
  	
  	for (let row = 0; row < rowCount; row++){
  		interpolators[row].update();
  	}
	
	closestDist = width*height; //arbitrarily high
	
	for (let row = 0; row < rowCount; row++) {
		let abbrev = dataTable.getString(row,0);
		let locRow = locationTable.findRow(abbrev,0);
		let x = float(locRow.getNum(1));
		let y = float(locRow.getNum(2));
		drawData(x, y, abbrev, row);
  	}
  	
	// Use global variables set in drawData()
	// to draw text related to closest circle.
	if (closestDist != width*height) {
		fill(0);
		textAlign(CENTER);
		text(closestText, closestTextX, closestTextY);
	}
}


// Map the size of the ellipse to the data value
function drawData(x, y, abbrev, row) {
	// Get data value for state
	let value = float(interpolators[row].value);
	let nRow = nameTable.findRow(abbrev,0);
	let name = nRow.getString(1);
	let radius = 0;
	let clr;
	if (value >= 0){
		radius = float(map(value, 0, dataMax, 1.5, 15));
		clr = color('#333366'); //blue
	} else {
		radius = float(map(value, 0, dataMin, 1.5, 15));
		clr = color('#ec5166'); //red
	}
	fill(clr);
	ellipseMode(RADIUS)
	circle(x, y, radius);
	
	let d = dist(x, y, mouseX, mouseY);
	// Because the following check is done each time a new
	// circle is drawn, we end up with the values of the
	// circle closest to the mouse.
	if ((d < radius + 2) && (d < closestDist)) {
		closestDist = d;
		let val = nfp(interpolators[row].target,0,2);
		closestText = name + " " + val; //nfp is used to format numbers
		closestTextX = x;
		closestTextY = y-radius-4;
	}	
}

function keyTyped() {
	if (key == ' ') {
		updateTable();
	}
}

function updateTable() {  
	for (let row = 0; row < rowCount; row++) {
		let newValue = float(random(dataMin, dataMax));
		interpolators[row].setTarget(newValue);
	}
}

class Integrator {
  constructor(val, damp, attract) {
    this.value = float(val);
    this.damping = float(damp);
    this.attraction = float(attract);
    this.targeting = false;
    this.mass = 1.0;
    this.force = 0.0;
	this.vel = 0.0;
	this.accel = 0.0;
	this.target = this.value;
    }

	update() {
		if (this.targeting) {
			this.force += this.attraction * (this.target - this.value);      
	    }
	    this.accel = this.force / this.mass;
		this.vel = (this.vel + this.accel) * this.damping;
		this.value = this.value + this.vel;
		this.force = 0.0;
	}

	setTarget(t) {
		this.targeting = true;
		this.target = t;
	}
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-visData-ch03-step014_integrators.jpg')
}

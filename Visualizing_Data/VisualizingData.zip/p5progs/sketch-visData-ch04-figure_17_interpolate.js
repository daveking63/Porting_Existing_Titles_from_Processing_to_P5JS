// Source: Visualizing Data
// Artist: Ben Fry
// SourceType: Book & https://benfry.com/writing/archives/3/
// Date: 2008
// PDE: step_17_interpolate.pde
// Chapter: Ch04-17, Mapping, No Figure
// Description: Area charts with interpolation to dampen the change from one data set to another

let dataTable;
let dataMin = 0.0;
let dataMax = 0.0;
let plotX1, plotY1; 
let plotX2, plotY2; 
let labelX, labelY;
let yearMin, yearMax; 
let years = [];
let yearInterval = 10;
let volumeInterval = 10;
let volumeIntervalMinor = 5;
let barWidth = 4;

let columnTitles = ['Year','Milk','Tea','Coffee']
let currentColumn = 1; 
let columnCount;
let rowCount;

let tabLeft = [];
let tabRight = [];
let tabTop, tabBottom;
let tabPad = 0;
let tabImageNormal = [];
let tabImageHighlight = [];
let tabImgHeight = 34;
let tabImgWidth = 55;

let plotFont;
let fontSize = 12;

let interpolators = [];

function preload(){
	dataTable = loadTable("data/milk-tea-coffee.tsv","tsv","header");
	plotFont = loadFont("data/FreeSans.otf");
	for (col = 1; col < columnTitles.length; col++){
		tabImageNormal[col] = loadImage("data/" + columnTitles[col] + "-unselected.png");
		tabImageHighlight[col] = loadImage("data/" + columnTitles[col] + "-selected.png");
	}
}

function setup() { 
	createCanvas(720, 405); 

    columnCount = dataTable.getColumnCount();
    rowCount = dataTable.getRowCount();
    
	years = dataTable.getColumn('Year');
	yearMin = years[0]; 
	yearMax = years[years.length - 1]; 

	for (let r = 0; r < dataTable.getRowCount(); r++) {
		for (let c = 1; c < dataTable.getColumnCount(); c++){
			let value = float(dataTable.getNum(r,c));
			if (value > dataMax) {
				dataMax = value;
			}
		}
	}
	
	dataMax = ceil(dataMax/volumeInterval)*volumeInterval;
	dataMin = 0;
    
	for (let row = 0; row < rowCount; row++) {
		let initialValue = float(dataTable.getNum(row,1));
		interpolators[row] = new Integrator(initialValue, 0.5, 0.1); // (value, damping, attraction)
	}
    
	// Corners of the plotted time series 
	plotX1 = 120; 
	plotX2 = width - 80;
	labelX = 50;
	plotY1 = 60;
	plotY2 = height - 70;
	labelY = height - 25; 
	smooth(); 
}

function draw() { 
	background(255);
	
	stroke(0);
	strokeWeight(0.5);

	drawTitle();
	drawTitleTabs();
	drawAxisLabels();
	
  	for (let row = 0; row < rowCount; row++){
		interpolators[row].update();
  	}
  	
	drawVolumeLabels();
    drawYearLabels();

	noStroke();
	fill(color('#5679C1'));
	drawDataArea(currentColumn);

} 

function drawTitle(){
	fill(0);
	title = columnTitles[currentColumn];
	textFont(plotFont);  
	textSize(fontSize + 2);
  	text(title, plotX1 + 30, plotY1 - 25);	
}

function drawAxisLabels(){
	fill(0);
	stroke(128);
	textSize(fontSize);
	textLeading(15);
	textAlign(CENTER, CENTER);
	// Use \n (enter/linefeed) to break the text into separate lines
	text("Gallons\nconsumed\nper capita", labelX, (plotY1+plotY2)/2);
	textAlign(CENTER);
	text("Year", (plotX1+plotX2)/2, labelY);
}

function drawYearLabels() {
	fill(0);
	stroke(0);
	textSize(fontSize-2);
	textLeading(15);
	textAlign(CENTER, TOP);
  
	// Use thin white lines to draw the grid
	stroke(255);
	strokeWeight(1);
  
	for (let row = 0; row < rowCount; row++) {
		if (years[row] % yearInterval == 0) {
			let x = float(map(years[row], yearMin, yearMax, plotX1, plotX2));
			text(years[row], x, plotY2 + 5);
			line(x, plotY1, x, plotY2);
		}
	}
}

function drawVolumeLabels() {
	fill(0);
	textSize(fontSize-2);
	textAlign(RIGHT, CENTER)

	for (let v = dataMin; v <= dataMax; v += volumeIntervalMinor) {
		if (v % volumeIntervalMinor == 0) {     // If a tick mark
			let y = float(map(v, dataMin, dataMax, plotY2, plotY1));  
			if (v % volumeInterval == 0) {        // If a major tick mark
				let textOffset = float(textAscent()/2);  // Center vertically --float?
				if (v == dataMin) {
					textOffset = 0;                   // Align by the bottom
				} else if (v == dataMax) {
					textOffset = textAscent();        // Align by the top
				}
				text(floor(v), plotX1 - 10, y - textOffset);
				line(plotX1 - 4, y, plotX1, y);     // Draw major tick
			} else {
			//line(plotX1 - 2, y, plotX1, y);     // Draw minor tick
			}
		}
	}
}

function drawTitleTabs() {
	rectMode(CORNERS);
	noStroke();
	strokeWeight(0.5);
	textSize(fontSize+8);
	textAlign(LEFT);
 	
	let runningX = float(plotX1);
	tabBottom = plotY1;

	// Size based on the height of the tabs by checking the
	// height of the first (all images are the same height)
	//print(tabImgHeight, tabImgWidth);
	tabTop = plotY1 - tabImgHeight;

	for (let col = 1; col < columnCount; col++) {
		let title = columnTitles[col];
		tabLeft[col] = runningX; 
		let titleWidth = tabImageNormal[col].width;
		tabRight[col] = tabLeft[col] + tabPad + titleWidth + tabPad;

		let tabImage = (col == currentColumn) ? 
			tabImageHighlight[col] : tabImageNormal[col];
			image(tabImage, tabLeft[col], tabTop);

		runningX = tabRight[col];
	} 
}

function mouseClicked() {
	if (mouseY > tabTop && mouseY < tabBottom) {
		for (let col = 0; col < columnCount; col++) {
			if (mouseX > tabLeft[col] && mouseX < tabRight[col]) {
				setCurrent(col);
			}
		}
	}
}

function setCurrent(col) {
	currentColumn = col;
	
	for (let row = 0; row < rowCount; row++) {
		let newValue = float(dataTable.getNum(row,col));
		interpolators[row].setTarget(newValue);
	}
}

function drawDataBars(col) { 
    noStroke();
    rectMode(CORNERS); 

	for (let row = 0; row < rowCount; row++) {
		let value = dataTable.getNum(row, col);
		let x = float(map(years[row], yearMin, yearMax, plotX1, plotX2));
		let y = float(map(value, dataMin, dataMax, plotY2, plotY1));      
		rect(x-barWidth/2, y, x+barWidth/2, plotY2);
	}
}

function drawDataArea(col) { 
	push();
	    noStroke();
	    fill(color('#5679C1'));
		beginShape();
			for (let row = 0; row < rowCount; row++) {
				//let value = dataTable.getNum(row, col);
				let value = float(interpolators[row].value);
				let x = float(map(years[row], yearMin, yearMax, plotX1, plotX2));
				let y = float(map(value, dataMin, dataMax, plotY2, plotY1));      
				vertex(x, y);
			}
			vertex(plotX2, plotY2);
			vertex(plotX1, plotY2);
		endShape(CLOSE);
	pop();
}

function keyTyped() {
if (key == '[') {
	currentColumn--;
		if (currentColumn < 1) {
			currentColumn = columnCount - 1;
		}
	} else if (key == ']') {
		currentColumn++;
		if (currentColumn == columnCount) {
			currentColumn = 1;
		}
	} else if (key == 's' || key == 'S') {
		save('img-visData-ch04-figure_17_interpolate.jpg');
	}
}

class Integrator {
  constructor(val, damp, attract) {
    this.value = float(val);
    this.damping = float(damp);
    this.attraction = float(attract);
    this.targeting = false;
    this.mass = 1.0;
    this.force = 0.0;
	this.vel = 0.0;
	this.accel = 0.0;
	this.target = this.value;
    }

	update() {
		if (this.targeting) {
			this.force += this.attraction * (this.target - this.value);      
	    }
	    this.accel = this.force / this.mass;
		this.vel = (this.vel + this.accel) * this.damping;
		this.value = this.value + this.vel;
		this.force = 0.0;
	}

	setTarget(t) {
		this.targeting = true;
		this.target = t;
	}
}

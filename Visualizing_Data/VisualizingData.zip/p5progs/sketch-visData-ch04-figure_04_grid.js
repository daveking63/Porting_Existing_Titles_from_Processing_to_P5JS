// Source: Visualizing Data
// Artist: Ben Fry
// SourceType: Book & https://benfry.com/writing/archives/3/
// Date: 2008
// PDE: figure_04_grid.pde
// Chapter: Ch04-04, Mapping, Figure 4-4
// Description: Plot of one set of data points over time with dataset and x-axis labels and vertical grid lines.

let dataTable;
let dataMin = 100.0;
let dataMax = 0.0;
let plotX1, plotY1; 
let plotX2, plotY2; 
let yearMin, yearMax; 
let years = [];
let yearInterval = 10;

let columnTitles = ['Year','Milk','Tea','Coffee']
let currentColumn = 1; 
let columnCount;
let rowCount;

let plotFont;
let fontSize = 12; 

function preload(){
	dataTable = loadTable("data/milk-tea-coffee.tsv","tsv","header");
	plotFont = loadFont("data/FreeSans.otf")
}

function setup() { 
	createCanvas(720, 405); 

    columnCount = dataTable.getColumnCount();
    rowCount = dataTable.getRowCount();
    
	years = dataTable.getColumn('Year');
	yearMin = years[0]; 
	yearMax = years[years.length - 1]; 

	for (let r = 0; r < dataTable.getRowCount(); r++) {
		for (let c = 1; c < dataTable.getColumnCount(); c++){
		let value = float(dataTable.getNum(r,c));
		//print(r, c, value);
		if (value > dataMax) {
			dataMax = value;
		}
		if (value < dataMin) {
			dataMin = value;
		}
		}
	}
    
	// Corners of the plotted time series 
	plotX1 = 50.0; 
	plotX2 = width - plotX1; 
	plotY1 = 60.0; 
	plotY2 = height - plotY1; 
	smooth(); 
}

function draw() { 
	background(224); 

	// Show the plot area as a white box 
	fill(255); 
	rectMode(CORNERS); 
	noStroke(); 
	rect(plotX1, plotY1, plotX2, plotY2); 

	strokeWeight(5); 
	// Draw the data for the first column 
	stroke(color('#5679C1')); 
	drawDataPoints(currentColumn);
    drawTitle();
    drawYearLabels()
  
} 

// Draw the data as a series of points 
function drawDataPoints(col) { 
	let rowCount = dataTable.getRowCount(); 
	for (let row = 0; row < rowCount; row++) { 
		let value = float(dataTable.getNum(row, col)); 
		let x = map(years[row], yearMin, yearMax, plotX1, plotX2); 
		let y = map(value, dataMin, dataMax, plotY2, plotY1); 
		point(x, y); 
	} 
} 

function drawTitle(){
	fill(0);
	stroke(0);
	strokeWeight(0.5);
	title = columnTitles[currentColumn];;
	textFont(plotFont);  
	textSize(fontSize + 2);
  	text(title, plotX1 + 15, plotY1 - 25);	
}

function drawYearLabels() {
  fill(0);
  textSize(10);
  textAlign(CENTER, TOP);
  
  // Use thin, gray lines to draw the grid
  stroke(224);
  strokeWeight(1);
  
  for (let row = 0; row < rowCount; row++) {
    if (years[row] % yearInterval == 0) {
      let x = float(map(years[row], yearMin, yearMax, plotX1, plotX2));
      text(years[row], x, plotY2 + 5);
      line(x, plotY1, x, plotY2);
    }
  }
}

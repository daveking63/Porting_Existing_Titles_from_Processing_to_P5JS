// Source: Visualizing Data
// Artist: Ben Fry
// SourceType: Book
// Date: 2008
// PDE: step00_show_map.pde
// Chapter: 3-01
// Description: importing a map of the US
//

let mapImage;

function preload(){
	mapImage = loadImage("data/map.png");
}

function setup() {
	createCanvas(640, 400);
}

function draw() {
	  background(255);
	  image(mapImage, 0, 0);
}


//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-visData-ch03-step00_show_map.jpg')
}

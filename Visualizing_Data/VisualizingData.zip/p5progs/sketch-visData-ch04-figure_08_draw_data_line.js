// Source: Visualizing Data
// Artist: Ben Fry
// SourceType: Book & https://benfry.com/writing/archives/3/
// Date: 2008
// PDE: figure_08_draw_data_line.pde
// Chapter: Ch04-08, Mapping, Figure 4-8
// Description: Plot of one set of data points over time with dataset and x-axis labels, vertical grid lines, y-labels with tick marks.

let dataTable;
let dataMin = 0.0;
let dataMax = 0.0;
let plotX1, plotY1; 
let plotX2, plotY2; 
let labelX, labelY;
let yearMin, yearMax; 
let years = [];
let yearInterval = 10;
let volumeInterval = 10;
let volumeIntervalMinor = 5; 

let columnTitles = ['Year','Milk','Tea','Coffee']
let currentColumn = 1; 
let columnCount;
let rowCount;

let plotFont;
let fontSize = 12; 

function preload(){
	dataTable = loadTable("data/milk-tea-coffee.tsv","tsv","header");
	plotFont = loadFont("data/FreeSans.otf")
}

function setup() { 
	createCanvas(720, 405); 

    columnCount = dataTable.getColumnCount();
    rowCount = dataTable.getRowCount();
    
	years = dataTable.getColumn('Year');
	yearMin = years[0]; 
	yearMax = years[years.length - 1]; 

	for (let r = 0; r < dataTable.getRowCount(); r++) {
		for (let c = 1; c < dataTable.getColumnCount(); c++){
			let value = float(dataTable.getNum(r,c));
			if (value > dataMax) {
				dataMax = value;
			}
		}
	}
	
	dataMax = ceil(dataMax/volumeInterval)*volumeInterval;
	dataMin = 0;
    
	// Corners of the plotted time series 
	plotX1 = 120; 
	plotX2 = width - 80;
	labelX = 50;
	plotY1 = 60;
	plotY2 = height - 70;
	labelY = height - 25; 
	smooth(); 
}

function draw() { 
	background(224); 

	// Show the plot area as a white box 
	fill(255); 
	rectMode(CORNERS); 
	noStroke(); 
	rect(plotX1, plotY1, plotX2, plotY2);
	stroke(128);
	strokeWeight(1); 
    drawTitle();
    drawAxisLabels();
    drawYearLabels()
    drawVolumeLabels();
    
    //strokeWeight(5); 
	//stroke(color('#5679C1')); 
	//drawDataPoints(currentColumn);
	
	noFill();
	strokeWeight(2);
	drawDataLine(currentColumn);
  
} 

function drawTitle(){
	fill(0);
	strokeWeight(0.5);
	title = columnTitles[currentColumn];
	textFont(plotFont);  
	textSize(fontSize + 2);
  	text(title, plotX1 + 30, plotY1 - 25);	
}

function drawAxisLabels(){
	fill(0);
	stroke(128);
	textSize(fontSize);
	textLeading(15);
	textAlign(CENTER, CENTER);
	// Use \n (enter/linefeed) to break the text into separate lines
	text("Gallons\nconsumed\nper capita", labelX, (plotY1+plotY2)/2);
	textAlign(CENTER);
	text("Year", (plotX1+plotX2)/2, labelY);
}

function drawYearLabels() {
  fill(0);
  textSize(fontSize-2);
  textAlign(CENTER, TOP);
  
  // Use thin, gray lines to draw the grid
  stroke(128);
  strokeWeight(0.5);
  
  for (let row = 0; row < rowCount; row++) {
    if (years[row] % yearInterval == 0) {
      let x = float(map(years[row], yearMin, yearMax, plotX1, plotX2));
      text(years[row], x, plotY2 + 5);
      line(x, plotY1, x, plotY2);
    }
  }
}

function drawVolumeLabels() {
	fill(0);
	textSize(fontSize - 2);
	textAlign(RIGHT,CENTER);

	for (let v = dataMin; v <= dataMax; v += volumeIntervalMinor) {
		if (v % volumeIntervalMinor == 0) {     // If a tick mark
			let y = float(map(v, dataMin, dataMax, plotY2, plotY1));  
			if (v % volumeInterval == 0) {        // If a major tick mark
				let textOffset = float(textAscent()/2);  // Center vertically --float?
				if (v == dataMin) {
					textOffset = 0;                   // Align by the bottom
				} else if (v == dataMax) {
					textOffset = textAscent();        // Align by the top
				}
				text(floor(v), plotX1 - 10, y - textOffset);
				line(plotX1 - 4, y, plotX1, y);     // Draw major tick
			} else {
			line(plotX1 - 2, y, plotX1, y);     // Draw minor tick
			}
		}
	}
}


// Draw the data as a series of points 
function drawDataPoints(col) { 
	let rowCount = dataTable.getRowCount(); 
	for (let row = 0; row < rowCount; row++) { 
		let value = float(dataTable.getNum(row, col)); 
		let x = map(years[row], yearMin, yearMax, plotX1, plotX2); 
		let y = map(value, dataMin, dataMax, plotY2, plotY1); 
		point(x, y); 
	} 
}

function drawDataLine(col) {  
	beginShape();
		for (let row = 0; row < rowCount; row++) {
			let value = dataTable.getNum(row, col);
			let x = float(map(years[row], yearMin, yearMax, plotX1, plotX2));
			let y = float(map(value, dataMin, dataMax, plotY2, plotY1));      
			vertex(x, y);
		}
	endShape();
}

function keyTyped() {
	if (key == '[') {
	currentColumn--;
		if (currentColumn < 1) {
			currentColumn = columnCount - 1;
		}
	} else if (key == ']') {
		currentColumn++;
		if (currentColumn == columnCount) {
			currentColumn = 1;
		}
	} else if (key == 's' || key == 'S') {
		save('img-visData-ch04-figure_08_draw_data_line.jpg');
	}
}

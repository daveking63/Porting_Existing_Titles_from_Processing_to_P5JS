// Source: Visualizing Data
// Artist: Ben Fry
// SourceType: Book & https://benfry.com/writing/archives/3/
// Date: 2008
// PDE: step03_fig3_red_to_blue.pde
// Chapter: Ch03-03, Mapping, Figure 3-3
// Description: US map of the states with each state containing a circle who color varies by the magnitude of a random data value (red low to blue high)

//

let mapImage;
let locationTable;
let dataTable;
let dataMin = 20.0;
let dataMax = -20.0;
let rowCount;

function preload(){
	mapImage = loadImage("data/map.png");
	locationTable = loadTable("data/locations.tsv","tsv");
	dataTable = loadTable("data/random.tsv","tsv");
}

function setup() {
	createCanvas(640, 400);	
	rowCount = locationTable.getRowCount();
	// Find the minimum and maximum values
	for (let r = 0; r < rowCount; r++) {
		let value = float(dataTable.getNum(r,1));
		if (value > dataMax) {
			dataMax = value;
		}
		if (value < dataMin) {
			dataMin = value;
		}
	}
	noLoop();
}


function draw() {
	background(255);
	image(mapImage, 0, 0);
	smooth();
	fill(192, 0, 0);
	noStroke();
	
	for (let r = 0; r < rowCount; r++) {
		let abbrev = dataTable.getString(r,0);
		let row = locationTable.findRow(abbrev,0);
		let x = float(row.getNum(1));
		let y = float(row.getNum(2));
		drawData(x, y, abbrev);
  	}
  	noLoop;
}


// Map the size of the ellipse to the data value
function drawData(x, y, abbrev) {
	// Get data value for state
	let row = dataTable.findRow(abbrev,0);
	let value = float(row.getNum(1));
	let percent = norm(value, dataMin, dataMax);
	// from color is reddish - lower value
	let fromClr = color('#ff4422');
	// to color is blue'ish - higher value
	let toClr = color('#4422cc');
	let between = lerpColor(fromClr, toClr, percent);
	fill(between)
	circle(x, y, 15);
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-visData-ch03-step03_fig3_red_to_blue.jpg')
}

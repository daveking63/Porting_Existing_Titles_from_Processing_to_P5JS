// Source: Visualizing Data
// Artist: Ben Fry
// SourceType: Book & https://benfry.com/writing/archives/3/
// Date: 2008
// PDE: round_09c_focus_handling.pde
// Chapter: Ch06-01, Scatterplot Maps, Figure 6-1
// Description: Interactive map of zipcodes in US mainland

let places = [];
let placeCount = 41556;
let zipData;
let placeDict;

let minX, maxX, minY, maxY;
let mapX1, mapX2, mapY1, mapY2;

//colors
let backColor;
let dormantColor;
let highlightedColor;
let unhighlightedColor;
let badColor;

let faders = []; //ColorIntegrator faders[];

// typing and selection  
let pFont;
let checkValStr = "";
let prevStartCode = "";
let prevEndCode = "";
let	prevStartCodeNum = -1;
let	prevEndCodeNum = -1;

let typedString = "";
let typedChars = []; //char typedChars[] = new char[5];
let typedCount; //integer
let typedPartials = []; //int typedPartials[] = new int[6];

let messageX, messageY; //floats
let inputMsgX, inputMsgY;
let inp;
let foundCount; //int
let chosen; //Place chosen;
  
// smart updates
let notUpdatedCount = 0; //int

// zoom
let zoomButton;
let zoomEnabled = false;
let zoomDepth; //Integrator zoomDepth = new Integrator();

let zoomX1; //Integrator zoomX1;
let zoomY1; //Integrator zoomY1;
let zoomX2; //Integrator zoomX2;
let zoomY2; //Integrator zoomY2;

let targetX1 = []; //float targetX1[] = new float[6];
let targetY1 = []; //float targetY1[] = new float[6];
let targetX2 = []; //float targetX2[] = new float[6];
let targetY2 = []; //float targetY2[] = new float[6];

// boundary of currently valid points at this typedCount
let boundsX1, boundsY1; //floats
let boundsX2, boundsY2; //floats

function preload(){
	zipData = loadTable('data/zips.tsv', 'tsv');
	pFont = loadFont('data/OpenSans-Regular.ttf');
}

function setup(){
	createCanvas(720, 453);
	
	//initializing colors
	backColor = color('#333333');
	dormantColor = color('#999966');
	highlightedColor = color('#cbcbcb');
	unhighlightedColor = color('#66664c');
	badColor = color('#ffff66');
	
	//font
	textFont(pFont);
	textSize(14);
	messageX = 40;
	messageY= height-40;
	inputMsgX = 50;
	inputMsgY = height-30;
	
	stroke(0);
	
	mapX1 = 20;
	mapX2 = width - mapX1;
	mapY1 = 20;
	mapY2 = height - mapY1;
    
    // create a lookup dictionary placeDict('zipcode','array number')
    // enables quick lookup of info associated with zipcode class/object
    placeDict = createStringDict();
	for (i = 0; i < placeCount; i++){
		var code = zipData.getString(i, 0);
		var latitude = zipData.getNum(i, 1);
		var longitude = zipData.getNum(i, 2);
		var name = zipData.getString(i, 3);
		places[i] = new Place(code, latitude, longitude, name);
		placeDict.set(code, str(i));
	}
	
	// set or calculate min/max figures	
	minX = -0.40;
	maxX = 0.35;
	minY = 0.90;
	maxY = 0.40;
	
	//input box for entering 5 digit zipcode
	inp = createInput('');
	inp.position(inputMsgX, inputMsgY);
	inp.size(40,15);
  	inp.input(checkTypedInput);
	
		
	zoomButton = createButton('zoom off');
  	zoomButton.position(650, height-40);
  	zoomButton.size(70, 20);
  	zoomButton.mousePressed(enableZoom);
	
	loadPixels();

}

function draw(){

    background(backColor);
	fill(255);

	for	(i = 0; i < placeCount; i++){
		places[i].placeDraw();
	}
	updatePixels();
	
	text('Enter complete or partial zipcode:', messageX, messageY);
	
	if (checkValStr.length == 5){
		if (placeDict.hasKey(checkValStr)){
			pIndx = placeDict.get(checkValStr);
			cityState = places[pIndx].name;
			nameWidth = textWidth(cityState);
			if ((nameWidth + places[pIndx].xx + 5) > width){
				textAlign(RIGHT);}
			text(cityState, places[pIndx].xx, places[pIndx].yy);
			textAlign(LEFT);
		}
	}
}

class Place{
	constructor(code, x, y, name){
		this.code = int(code);
		this.x = float(x);
		this.xx;
		this.yy
		this.y = float(y);
		this.name = name;
		this.plcClr = dormantColor; // shift from original color of 'this.plcClr = color(0,0,0);'
	}
	
	placeDraw(){
		this.xx = int(map(this.x, minX, maxX, mapX1, mapX2));
		this.yy = int(map(this.y, minY, maxY, mapY1, mapY2));
		set(this.xx, this.yy, this.plcClr);
	}
	
	setColor(status){
		if (status == 'highlight'){this.plcClr = highlightedColor;}
		else if (status == 'unhighlight'){this.plcClr = dormantColor;}
	}		
}

// function that processes zipcodes typed in input box
function checkTypedInput(){
    checkValStr = this.value();   
    if (checkValStr.length > 5){
		checkValStr = checkValStr.substring(0, checkValStr.length - 1);
    	this.value(checkValStr);
	}
    let lastKeyCode = keyCode;
	if ((keyCode < 48) || (keyCode > 57)){ //if keyCode is not a number
		if ((keyCode != BACKSPACE) && (keyCode != DELETE)) {
			if (checkValStr.length < 5){
    			checkValStr = checkValStr.substring(0, checkValStr.length - 1);
    			this.value(checkValStr);}
   		}
	}
	updateHighlights();
}

// highlights and unhighlights zipcode areas as they are typed
function updateHighlights(){
	let startCode = '';
	let endCode = '';
	let matchCnt = 0;
	let tailLen = 5 - checkValStr.length;
	for (let i = 0; i < tailLen; i++){
		startCode = startCode + '0';
		endCode = endCode + '9';
	}
	startCodeNum = int(checkValStr + startCode);
	endCodeNum =   int(checkValStr + endCode);
	
	//unhighlight previous highlights
	if (prevStartCodeNum != -1){
		for (i = prevStartCodeNum; i <= prevEndCodeNum; i++){
			chkCode = str(i);
			if (i < 1000){
			chkCode = '00' + chkCode;
			}
			else if (i < 10000){
				chkCode = '0' + chkCode;
			}
			if (placeDict.hasKey(chkCode)){
				pIndx = placeDict.get(chkCode);
				places[pIndx].setColor('unhighlight');
				places[pIndx].placeDraw();
				matchCnt += 1;
			}
		}
	}

	// highlight current input value
	if (checkValStr == ''){
		var updateClr = 'unhighlight';
	}
	else {
		var updateClr = 'highlight';
	}
	
	for (i = startCodeNum; i <= endCodeNum; i++){
		chkCode = str(i);
		if (i < 1000){
			chkCode = '00' + chkCode;
		}
		else if (i < 10000){
			chkCode = '0' + chkCode;
		}
		if (placeDict.hasKey(chkCode)){
			pIndx = placeDict.get(chkCode);
			places[pIndx].setColor(updateClr);
			places[pIndx].placeDraw();
		}
		matchCnt += 1;
	}
	
	prevStartCode = startCode;
	prevEndCode = endCode;
	prevStartCodeNum = startCodeNum;
	prevEndCodeNum = endCodeNum;
}

function enableZoom(){
	if (zoomEnabled){
		print('zoom turned off');
		document.getElementById("zoomButton").value="zoom on";
		zoomEnabled = false;
	}
	else{
		print('zoom turned on');
		document.getElementById("zoomButton").value="zoom on";
		zoomEnabled = true;
	}
}

//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-visData-ch06-round_09c_focus_handling.jpg')
}

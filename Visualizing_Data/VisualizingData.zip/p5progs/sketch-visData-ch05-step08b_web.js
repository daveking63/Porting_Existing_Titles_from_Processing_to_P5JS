// Source: Visualizing Data
// Artist: Ben Fry
// SourceType: Book & https://benfry.com/writing/archives/3/
// Date: 2008
// PDE: step08b_web.pde
// Chapter: Ch05-01, Connections and Correlations, 5-7
// Description: Connection-correlation chart showing relationship between standings ranking at end of season to total payroll salary


let ROW_HEIGHT = 23;
let HALF_ROW_HEIGHT = 11.5;
let SIDE_PADDING = 30;
let pFont;
let standings = [];
let teamCount = 30;
let bballData;
let teamNames = [];
let teamCodes = [];
let logos = [];
let logoWidth = 20;
let logoHeight = 23;
let leftX = 130;
let rightX = 360;
let wins = [];
let losses = [];
let season = [];
let standingsTitle = [];
let salaries = [];
let salaryRanks = [];

function preload(){
	pFont = loadFont('data/OpenSans-Regular.ttf');
	bballData = loadTable('data/baseball.tsv','tsv','header');
	teamCodes = ['ari','atl','bal','bos','chc','cws','cin','cle','col','det',
				'hou','kcr','laa','lad','mia','mil','min','nym','nyy','oak',
				'phi','pit','sdp','sfg','sea','stl','tbr','tex','tor','was'];
	for (i = 0; i < teamCount; i++){
		logos[i] = loadImage('data/logos/' + teamCodes[i] + '.gif');
	}	
}

function setup(){
	createCanvas(600,800);
	background(255);
	smooth();
	textFont(pFont);
	textSize(11);
	
	for (i = 0; i < teamCount; i++){
		teamNames[i] = bballData.getString(i,0);
		//teamCodes[i] = bballData.getString(i,1);
		wins[i] = bballData.getNum(i,2);
		losses[i] = bballData.getNum(i,3);
		season[i] = bballData.getNum(i,4);
		salaries[i] = bballData.getNum(i,5);
		salaryRanks[i] = bballData.getNum(i,6);
		print(teamNames[i], wins[i], losses[i], season[i], salaries[i], salaryRanks[i]); 
	}
	
	translate(SIDE_PADDING + 50, SIDE_PADDING);
	textAlign(LEFT, CENTER);
	
	for (i = 0; i < teamCount; i++){
		fill(0);
		let standingsY = float(season[i]*ROW_HEIGHT + HALF_ROW_HEIGHT);
		image(logos[i], 0, standingsY-logoHeight/2, logoWidth, logoHeight);
		text(teamNames[i], 28, standingsY);
		standingsTitle = str(wins[i]) + '-' + str(losses[i]);
		text(standingsTitle, 120, standingsY);
		let salaryY = float(salaryRanks[i]*ROW_HEIGHT + HALF_ROW_HEIGHT);
		text('$' + nfc(salaries[i]), rightX + 10, salaryY);
		push();
			if (salaryY >= standingsY){
				stroke(33, 85, 156); blue 
			}else{
				stroke(206, 0, 82);
			}
			
			let weight = map(salaries[i], min(salaries), max(salaries), 0.25, 4); 
			strokeWeight(weight);
			line(160, standingsY, rightX, salaryY);
		pop();
	}
}
//
function keyTyped(){
  if (key == 's' || key == 'S') save('img-visData-ch05-step08b_web.jpg')
}
